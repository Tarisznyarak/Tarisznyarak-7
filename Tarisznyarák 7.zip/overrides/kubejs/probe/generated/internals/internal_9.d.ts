/// <reference path="./internal_*.d.ts" />
declare namespace Internal {
    class ImageCapabilities implements Internal.Cloneable {
        constructor(arg0: boolean)
        clone(): any;
        isAccelerated(): boolean;
        isTrueVolatile(): boolean;
        get accelerated(): boolean
        get trueVolatile(): boolean
    }
    type ImageCapabilities_ = ImageCapabilities;
    class DecoratedPotRecipe extends Internal.CustomRecipe {
        constructor(arg0: ResourceLocation_, arg1: Internal.CraftingBookCategory_)
        getIngredients(): Internal.NonNullList<Internal.Ingredient>;
        getGroup(): string;
        getToastSymbol(): Internal.ItemStack;
        hasOutput(match: Internal.ReplacementMatch_): boolean;
        matches(arg0: Internal.CraftingContainer_, arg1: Internal.Level_): boolean;
        getSchema(): Internal.RecipeSchema;
        showNotification(): boolean;
        replaceInput(match: Internal.ReplacementMatch_, with_: Internal.InputReplacement_): boolean;
        getRemainingItems(arg0: Internal.CraftingContainer_): Internal.NonNullList<Internal.ItemStack>;
        getType(): ResourceLocation;
        assemble(arg0: Internal.CraftingContainer_, arg1: Internal.RegistryAccess_): Internal.ItemStack;
        setGroup(group: string): void;
        getOrCreateId(): ResourceLocation;
        hasInput(match: Internal.ReplacementMatch_): boolean;
        isIncomplete(): boolean;
        replaceOutput(match: Internal.ReplacementMatch_, with_: Internal.OutputReplacement_): boolean;
        static createDecoratedPotItem(arg0: Internal.DecoratedPotBlockEntity$Decorations_): Internal.ItemStack;
        getMod(): string;
        get ingredients(): Internal.NonNullList<Internal.Ingredient>
        get group(): string
        get toastSymbol(): Internal.ItemStack
        get schema(): Internal.RecipeSchema
        get type(): ResourceLocation
        set group(group: string)
        get orCreateId(): ResourceLocation
        get incomplete(): boolean
        get mod(): string
    }
    type DecoratedPotRecipe_ = DecoratedPotRecipe;
    interface AccessibleSelection {
        abstract clearAccessibleSelection(): void;
        abstract addAccessibleSelection(arg0: number): void;
        abstract getAccessibleSelection(arg0: number): Internal.Accessible;
        abstract removeAccessibleSelection(arg0: number): void;
        abstract selectAllAccessibleSelection(): void;
        abstract isAccessibleChildSelected(arg0: number): boolean;
        abstract getAccessibleSelectionCount(): number;
        get accessibleSelectionCount(): number
    }
    type AccessibleSelection_ = AccessibleSelection;
    interface ConfigurableAutoFlush {
        abstract setShouldAutoFlush(arg0: boolean): void;
        set shouldAutoFlush(arg0: boolean)
        (arg0: boolean): void;
    }
    type ConfigurableAutoFlush_ = ConfigurableAutoFlush;
    class ProjectileImpactEvent extends Internal.EntityEvent {
        constructor()
        constructor(arg0: Internal.Projectile_, arg1: Internal.HitResult_)
        getImpactResult(): Internal.ProjectileImpactEvent$ImpactResult;
        getProjectile(): Internal.Projectile;
        setImpactResult(arg0: Internal.ProjectileImpactEvent$ImpactResult_): void;
        getRayTraceResult(): Internal.HitResult;
        get impactResult(): Internal.ProjectileImpactEvent$ImpactResult
        get projectile(): Internal.Projectile
        set impactResult(arg0: Internal.ProjectileImpactEvent$ImpactResult_)
        get rayTraceResult(): Internal.HitResult
    }
    type ProjectileImpactEvent_ = ProjectileImpactEvent;
    class ModuleDescriptor$Exports$Modifier extends Internal.Enum<Internal.ModuleDescriptor$Exports$Modifier> {
        static values(): Internal.ModuleDescriptor$Exports$Modifier[];
        static valueOf(arg0: string): Internal.ModuleDescriptor$Exports$Modifier;
        static readonly SYNTHETIC: Internal.ModuleDescriptor$Exports$Modifier;
        static readonly MANDATED: Internal.ModuleDescriptor$Exports$Modifier;
    }
    type ModuleDescriptor$Exports$Modifier_ = "mandated" | "synthetic" | ModuleDescriptor$Exports$Modifier;
    class DynamicRecipeComponent extends Internal.Record {
        constructor(desc: Internal.TypeDescJS_, factory: Internal.DynamicRecipeComponent$Factory_)
        desc(): Internal.TypeDescJS;
        factory(): Internal.DynamicRecipeComponent$Factory;
    }
    type DynamicRecipeComponent_ = DynamicRecipeComponent;
    class Item implements Internal.FeatureElement, Internal.ItemFTBL, Internal.ItemLike, Internal.IForgeItem, Internal.ItemKJS, Internal.IZetaForgeItemStuff, Internal.IExtendedItem, Internal.InjectedItemExtension {
        constructor(arg0: Internal.Item$Properties_)
        getDrinkingSound(): Internal.SoundEvent;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        setRarity(arg0: Internal.Rarity_): void;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        getDestroySpeed(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): number;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        moonlight$addAdditionalBehavior(placementOverride: Internal.AdditionalItemPlacement_): void;
        /**
         * @deprecated
        */
        onDestroyed(arg0: Internal.ItemEntity_): void;
        isFireResistant(): boolean;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        onCraftedBy(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        isComplex(): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        appendHoverText(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.List_<net.minecraft.network.chat.Component>, arg3: Internal.TooltipFlag_): void;
        onUseTick(arg0: Internal.Level_, arg1: Internal.LivingEntity_, arg2: Internal.ItemStack_, arg3: number): void;
        /**
         * @deprecated
        */
        getFoodProperties(): Internal.FoodProperties;
        canBeHurtBy(arg0: DamageSource_): boolean;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        getUseAnimation(arg0: Internal.ItemStack_): Internal.UseAnim;
        getDescriptionId(): string;
        isValidRepairItem(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        moonlight$getClientAnimationExtension(): any;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        zeta$setHumanoidArmorModel(arg0: Internal.HumanoidArmorModelGetter_): void;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        asItem(): this;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        getTypeData(): Internal.CompoundTag;
        getDefaultInstance(): Internal.ItemStack;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        setMaxStackSize(arg0: number): void;
        setBurnTime(i: number): void;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getBarWidth(arg0: Internal.ItemStack_): number;
        setMaxDamage(arg0: number): void;
        getItem(): this;
        getBarColor(arg0: Internal.ItemStack_): number;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        getItemBuilder(): Internal.ItemBuilder;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        /**
         * @deprecated
        */
        getMaxDamage(): number;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        asIngredient(): Internal.Ingredient;
        getDescription(): net.minecraft.network.chat.Component;
        /**
         * @deprecated
        */
        hasCraftingRemainingItem(): boolean;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        static byId(arg0: number): Internal.Item;
        getRenderPropertiesInternal(): any;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        interactLivingEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.LivingEntity_, arg3: Internal.InteractionHand_): Internal.InteractionResult;
        moonlight$getAdditionalBehavior(): Internal.AdditionalItemPlacement;
        moonlight$setClientAnimationExtension(obj: any): void;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        useOn(arg0: Internal.UseOnContext_): Internal.InteractionResult;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getRarity(arg0: Internal.ItemStack_): Internal.Rarity;
        setItemBuilder(b: Internal.ItemBuilder_): void;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        setCraftingRemainingItemFTBL(arg0: Internal.Item_): void;
        setAttackDamage(attackDamage: number): void;
        isEdible(): boolean;
        getTooltipImage(arg0: Internal.ItemStack_): Internal.Optional<Internal.TooltipComponent>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        use(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.InteractionHand_): Internal.InteractionResultHolder<Internal.ItemStack>;
        /**
         * @deprecated
        */
        getEnchantmentValue(): number;
        setArmorToughness(armorToughness: number): void;
        getId(): string;
        isEnchantable(arg0: Internal.ItemStack_): boolean;
        modifyReturnValue$cjp000$overrideStackedOnOther(arg0: boolean, arg1: Internal.ItemStack_, arg2: Internal.Slot_, arg3: Internal.ClickAction_, arg4: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        overrideStackedOnOther(arg0: Internal.ItemStack_, arg1: Internal.Slot_, arg2: Internal.ClickAction_, arg3: Internal.Player_): boolean;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        isFoil(arg0: Internal.ItemStack_): boolean;
        isRepairable(arg0: Internal.ItemStack_): boolean;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        useOnRelease(arg0: Internal.ItemStack_): boolean;
        canAttackBlock(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        setDigSpeed(speed: number): void;
        getDescriptionId(arg0: Internal.ItemStack_): string;
        releaseUsing(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.LivingEntity_, arg3: number): void;
        setAttackSpeed(attackSpeed: number): void;
        isBarVisible(arg0: Internal.ItemStack_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getUseDuration(arg0: Internal.ItemStack_): number;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        /**
         * @deprecated
        */
        getMaxStackSize(): number;
        /**
         * @deprecated
        */
        static byBlock(arg0: Internal.Block_): Internal.Item;
        modifyReturnValue$cjp000$overrideOtherStackedOnMe(arg0: boolean, arg1: Internal.ItemStack_, arg2: Internal.ItemStack_, arg3: Internal.Slot_, arg4: Internal.ClickAction_, arg5: Internal.Player_, arg6: Internal.SlotAccess_): boolean;
        zeta$setBlockEntityWithoutLevelRenderer(arg0: Internal.BlockEntityWithoutLevelRenderer_): void;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        canFitInsideContainerItems(): boolean;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        isCorrectToolForDrops(arg0: Internal.BlockState_): boolean;
        verifyTagAfterLoad(arg0: Internal.CompoundTag_): void;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        finishUsingItem(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.LivingEntity_): Internal.ItemStack;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        setFireResistant(arg0: boolean): void;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        getEatingSound(): Internal.SoundEvent;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        canBeDepleted(): boolean;
        initializeClient(arg0: Internal.Consumer_<Internal.IClientItemExtensions>): void;
        getDamage(arg0: Internal.ItemStack_): number;
        mineBlock(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.LivingEntity_): boolean;
        setNameKey(arg0: string): void;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        getName(arg0: Internal.ItemStack_): net.minecraft.network.chat.Component;
        /**
         * @deprecated
        */
        getDefaultAttributeModifiers(arg0: Internal.EquipmentSlot_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$registryName(): ResourceLocation;
        getIdLocation(): ResourceLocation;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        /**
         * @deprecated
        */
        builtInRegistryHolder(): Internal.Holder$Reference<Internal.Item>;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        handler$cdo000$initializeClient(consumer: Internal.Consumer_<any>, ci: Internal.CallbackInfo_): void;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        inventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Entity_, arg3: number, arg4: boolean): void;
        hurtEnemy(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: Internal.LivingEntity_): boolean;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        /**
         * @deprecated
        */
        getCraftingRemainingItem(): this;
        getTypeItemStackKey(): Internal.ItemStackKey;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        shouldOverrideMultiplayerNbt(): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        requiredFeatures(): Internal.FeatureFlagSet;
        static getId(arg0: Internal.Item_): number;
        overrideOtherStackedOnMe(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.Slot_, arg3: Internal.ClickAction_, arg4: Internal.Player_, arg5: Internal.SlotAccess_): boolean;
        setFoodProperties(arg0: Internal.FoodProperties_): void;
        setCraftingRemainder(arg0: Internal.Item_): void;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        static getPlayerPOVHitResult(arg0: Internal.Level_, arg1: Internal.Player_, arg2: Internal.ClipContext$Fluid_): Internal.BlockHitResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        get drinkingSound(): Internal.SoundEvent
        set rarity(arg0: Internal.Rarity_)
        get fireResistant(): boolean
        get complex(): boolean
        /**
         * @deprecated
        */
        get foodProperties(): Internal.FoodProperties
        get descriptionId(): string
        get creativeTab(): string
        get typeData(): Internal.CompoundTag
        get defaultInstance(): Internal.ItemStack
        set maxStackSize(arg0: number)
        set burnTime(i: number)
        set maxDamage(arg0: number)
        get item(): Internal.Item
        get itemBuilder(): Internal.ItemBuilder
        /**
         * @deprecated
        */
        get maxDamage(): number
        get description(): net.minecraft.network.chat.Component
        get renderPropertiesInternal(): any
        set itemBuilder(b: Internal.ItemBuilder_)
        set craftingRemainingItemFTBL(arg0: Internal.Item_)
        set attackDamage(attackDamage: number)
        get edible(): boolean
        /**
         * @deprecated
        */
        get enchantmentValue(): number
        set armorToughness(armorToughness: number)
        get id(): string
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        /**
         * @deprecated
        */
        get maxStackSize(): number
        set armorKnockbackResistance(knockbackResistance: number)
        set fireResistant(arg0: boolean)
        get eatingSound(): Internal.SoundEvent
        set nameKey(arg0: string)
        get idLocation(): ResourceLocation
        get mod(): string
        set armorProtection(armorProtection: number)
        /**
         * @deprecated
        */
        get craftingRemainingItem(): Internal.Item
        get typeItemStackKey(): Internal.ItemStackKey
        set foodProperties(arg0: Internal.FoodProperties_)
        set craftingRemainder(arg0: Internal.Item_)
        static readonly BY_BLOCK: {[key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.AntibuilderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaWallSignBlock]: Internal.ZetaSignItem, [key: Internal.EndermanSkullWallBlock]: Internal.EndermanHeadItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ShingleBlock]: Internal.ShingleBlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.MagicLeavesBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TrollsteinnBlock]: Internal.BlockItem, [key: Internal.CatwalkStairBlock]: Internal.CatwalkStairBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.EnergyCellBlock]: Internal.EnergyCellBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.CastleDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShaftBlock]: Internal.BlockItem, [key: Internal.BigCannonEndBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.MushroomBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.DoublePlantBlock]: Internal.DoubleHighBlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.ClockBlock]: Internal.BlockItem, [key: Internal.CarrotBlock]: Internal.ItemNameBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.CommandBlock]: Internal.GameMasterBlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedStackedSlopeSlabBlock]: Internal.BlockItem, [key: com.ldtteam.domumornamentum.block.vanilla.StairBlock]: Internal.StairsBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.LinearChassisBlock]: Internal.BlockItem, [key: Internal.FramedCeilingHangingSignBlock]: Internal.FramedHangingSignItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StructuralArmBlock]: Internal.BlockItemIE, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.SconceWallBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SculkVeinBlock]: Internal.BlockItem, [key: Internal.SeagrassBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.UnboredScrewBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStructuralGlass<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PitcherCropBlock]: Internal.ItemNameBlockItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.FramedSmallDoubleCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.FoliageBlockBOP]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ForceFieldBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IronGateBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.MagnetBlock]: Internal.ZetaBlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: com.ldtteam.domumornamentum.block.vanilla.FenceGateBlock]: Internal.FenceGateBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.CopperPipeBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.FramedVerticalDoubleHalfSlopeBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.FramedChestBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoublePlantBlockBOP]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.LPGEngineBackBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.StructuralArmBlock]: Internal.BlockItemIE, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BellBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.EncasedFireJetBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.StageBarrierBlock]: Internal.StageBarrierBlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.TFLeavesBlock]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.MetalButtonBlock]: Internal.ZetaBlockItem, [key: Internal.FramedPrismCornerBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.TurbineEngineBackBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.FramedSlopedPrismBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.TrainTrapdoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.ChuteBlock]: Internal.ChuteItem, [key: Internal.FramedLadderBlock]: Internal.BlockItem, [key: Internal.FramedPoweredRailSlopeBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.FramedExtendedDoubleCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.CaveVinesBlock]: Internal.ItemNameBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlastFurnaceOutputBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DirtPathBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.FurnaceBlock]: Internal.BlockItem, [key: Internal.FleshBlock]: Internal.BlockItem, [key: Internal.SupportWedgeBlock]: Internal.BlockItem, [key: Internal.ThornsBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.PlayerWallHeadBlock]: Internal.PlayerHeadItem, [key: Internal.CutVineBlock]: Internal.ZetaBlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.DirtyGlassBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: com.ldtteam.domumornamentum.block.vanilla.FenceBlock]: Internal.FenceBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.MatrixEnchantingTableBlock]: Internal.ZetaBlockItem, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.InfestedRotatedPillarBlock]: Internal.BlockItem, [key: Internal.CauldronBlock]: Internal.Items$1, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FramedStackedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.ChorusVegetationBlock]: Internal.ZetaBlockItem, [key: Internal.ObsidianPressurePlateBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.PlatformBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.FramedFlatSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.SupportWedgeBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.InfestedSculkBlock]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RootsBlock]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.NetherWartBlock]: Internal.ItemNameBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.UrnBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockLeafcutterAntChamber]: Internal.AMBlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFLeavesBlock]: Internal.BlockItem, [key: Internal.SpringLauncherBlock]: Internal.BlockItem, [key: Internal.BlockHutNetherWorker]: Internal.ItemBlockHut, [key: Internal.MolecularAssemblerBlock]: Internal.AEBaseBlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockTurbineRotor]: Internal.ItemBlockTooltip<any>, [key: Internal.RopeBlock]: vectorwing.farmersdelight.common.item.RopeItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SchematicannonBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.FramedItemFrameBlock]: Internal.BlockItem, [key: Internal.MushroomBlockBOP]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.SpatialIOPortBlock]: Internal.AEBaseBlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FeastBlock]: Internal.BlockItem, [key: Internal.BlockCapsid]: Internal.AMBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.CatwalkRailingBlock]: Internal.RailingBlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedSlabEdgeBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaTrapdoorBlock]: Internal.ZetaBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFMGPumpBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.FleshTendonsBottomBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallPillarBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Experiment115Block]: Internal.Experiment115Item, [key: Internal.FeedthroughBlock]: Internal.BlockItemIE, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.IronRodBlock]: Internal.ZetaBlockItem, [key: Internal.SkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.FurnaceHeaterBlock]: Internal.BlockItemIE, [key: Internal.StringyCobwebBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.ConnectedGlassBlock]: Internal.BlockItem, [key: Internal.NotSoMysteriousCubeBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE$BlockItemIENoInventory, [key: Internal.SconceWallBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.FramedDoubleCornerBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.SlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.CreativeEnergyBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.EntityBlockingLightBlock]: Internal.TMItemBlock, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.MetalStepBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.KnightmetalBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.IncompleteAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.ZetaWallHangingSignBlock]: Internal.ZetaHangingSignItem, [key: Internal.ThatchBlock]: Internal.ZetaBlockItem, [key: Internal.FungusBlock]: Internal.BlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RailBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ArmBlock]: Internal.ArmItem, [key: Internal.BrassDiodeBlock]: Internal.BlockItem, [key: Internal.TurnTableBlock]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockHutCowboy]: Internal.ItemBlockHut, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RadialChassisBlock]: Internal.BlockItem, [key: Internal.ScaffoldingBlock]: Internal.ScaffoldingBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.PoweredFramingSawBlock]: Internal.BlockItem, [key: Internal.DDBlocks$5]: Internal.HangingSignItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockSecurityDesk, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LPGEngineBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.VanishingBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.PedestalBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.TrollRootBlock]: Internal.BlockItem, [key: Internal.JigsawBlock]: Internal.GameMasterBlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.SmallConnectorBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.PistonBaseBlock]: Internal.BlockItem, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.GunpowderBarrelBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CrateBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MultiblockPartBlock<any>]: Internal.MultiblockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SkyChestBlock]: Internal.AEBaseBlockItem, [key: Internal.MechanicalPistonBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent, [key: Internal.FeralFlareLanternBlock]: Internal.TMItemBlock, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BrassTunnelBlock]: Internal.BeltTunnelItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.FramedSoulWallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.SculkVinesPlantBlock]: Internal.BlockItem, [key: Internal.FramedFlatSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.TFMGGravityBlock]: Internal.BlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.BracketBlock]: Internal.BracketBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.PaperWallBlock]: Internal.ZetaBlockItem, [key: Internal.MineLogCoreBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedCornerPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WhistleBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.PhantomNodeBlock]: Internal.AEBaseBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.TrussBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BeltTunnelBlock]: Internal.BeltTunnelItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LanternBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.DrillBlock]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.UberousSoilBlock]: Internal.BlockItem, [key: Internal.CreativeMotorBlock]: Internal.BlockItem, [key: Internal.BlockHutArchery]: Internal.ItemBlockHut, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CellWorkbenchBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockHutFletcher]: Internal.ItemBlockHut, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PieBlock]: Internal.BlockItem, [key: Internal.MetalLadderBlock]: Internal.BlockItemIE, [key: Internal.MechanicalPressBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.TinyTNTBlock]: Internal.AEBaseBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.FramedFlatDoubleSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedWeightedPressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.BreakerSwitchBlock<any>]: Internal.BlockItemIE, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SpatialPylonBlock]: Internal.AEBaseBlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.PistonBaseBlock]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.AnvilBlock]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SupportWedgeBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.LightDetectorBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.RedstoneWallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.FramedGlowingCube]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HangingCobwebBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WindVaneBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.FramedFlatSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.MechanicalMixerBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.MediumQuarry]: Internal.ItemBlockHut, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.PumpjackHammerPartBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.ConveyorBlock]: Internal.BlockItemIE, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.QuestBarrierBlock]: Internal.QuestBarrierBlockItem, [key: Internal.SupportBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockSlave]: Internal.BlockItem, [key: Internal.TargetBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.CarpetBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.TFMGPumpBlock]: Internal.BlockItem, [key: Internal.AzaleaBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SculkJawBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.PumpBlock]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuickfiringBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.DirectionalRotatedPillarBlock]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.NetheriteDoorBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockHutCrusher]: Internal.ItemBlockHut, [key: Internal.CactusBlock]: Internal.BlockItem, [key: Internal.FloodlightBlock]: Internal.BlockItemIE, [key: Internal.BeehiveBlock]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.TomatoVineBlock]: Internal.ModItems$1, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: twilightforest.block.CloudBlock]: Internal.BlockItem, [key: Internal.MagicLeavesBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.LinearChassisBlock]: Internal.BlockItem, [key: Internal.TrafficConeBlock]: Internal.TrafficConeBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.HorizontalFacingBlock<any>]: Internal.BlockItemIE, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.ZetaFenceGateBlock]: Internal.ZetaBlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.PancakeBlock]: Internal.PancakeItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.ElevatorPulleyBlock]: Internal.BlockItem, [key: Internal.ConveyorBlock]: Internal.BlockItemIE, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ConveyorBlock]: Internal.BlockItemIE, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.SmokerBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDividedSlopeBlock]: Internal.BlockItem, [key: Internal.SliderBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ControllerRailBlock]: Internal.BlockItem, [key: Internal.FramedFancyRailBlock]: Internal.BlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WildFlaxBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.HauntedBellBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.SweetBerryBushBlock]: Internal.ItemNameBlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.WeepingVinesBlock]: Internal.BlockItem, [key: biomesoplenty.common.block.HugeLilyPadBlock]: Internal.PlaceOnWaterBlockItem, [key: Internal.WeatheringCopperVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.FramedStandingSignBlock]: Internal.FramedSignItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBase<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.QuantumLinkChamberBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQuantumEntangloporter, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.BlockHutFarmer]: Internal.ItemBlockHut, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FoliageBlockBOP]: Internal.BlockItem, [key: Internal.SmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.TaterInAJarBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.RepeaterBlock]: Internal.BlockItem, [key: Internal.DetectorBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BlockHutEnchanter]: Internal.ItemBlockHut, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HayBlock]: Internal.BlockItem, [key: Internal.ConduitBlock]: Internal.BlockItem, [key: Internal.AllBrickBlock]: Internal.AllBrickBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FramedCube]: Internal.BlockItem, [key: Internal.FramedLatticeBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlastFurnacePreheaterBlock]: Internal.BlockItemIE, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.PlasticPipeBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.HugeCloverPetalBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.LoomBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.HempBlock]: Internal.IESeedItem, [key: Internal.BlockHutMysticalSite]: Internal.ItemBlockHut, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.DebugBlock]: Internal.BlockItem, [key: Internal.FramedTrapDoorBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.CastleDoorBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SpawnerBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.MudBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.FramedInverseDoubleSlopePanelBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutBeekeeper]: Internal.ItemBlockHut, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: com.ldtteam.domumornamentum.block.vanilla.DoorBlock]: Internal.DoorBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FluidPumpBlock]: Internal.BlockItemIE, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDoubleSlopeSlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.TFMGFluidValveBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ControlsBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.CokeOvenBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.FramedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.EquipableCarvedPumpkinBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.MatrixFrameBlock]: Internal.AEBaseBlockItem, [key: Internal.WitherRoseBlock]: Internal.BlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.EtchedNagastoneBlock]: Internal.BlockItem, [key: Internal.CommandBlock]: Internal.GameMasterBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: twilightforest.block.HedgeBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.FramedPillarBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockRainbowGlass]: Internal.AMBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.ElectricLanternBlock]: Internal.BlockItemIE, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.AllBrickBlock]: Internal.AllBrickBlockItem, [key: Internal.TurretBlock<any>]: Internal.BlockItemIE, [key: Internal.HangingCobwebBottomBlock]: Internal.BlockItem, [key: Internal.DropMortarEndBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.ReappearingBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.FramedLargeInnerCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.UnboredScrewBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.CherryLeavesBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockConstructionTape]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.RedStoneWireBlock]: Internal.ItemNameBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PlayerHeadBlock]: Internal.PlayerHeadItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SconceBlock]: Internal.StandingAndWallBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.ConveyorBlock]: Internal.BlockItemIE, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.AshLayerBlock]: Internal.BlockItem, [key: Internal.FramedStairsBlock]: Internal.BlockItem, [key: Internal.FramedPillarBlock]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.BarbedWireBlock]: Internal.BlockItem, [key: Internal.FodderBlock]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallSkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.NyliumBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WebbingBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.CryingObsidianBlock]: Internal.BlockItem, [key: Internal.RakedGravelBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ArcticFurBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.RedstoneLampBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.LowGradeFuelEngineBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.GlassPaneBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.BlockRestrictiveTransporter]: Internal.ItemBlockRestrictiveTransporter, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutSifter]: Internal.ItemBlockHut, [key: Internal.StructureVoidBlock]: Internal.BlockItem, [key: Internal.MetalLadderBlock]: Internal.BlockItemIE, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.TFMGSlidingDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedFlatStackedSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.ZetaFlammablePillarBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFMGSmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.FramedItemFrameBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.GearshiftBlock]: Internal.BlockItem, [key: Internal.BrushableBlock]: Internal.BlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.FramedPrismBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: com.ldtteam.domumornamentum.block.decorative.BarrelBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BrassDiodeBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: appeng.block.storage.ChestBlock]: Internal.AEBaseBlockItem, [key: Internal.RebarFormWorkBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.BigCannonEndBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.BambooMatCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.BlockLaserFocusMatrix]: Internal.ItemBlockTooltip<any>, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: com.ldtteam.domumornamentum.block.vanilla.SlabBlock]: Internal.SlabBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.PostBlock]: Internal.BlockItemIE, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.AnvilBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStash]: Internal.ItemBlockHut, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.BlastFurnaceBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.FramedHalfSlopeBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.IncompleteAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.DispenserBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.NoticeBoardBlock]: Internal.WoodBasedBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.CampfireBlock]: Internal.BlockItem, [key: Internal.BambooMatBlock]: Internal.ZetaBlockItem, [key: Internal.HighGrassBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.metal.FluidPipeBlock]: Internal.BlockItemIE, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.VibrationChamberBlock]: Internal.AEBaseBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: blusunrize.immersiveengineering.common.blocks.metal.LanternBlock]: Internal.BlockItemIE, [key: Internal.BrassPipeBlock]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ItemGenBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.GloomySculkBlock]: Internal.BlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.SculkShriekerBlock]: Internal.BlockItem, [key: Internal.FramedSlopeBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.BrimstoneClusterBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.HullBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallSkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.MiniatureStructureBlock]: Internal.BlockItem, [key: Internal.BlackboardBlock]: Internal.BlackboardItem, [key: Internal.GlobeBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SmokeStackBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.QuartzGlassBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.RopeBlock]: Internal.RopeItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ElevatorContactBlock]: Internal.BlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.FramedDoubleSlabBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PartialConcreteBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SchematicTableBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.AirIntakeBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.ThornLeavesBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.MonorailTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockCrystalizedMucus]: Internal.AMBlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CreativeCrateBlock]: Internal.BlockItem, [key: Internal.FramedPaneBlock]: Internal.BlockItem, [key: Internal.PoweredLatchBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ElectricMotorBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.CraftingMonitorBlock]: Internal.CraftingBlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.FramedExtendedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemCapacitor, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.FramedSlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedHalfStairsBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.DistillationOutputBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.TrackSwitchBlockImpl]: Internal.TrackSwitchBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.FramedPressurePlateBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CompactEngineBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.CampfireBlock]: Internal.BlockItem, [key: Internal.FoliageBlockBOP]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.TFMGPumpBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CrafterBlock]: Internal.ZetaBlockItem, [key: Internal.BookPileBlock]: Internal.EnchantedBookItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.FramedDividedPanelBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockHutDyer]: Internal.ItemBlockHut, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.RedStoneOreBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.ModularAccumulatorBlock]: Internal.ModularAccumulatorBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.VariantFurnaceBlock]: Internal.ZetaBlockItem, [key: Internal.ShingleBlock]: Internal.ShingleBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlossomLeavesBlock]: Internal.ZetaBlockItem, [key: Internal.GunpowderBlock]: Internal.Item, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemCapacitor, [key: Internal.ZetaSaplingBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.FungusBlock]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.CalibratedSculkSensorBlock]: Internal.BlockItem, [key: Internal.NoteBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.BlockSubstitution]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.BlackstoneDecorationBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedExtendedDoubleSlopePanelBlock]: Internal.BlockItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaPressurePlateBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaFlammablePillarBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedFancyRailSlopeBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DirectionalRotatedPillarBlock]: Internal.BlockItem, [key: Internal.SugarBlock]: Internal.SugarCubeItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.IncompleteSlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.CopycatPanelBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.FieryBlock]: Internal.BlockItem, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.PartialConcreteBlock]: Internal.BlockItemIE, [key: com.ldtteam.domumornamentum.block.decorative.PaperWallBlock]: Internal.PaperwallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.SkyChestBlock]: Internal.AEBaseBlockItem, [key: Internal.FrameBlock]: Internal.TimberFrameItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.BlockMinecoloniesRack]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.RedStoneOreBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.GravelBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.StrawBaleBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.BambooSpikesBlock]: Internal.BambooSpikesTippedItem, [key: Internal.CloudBlock]: Internal.ZetaBlockItem, [key: Internal.SupportWedgeBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockHutLibrary]: Internal.ItemBlockHut, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutComposter]: Internal.ItemBlockHut, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.TurretBlock<any>]: Internal.BlockItemIE, [key: Internal.MyceliumBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.MachineInputBlock]: Internal.BlockItem, [key: Internal.DigitalAdapterBlock]: Internal.DigitalAdapterBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.GrassBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.FramedFenceBlock]: Internal.BlockItem, [key: Internal.FramedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.FramedFlatDoubleSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CatwalkBlock]: Internal.CatwalkBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.IncompleteAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PeculiarBellBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.TFHorizontalBlock]: Internal.BlockItem, [key: Internal.TFLeavesBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ScrewBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.BlockHummingbirdFeeder]: Internal.AMBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.SlagGravelBlock]: Internal.BlockItemIE, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.EntityBlockingLightBlock]: Internal.TMItemBlock, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockColonyFlagBanner]: Internal.ItemColonyFlagBanner, [key: Internal.FramedVerticalHalfStairsBlock]: Internal.BlockItem, [key: Internal.SignalBlock]: Internal.TrackTargetingBlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.GeyserBlock]: Internal.BlockItem, [key: Internal.DDBlocks$1]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: net.mehvahdjukaar.supplementaries.common.block.blocks.CrankBlock]: Internal.BlockItem, [key: Internal.TFMGSmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.SlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockHutChickenHerder]: Internal.ItemBlockHut, [key: Internal.ToggleLatchBlock]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.StickBlock]: Internal.Item, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.TFMGSmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.FireflyBlock]: Internal.WearableItem, [key: Internal.CatwalkStairBlock]: Internal.CatwalkStairBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoubleWatersidePlantBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.PaperLanternBlock]: Internal.ZetaBlockItem, [key: Internal.IronLadderBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.BellowsBlock]: Internal.WoodBasedBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DistilleryControllerBlock]: Internal.BlockItem, [key: Internal.FramedDoubleSlopedPrismBlock]: Internal.BlockItem, [key: Internal.NetheriteTrapdoorBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BeltBlock]: Internal.BeltConnectorItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BrushableBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.PillarBlock]: Internal.PillarBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.OilburnerSmokeStackBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PatternProviderBlock]: Internal.AEBaseBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.HairBlock]: Internal.BlockItem, [key: Internal.BlockDecorationController]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.RotatedFlammableBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SculkTendrilsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TallFlowerBlockBOP]: Internal.BlockItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.NoCollisionCustomTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlackstoneDecorationBlock]: Internal.BlockItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BuilderBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SimpleQuarry]: Internal.ItemBlockHut, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockHutAlchemist]: Internal.ItemBlockHut, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockSculkBoomer]: Internal.AMBlockItem, [key: Internal.FramedWeightedPressurePlateBlock]: Internal.BlockItem, [key: Internal.RotatedFlammableBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.DistilleryOutputBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GloomyGrassBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.RootStrandBlock]: Internal.BlockItem, [key: Internal.UncraftingTableBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WitherSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.StripCurtainBlock]: Internal.BlockItemIE, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TripWireHookBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.AllBrickStairBlock]: Internal.AllBrickStairBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FramedDoubleSlopePanelBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.CartographyTableBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.EnergyCellBlock]: Internal.EnergyCellBlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FramedHorizontalPaneBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.StickerBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.DirectionalRotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.OrangeAutumnLeavesBlock]: Internal.BlockItem, [key: Internal.DDBlocks$3]: Internal.SignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.ShingleSlabBlock]: Internal.ShingleSlabBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.FramedPanelBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.FramedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockVoidWormEffigy]: Internal.AMBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.WitherWallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.JarBlock]: Internal.JarItem, [key: Internal.FramedFlowerPotBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.FlywheelBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.GiantBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.LiverootBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BeehiveBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.CannonBuilderBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.MyaliteBlock]: Internal.ZetaBlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HullBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SailBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CannonCarriageBlock]: Internal.CannonCarriageBlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.HourGlassBlock]: Internal.BlockItem, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.SkyStoneTankBlock]: Internal.AEBaseBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BrassCubeBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CuttingBoardBlock]: Internal.FuelBlockItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.BlockHutWareHouse]: Internal.ItemBlockHut, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.EndLampBlock]: Internal.BlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.LayeredCauldronBlock]: Internal.Items$1, [key: Internal.FlammableFenceBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DDBlocks$4]: Internal.HangingSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TrappedChestBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockHutRabbitHutch]: Internal.ItemBlockHut, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTeleporter, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CannonDrillBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.WindmillBlock]: Internal.BlockItemIE, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.WebBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LightningRodBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BarrelBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.HullBlock]: Internal.BlockItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockBananaPeel]: Internal.AMBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.ChainGearshiftBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.FramedFlatInverseDoubleSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.UnboredSlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockHutBarracks]: Internal.ItemBlockHut, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ItemBatcherBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.MiniatureStructureBlock]: Internal.BlockItem, [key: Internal.FramedInverseDoubleCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGate]: Internal.ItemGate, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.FenceBlock]: Internal.BlockItemIE, [key: Internal.CuckooClockBlock]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.AllBrickStairBlock]: Internal.AllBrickStairBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BeanstalkLeavesBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.SoulFurnaceBlock]: Internal.ZetaBlockItem, [key: Internal.AndesiteFunnelBlock]: Internal.FunnelItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.NozzleBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.ThornRoseBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.SkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.FlippedBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.IncompleteSlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedStackedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.FramedFlatInverseDoubleSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.WallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RopeAndNailBlock]: Internal.RopeAndNailItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.CastleDoorBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SpiderEggBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.MetalStepBlock]: Internal.BlockItem, [key: Internal.HopperBlock]: Internal.BlockItem, [key: Internal.FramedFancyPoweredRailSlopeBlock]: Internal.BlockItem, [key: Internal.VentBlockImpl]: Internal.BlockItem, [key: Internal.GlassBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.TFMGFlywheelBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GravisandBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.StonecutterBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedVerticalStairsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CarminiteReactorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.GoldDoorBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockWaypoint]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.MyaliteBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedFlatElevatedDoubleSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SeaOatsBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LargePumpjackHammerConnectorBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.MyaliteBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.WroughtIronFenceBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PlacardBlock]: Internal.BlockItem, [key: Internal.FramedCenteredPanelBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.RedStoneOreBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.FramedLatticeBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.FramedFlatElevatedSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.TrapdoorBlock]: Internal.TrapdoorBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MushroomColonyBlock]: Internal.MushroomColonyItem, [key: Internal.PloughBlock]: Internal.BlockItem, [key: Internal.FramedLargeInnerCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.FramedPaneBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockHutTownHall]: Internal.ItemBlockHut, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.TFMGFlywheelBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.SpatialAnchorBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.TomeSpawnerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: twilightforest.block.FlammableBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockMechanicalPipe]: Internal.ItemBlockMechanicalPipe, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.GlowwormSilkBottomBlock]: Internal.BlockItem, [key: Internal.FramedWallSignBlock]: Internal.FramedSignItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ScrewBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PortableStorageInterfaceBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.MultiblockPartBlock<any>]: Internal.MultiblockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.ArchitectsCutterBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.MyalitePillarBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.BlossomLeavesBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.CushionBlock]: Internal.BlockItemIE, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaFenceBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockLaserAmplifier, [key: Internal.CatwalkRailingBlock]: Internal.RailingBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.SandBlock]: Internal.BlockItem, [key: Internal.PartialConcreteBlock]: Internal.BlockItemIE, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.FramedInverseDoubleSlopeSlabBlock]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.FluidShellBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.FaucetBlock]: Internal.BlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.SugarCaneBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.RedstoneRelayBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DeadBushBlock]: Internal.BlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.GoldTrapdoorBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.BlockStructuralGlass<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SpanishMossBottomBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: systems.alexander.bellsandwhistles.block.custom.PanelBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MechanicalPistonBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuickfiringBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockController]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.LockedVanishingBlock]: Internal.BlockItem, [key: Internal.PistonExtensionPoleBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.ZetaDoorBlock]: Internal.ZetaDoubleHighBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.NonMirrorableWithActiveBlock<any>]: Internal.MultiblockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.CropBlock]: Internal.ItemNameBlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.ZetaPressurePlateBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RichSoilFarmlandBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DoubleWaterPlantBlock]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaWoodenButtonBlock]: Internal.ZetaBlockItem, [key: Internal.FeedingTroughBlock]: Internal.ZetaBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.NetherrackBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.AzaleaBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FrameBraceBlock]: Internal.TimberFrameItem, [key: Internal.SmokeShellBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.GlowLichenGrowthBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.TrackSwitchBlockImpl]: Internal.TrackSwitchBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.NonMirrorableWithActiveBlock<any>]: Internal.MultiblockItem, [key: Internal.AnalogLeverBlock]: Internal.BlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RollingMillBlock]: Internal.BlockItem, [key: Internal.FramedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ClutchBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FluidValveBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.GrassBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.AmethystBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BrambleLeavesBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FramedLargeButtonBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.SupportBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.UnboredSlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.FramedVerticalDividedStairsBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.RazorWireBlock]: Internal.BlockItemIE, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.ZetaSaplingBlock]: Internal.ZetaBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.ZetaLeavesBlock]: Internal.ZetaBlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE$BlockItemIENoInventory, [key: Internal.DisplayLinkBlock]: Internal.DisplayLinkBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.MushroomColonyBlock]: Internal.MushroomColonyItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent, [key: Internal.BlockHutBaker]: Internal.ItemBlockHut, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.NagastoneBlock]: Internal.BlockItem, [key: Internal.FancyTrapdoorBlock]: Internal.FancyTrapdoorBlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.MangroveLeavesBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.PostBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.EndPortalFrameBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItemIE, [key: Internal.MetalBogieStepsBlock]: Internal.BlockItem, [key: Internal.RichSoilBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ConveyorBlock]: Internal.BlockItemIE, [key: Internal.BreakerSwitchBlock<any>]: Internal.BlockItemIE, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.MechanicalCrafterBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CastingBasinBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.LecternBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SconceLeverBlock]: Internal.BlockItem, [key: Internal.FramedStackedSlopePanelBlock]: Internal.BlockItem, [key: Internal.PumpjackBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockHutMechanic]: Internal.ItemBlockHut, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.TntBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.FlintBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BacktankBlock]: Internal.BacktankItem$BacktankBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MiniatureStructureBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaFlammablePillarBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDoubleCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.BlockBounding]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockHutPlantation]: Internal.ItemBlockHut, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.FramedStackedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.FramedRedstoneTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.AutocannonBarrelBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.AutocannonBreechBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutFisherman]: Internal.ItemBlockHut, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.PillarBlock]: Internal.PillarBlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.LanternBlock]: Internal.BlockItem, [key: Internal.ZetaWoodenButtonBlock]: Internal.ZetaBlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.HugeGlowShroomBlock]: Internal.ZetaBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.FramedPoweredRailSlopeBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FrogspawnBlock]: Internal.PlaceOnWaterBlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.MultiPistonBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.NyliumBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CloverBlock]: Internal.BlockItem, [key: Internal.WaterWheelBlock]: Internal.BlockItem, [key: Internal.BlockTerrapinEgg]: Internal.AMBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.InfestedTowerwoodBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlaxBaleBlock]: Internal.BlockItem, [key: Internal.HullBlock]: Internal.BlockItem, [key: Internal.MonsterBoxBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.BlockVoidWormBeak]: Internal.AMBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.SlimeBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.FramedTargetBlock]: Internal.BlockItem, [key: Internal.CatwalkBlock]: Internal.CatwalkBlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.FluidTankBlock]: Internal.FluidTankItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedSmallDoubleCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.VineBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.LootCrateOpenerBlock]: Internal.BlockItem, [key: Internal.DarkLeavesBlock]: Internal.BlockItem, [key: Internal.QuickfiringBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.FramedHalfPillarBlock]: Internal.BlockItem, [key: Internal.RotatedFlammableBlock]: Internal.BlockItem, [key: org.violetmoon.quark.content.building.block.RopeBlock]: Internal.RopeBlock$1, [key: Internal.FramedSoulTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.Block]: Internal.BiomassPelletBlock, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlossomLeavesBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.MoonwormBlock]: Internal.WearableItem, [key: Internal.SculkVinesBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDoublePanelBlock]: Internal.BlockItem, [key: Internal.FramedInnerThreewayCornerBlock]: Internal.BlockItem, [key: Internal.GasolineEngineBlock]: Internal.BlockItem, [key: Internal.WetSpongeBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SporeBlossomBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.CoalCokeBlockItem, [key: Internal.ConnectedGlassBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ThresholdSwitchBlock]: Internal.BlockItem, [key: Internal.BasinFoundryLidBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedButtonBlock]: Internal.BlockItem, [key: Internal.ExperienceBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.CannonMountBlock]: Internal.BlockItem, [key: Internal.TFMGSmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.FramedRedstoneWallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.ChunkLoaderBlock]: Internal.AEBaseBlockItem, [key: Internal.GaugeBlock]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDetectorRailSlopeBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.AlternatorBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedTrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.WatermillBlock]: Internal.BlockItemIE, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PowderSnowBlock]: Internal.SolidBucketItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.BacktankBlock]: Internal.BacktankItem$BacktankBlockItem, [key: Internal.WaterlilyBlock]: Internal.PlaceOnWaterBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedFancyPoweredRailBlock]: Internal.BlockItem, [key: Internal.TintedGlassBlock]: Internal.BlockItem, [key: Internal.SawdustBlock]: Internal.BlockItemIE, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.RedstoneRandomizerBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockDiversionTransporter]: Internal.ItemBlockDiversionTransporter, [key: Internal.ForceFieldBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaFenceGateBlock]: Internal.ZetaBlockItem, [key: Internal.AutocannonRecoilSpringBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GlowwormSilkBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.AxisSmokeStackBlock]: Internal.BlockItem, [key: Internal.AuroralizedGlassBlock]: Internal.BlockItem, [key: Internal.FramedLeverBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.KeepsakeCasketBlock]: Internal.TFBlocks$1, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.AutocannonBreechBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.EnergyGeneratorBlock]: Internal.AEBaseBlockItem, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ComposterBlock]: Internal.BlockItem, [key: Internal.PotatoBlock]: Internal.ItemNameBlockItem, [key: Internal.WallmountBlock]: Internal.BlockItemIE, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionCell, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoubleWaterPlantBlock]: Internal.BlockItem, [key: Internal.ZetaStandingSignBlock]: Internal.ZetaSignItem, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.LadderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.ZetaWallHangingSignBlock]: Internal.ZetaHangingSignItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.CableBusBlock]: Internal.AEBaseBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.FramedStorageBlock]: Internal.BlockItem, [key: Internal.BalloonBlock]: Internal.BlockItemBalloon, [key: Internal.BlockLogisticalSorter]: Internal.ItemBlockMachine, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.MortarStoneBlock]: Internal.MortarStoneItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RedstoneContactBlock]: Internal.RedstoneContactItem, [key: Internal.PaperWallBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBananaSlugSlime]: Internal.AMBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.AncientVaseBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.GirderBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.QuantumRingBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.CraftingTableBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FletchingTableBlock]: Internal.BlockItem, [key: Internal.DieselSmokeStackBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SteamEngineBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemCapacitor, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.SconceBlock]: Internal.StandingAndWallBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.FramedFlatExtendedSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.MetalStepBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.TFMGFluidValveBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.TorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TatamiHalfMatBlock]: Internal.FuelBlockItem, [key: Internal.FlammableStairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedGateBlock]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.ChainBlock]: Internal.BlockItem, [key: Internal.EncasedShaftBlock]: Internal.BlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWoodenButtonBlock]: Internal.ZetaBlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.FossilstoneItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.GiantBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.ZetaWallHangingSignBlock]: Internal.ZetaHangingSignItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.MetalGrabRailsBlock]: Internal.BlockItem, [key: Internal.TrophyPedestalBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedFlatElevatedDoubleSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockHutSawmill]: Internal.ItemBlockHut, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.MultiblockPartBlock<any>]: Internal.MultiblockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HEShellBlock]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FlaxBlock]: Internal.ItemNameBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BracketBlock]: Internal.BracketBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedVerticalHalfSlopeBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.SandBlockBOP]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.FramedFlatElevatedSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.YawControllerBlock]: Internal.BlockItem, [key: Internal.FramedFlatSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.QuartzLampBlock]: Internal.BlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SandBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.CACakeBlock]: Internal.BlockItem, [key: Internal.ZetaWallSignBlock]: Internal.ZetaSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaFenceGateBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDoublePrismBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.RoseQuartzLampBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SortLogCoreBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.SackBlock]: Internal.SackItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockHutUniversity]: Internal.ItemBlockHut, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BlockReptileEgg]: Internal.AMBlockItem, [key: Internal.CuckooClockBlock]: Internal.BlockItem, [key: Internal.CubeGeneratorBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.MultiblockPartBlock<any>]: Internal.MultiblockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.ContraptionControlsBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.MudBrickLatticeBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.QuartzFixtureBlock]: Internal.AEBaseBlockItem, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.LavaCauldronBlock]: Internal.Items$1, [key: Internal.ShepherdsPieBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.WeatheringCopperVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockCompostedDirt]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.InscriberBlock]: Internal.AEBaseBlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.ControllerBlock]: Internal.AEBaseBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutHospital]: Internal.ItemBlockHut, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.TallFlowerBlockBOP]: Internal.BlockItem, [key: Internal.TallGrassBlock]: Internal.BlockItem, [key: Internal.NixieTubeBlock]: Internal.BlockItem, [key: Internal.FramedDividedStairsBlock]: Internal.BlockItem, [key: Internal.PatchBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.metal.ChuteBlock]: Internal.BlockItemIE, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.BrimstoneBudBlock]: Internal.BlockItem, [key: Internal.CatwalkStairBlock]: Internal.CatwalkStairBlockItem, [key: Internal.Block]: Internal.AMBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CACakeBlock]: Internal.BlockItem, [key: Internal.GobletBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockSolidSubstitution]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BlockMinecoloniesGrave]: Internal.BlockItem, [key: Internal.FramedDoorBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.WormHeadBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BuddingTomatoBlock]: Internal.ModItems$1, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PaperLanternBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallSkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.SteelPipeBlock]: Internal.BlockItem, [key: Internal.BlockFluidSubstitution]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.FramedExtendedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.SandBlockBOP]: Internal.BlockItem, [key: Internal.FoliageBlockBOP]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockHutSwineHerder]: Internal.ItemBlockHut, [key: Internal.HandCrankBlock]: Internal.BlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.ItemShelfBlock]: Internal.WoodBasedBlockItem, [key: Internal.MelonBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.GlowLichenBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockGate]: Internal.ItemGate, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PaintSplotchesBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedInverseDoubleCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BasketBlock]: Internal.FuelBlockItem, [key: Internal.TallFlowerBlockBOP]: Internal.BlockItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaCeilingHangingSignBlock]: Internal.ZetaHangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SconceBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaSaplingBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FluidTankBlock]: Internal.FluidTankItem, [key: Internal.FramedRailSlopeBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.ExhaustBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.SawBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockSkunkSpray]: Internal.ItemStinkBottle, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FrameBlock]: Internal.TimberFrameItem, [key: Internal.TFSmokerBlock]: Internal.BlockItem, [key: Internal.ConveyorBlock]: Internal.BlockItemIE, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.FramedOneWayWindowBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.GloomyCactusBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TransformerBlock]: Internal.TransformerBlockItem, [key: Internal.MagmaBlock]: Internal.BlockItem, [key: Internal.WallmountBlock]: Internal.BlockItemIE, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.ChestBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.GantryShaftBlock]: Internal.BlockItem, [key: Internal.ZetaTrapdoorBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.BlockReptileEgg]: Internal.AMBlockItem, [key: Internal.FramedFlatExtendedSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.FramedWallBoardBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.LargeRadialEngineBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.FramedChiseledBookshelfBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.EtchedNagastoneBlock]: Internal.BlockItem, [key: Internal.ZetaFenceBlock]: Internal.ZetaBlockItem, [key: Internal.OvergrownSandBlock]: Internal.BlockItem, [key: Internal.ForceFieldBlock]: Internal.BlockItem, [key: Internal.FramedDividedSlabBlock]: Internal.BlockItem, [key: Internal.RootedDirtBlock]: Internal.BlockItem, [key: Internal.TFMGFluidValveBlock]: Internal.BlockItem, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedStackedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.GaugeBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PieBlock]: Internal.BlockItem, [key: Internal.BigCannonEndBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.MechanicalBearingBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.SemaphoreBlock]: Internal.SemaphoreItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.DragonEggBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.GasolineEngineBackBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BrambleBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.MyaliteCrystalBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.BloodBlock]: Internal.BlockItem, [key: Internal.ShingleBlock]: Internal.ShingleBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.StatueBlock]: Internal.BlockItem, [key: Internal.CicadaBlock]: Internal.WearableItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.TrollRootBlock]: Internal.BlockItem, [key: Internal.FramedSlopedStairsBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.AMBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.ShrapnelShellBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockHutLumberjack]: Internal.ItemBlockHut, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.HighGrassPlantBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.FramedThreewayCornerBlock]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DieselEngineExpansionBlock]: Internal.BlockItem, [key: Internal.FoliageBlockBOP]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ClipboardBlock]: Internal.ClipboardBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.FramedVerticalDoubleStairsBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.ZetaStandingSignBlock]: Internal.ZetaSignItem, [key: Internal.NetherSproutsBlock]: Internal.BlockItem, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.JarBoatBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.CatwalkStairBlock]: Internal.CatwalkStairBlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.WallSkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.MyaliteBlock]: Internal.ZetaBlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.BigDripleafStemBlock]: Internal.Items$1, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.PumpjackHammerHeadBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.DriveBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GrindstoneBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ComparatorBlock]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.PiglinWallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FlammableSlabBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedPressurePlateBlock]: Internal.BlockItem, [key: Internal.DoublePlantBlock]: Internal.DoubleHighBlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.MetalBogieStepsBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TurbineEngineBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaFenceBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.MudBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.FramedDoublePrismCornerBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: blusunrize.immersiveengineering.common.blocks.metal.ChuteBlock]: Internal.BlockItemIE, [key: Internal.TorchflowerCropBlock]: Internal.ItemNameBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FramedExtendedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HosePulleyBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.ZetaCeilingHangingSignBlock]: Internal.ZetaHangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.RedstoneIlluminatorBlock]: Internal.BlockItem, [key: Internal.WirelessAccessPointBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockChemicalTank, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.MangroveRootsBlock]: Internal.BlockItem, [key: Internal.BlockEnderResidue]: Internal.AMBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedSlopeSlabBlock]: Internal.BlockItem, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.PusBubbleBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.SturdyStoneBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: com.mrh0.createaddition.blocks.tesla_coil.TeslaCoilBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.BlockHutBarracksTower]: Internal.ItemBlockHut, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.BlockPressurizedTube]: Internal.ItemBlockPressurizedTube, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedCollapsibleBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.GlowShroomBlock]: Internal.ZetaBlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.MayappleBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.DeadBranchBlock]: Internal.BlockItem, [key: Internal.EjectorBlock]: Internal.EjectorItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.PowderSnowCauldronBlock]: Internal.Items$1, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.StationBlock]: Internal.TrackTargetingBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CoralPlantBlock]: Internal.BlockItem, [key: Internal.ChainDriveBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.ZetaDoorBlock]: Internal.ZetaDoubleHighBlockItem, [key: Internal.FramedBouncyCubeBlock]: Internal.BlockItem, [key: Internal.BlossomLeavesBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.NoCollisionCustomTrackBlock]: Internal.TrackBlockItem, [key: Internal.LargeConnectorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.LargePumpjackHammerPartBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.CondenserBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.TeslaCoilBlock]: Internal.BlockItemIE, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CatwalkStairBlock]: Internal.CatwalkStairBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedDividedPanelBlock]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.FramedPyramidBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SmallDripleafBlock]: Internal.DoubleHighBlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockHutCombatAcademy]: Internal.ItemBlockHut, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.MetalButtonBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.FramedExtendedDoubleCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SnifferEggBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SnowyDirtBlock]: Internal.BlockItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.PoweredBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFLeavesBlock]: Internal.BlockItem, [key: Internal.TFMGSmartFluidPipeBlock]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SmartObserverBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WeightedPressurePlateBlock]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.IOPortBlock]: Internal.AEBaseBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SupportBlock]: Internal.BlockItem, [key: Internal.BookshelfBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CarvedPumpkinBlock]: Internal.BlockItem, [key: Internal.SkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.EndRodBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.MangroveSaplingBlock]: Internal.BlockItem, [key: Internal.OnionBlock]: Internal.ItemNameBlockItem, [key: Internal.BlockHutMiner]: Internal.ItemBlockHut, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.DoublePlantBlock]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.SmokeStackBlock]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.CageBlock]: Internal.CageItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DeskBlock<any>]: Internal.BlockItemIE, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.FancyDoorBlock]: Internal.FancyDoorBlockItem, [key: Internal.CastingSpoutBlock]: Internal.BlockItem, [key: Internal.FlarestackBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CatwalkBlock]: Internal.CatwalkBlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.WildRiceBlock]: Internal.DoubleHighBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.HoneyBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.GlassBlock]: Internal.BlockItem, [key: Internal.GrowthAcceleratorBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedRedstoneBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DeskBlock<any>]: Internal.BlockItemIE, [key: Internal.SequencedGearshiftBlock]: Internal.BlockItem, [key: Internal.RoastChickenBlock]: Internal.BlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.FramedFlatStackedSlopeSlabCornerBlock]: Internal.BlockItem, [key: Internal.CertusQuartzClusterBlock]: Internal.AEBaseBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.FramedSlabCornerBlock]: Internal.BlockItem, [key: Internal.SolidShotBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.DropperBlock]: Internal.BlockItem, [key: Internal.StructureBlock]: Internal.GameMasterBlockItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.EnderWatcherBlock]: Internal.ZetaBlockItem, [key: Internal.FramedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.DecoratedPotBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FramedFancyPoweredRailBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: twilightforest.block.CloudBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StemBlock]: Internal.ItemNameBlockItem, [key: Internal.TrainTrapdoorBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.FramedFancyDetectorRailBlock]: Internal.BlockItem, [key: Internal.BeaconBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.TFMGPumpBlock]: Internal.BlockItem, [key: Internal.FramedButtonBlock]: Internal.BlockItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.VineBlock]: Internal.BlockItem, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: Internal.CanvasRugBlock]: Internal.FuelBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.BedBlock]: Internal.BedItem, [key: twilightforest.block.FlammableBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.HeadlightBlock]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.CatwalkStairBlock]: Internal.CatwalkStairBlockItem, [key: Internal.PumpkinBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.DDBlocks$2]: Internal.SignItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockHutStonemason]: Internal.ItemBlockHut, [key: Internal.FramedDoubleSlopeBlock]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.CannonLoaderBlock]: Internal.BlockItem, [key: Internal.MagicLeavesBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.UnboredSlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.SandyShrubBlock]: Internal.BlockItem, [key: Internal.SmithingTableBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ZetaDoorBlock]: Internal.ZetaDoubleHighBlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.FramedTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.KelpBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SandBlock]: Internal.AMBlockItem, [key: Internal.IronGateBlock]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.CrankBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.MushroomBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.EnchantmentTableBlock]: Internal.BlockItem, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FoliageBlockBOP]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MetalBogieStepsBlock]: Internal.BlockItem, [key: Internal.SupportBlock]: Internal.BlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.IncompleteScrewBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.MetalGrabRailsBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.GrateBlock]: Internal.ZetaBlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.PostBlock]: Internal.BlockItemIE, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.CrystalDisplayBlock]: Internal.BlockItem, [key: Internal.CommandBlock]: Internal.GameMasterBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.IncompleteScrewBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ItemDrainBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.AnvilBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.PostBlock]: Internal.PostBlockItem, [key: Internal.FramedElevatedSlopeSlabBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SculkCatalystBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.CogWheelBlock]: Internal.CogwheelBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.IncompleteAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.InterfaceBlock]: Internal.AEBaseBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.PanelBlock]: Internal.PanelBlockItem, [key: Internal.ClockworkBearingBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PoweredRailBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: com.simibubi.create.content.contraptions.pulley.PulleyBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.TwistingVinesBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.TimeLogCoreBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.AutocannonRecoilSpringBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: systems.alexander.bellsandwhistles.block.custom.PanelBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedDoubleHalfSlopeBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.MysteriousCubeBlock]: Internal.AEBaseBlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlazeRodBlock]: Internal.Item, [key: Internal.PieBlock]: Internal.BlockItem, [key: Internal.ModStairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.LargeWaterWheelBlock]: Internal.LargeWaterWheelBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MillstoneBlock]: Internal.BlockItem, [key: Internal.PointedDripstoneBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BuddingCertusQuartzBlock]: Internal.AEBaseBlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.CatwalkRailingBlock]: Internal.RailingBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockWindGenerator, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.PowderChargeBlock]: Internal.PowderChargeItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.CarminiteBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockLogisticalTransporter]: Internal.ItemBlockLogisticalTransporter, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.HoneyGlazedHamBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.ZetaPaneBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.GrapeshotBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CatwalkRailingBlock]: Internal.RailingBlockItem, [key: Internal.NonMirrorableWithActiveBlock<any>]: Internal.MultiblockItem, [key: Internal.ZetaSaplingBlock]: Internal.ZetaBlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockPersonalChest]: Internal.ItemBlockPersonalStorage<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.BlossomLeavesBlock]: Internal.ZetaBlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.TrackObserverBlock]: Internal.TrackTargetingBlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TallFlowerBlockBOP]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CogWheelBlock]: Internal.CogwheelBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockCardboardBox]: Internal.ItemBlockCardboardBox, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaSaplingBlock]: Internal.ZetaBlockItem, [key: Internal.StrongholdShieldBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.CogBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.BlockRadioactiveWasteBarrel]: Internal.ItemBlockRadioactiveWasteBarrel, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.WindmillBearingBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WispyCloudBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DeployerBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.WallSkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.FireflySpawnerBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.IndustrialPipeBlock]: Internal.BlockItem, [key: Internal.StandingSignBlockBOP]: Internal.SignItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.YellowAutumnLeavesBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BambooStalkBlock]: Internal.BlockItem, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.BrimstoneFumaroleBlock]: Internal.BlockItem, [key: Internal.FramedWallTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockLaserTractorBeam, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.FramedFlatExtendedDoubleSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.BlockBarrel]: Internal.BlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.ItemVaultBlock]: Internal.ItemVaultItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.MushroomBlockBOP]: Internal.BlockItem, [key: Internal.EnergyAcceptorBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.BurntThornsBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HullBlock]: Internal.BlockItem, [key: Internal.BlockHutConcreteMixer]: Internal.ItemBlockHut, [key: Internal.WallSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.FramedCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.FramedMiniCubeBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.ConductorWhistleFlagBlock]: Internal.ConductorWhistleItem, [key: Internal.CabinetBlock]: Internal.BlockItem, [key: Internal.AutocannonRecoilSpringBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.BlockUniversalCable]: Internal.ItemBlockUniversalCable, [key: Internal.TFSignBlock]: Internal.SignItem, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.FlapDisplayBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: blusunrize.immersiveengineering.common.blocks.metal.ChuteBlock]: Internal.BlockItemIE, [key: Internal.VariantBookshelfBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutSchool]: Internal.ItemBlockHut, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BasinBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine<any, any>]: Internal.ItemBlockMachine, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HullBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FlammableFenceGateBlock]: Internal.BlockItem, [key: Internal.TrainTrapdoorBlock]: Internal.BlockItem, [key: Internal.ValveHandleBlock]: Internal.BlockItem, [key: Internal.BlockPostBox]: Internal.ItemBlockHut, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.FluidDepositBlock]: Internal.BlockItem, [key: Internal.AmethystClusterBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MossPatchBlock]: Internal.BlockItem, [key: Internal.IncompleteSlidingBreechBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.FramedDoubleCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.RollerBlock]: Internal.RollerBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.RadialEngineBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.StoveBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DropMortarShellBlock]: Internal.BlockItem, [key: org.violetmoon.quark.content.automation.block.ChuteBlock]: Internal.ZetaBlockItem, [key: Internal.RedThreadBlock]: Internal.BlockItem, [key: Internal.BlockHutBlacksmith]: Internal.ItemBlockHut, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SandBlockBOP]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DistillationControllerBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFMGFlywheelBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.FramedBookshelfBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.WallmountBlock]: Internal.BlockItemIE, [key: Internal.SampleDrillBlock]: Internal.BlockItemIE, [key: twilightforest.block.JarBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaStandingSignBlock]: Internal.ZetaSignItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FleshTendonsBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.SkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.TurntableBlock]: Internal.BlockItemIE, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.HugeWaterLilyBlock]: Internal.HugeWaterLilyItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutDeliveryman]: Internal.ItemBlockHut, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.CastleDoorBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.InfestedBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MapleLeavesBlock]: Internal.BlockItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.AuroraBrickBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TurtleEggBlock]: Internal.BlockItem, [key: Internal.MossBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SafeBlock]: Internal.SafeItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockHutSmeltery]: Internal.ItemBlockHut, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.FeatherBlock]: Internal.BlockItem, [key: Internal.MovingMagnetizedBlock]: Internal.ZetaBlockItem, [key: Internal.FramedGateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BrassFunnelBlock]: Internal.FunnelItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.AmethystBlock]: Internal.BlockItem, [key: Internal.RotatedFlammableBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.GiantLeavesBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.ZetaTrapdoorBlock]: Internal.ZetaBlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.JacarandaLeavesBlock]: Internal.BlockItem, [key: Internal.TFWallSignBlock]: Internal.SignItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.CinderFurnaceBlock]: Internal.BlockItem, [key: Internal.BlockEnergyCube]: Internal.ItemBlockEnergyCube, [key: Internal.ZetaFlammablePillarBlock]: Internal.ZetaBlockItem, [key: Internal.SmallLightConnectorBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.FiddleheadBlock]: Internal.BlockItem, [key: Internal.FleshBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItemIE, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.CraftingUnitBlock]: Internal.AEBaseBlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockHutBuilder]: Internal.ItemBlockHut, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.TatamiBlock]: Internal.FuelBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BlockHutGuardTower]: Internal.ItemBlockHut, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.IncompleteAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.FlammableLeavesBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SnowLayerBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.FramedExtendedSlopePanelBlock]: Internal.BlockItem, [key: Internal.FramedPyramidBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.SandBlock]: Internal.AMBlockItem, [key: Internal.FlowerBoxBlock]: Internal.BlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.SlidingDoorBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.FramedFlatStackedSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockInductionProvider, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.PaperWallBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FlammableBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TripWireBlock]: Internal.ItemNameBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.BlockBase<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.ChorusPlantBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SteelTankBlock]: Internal.SteelTankItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.SkullCandleBlock]: Internal.SkullCandleItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockBisonCarpet]: Internal.AMBlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.FramedVerticalSlopedStairsBlock]: Internal.BlockItem, [key: Internal.TimberFrameBlock]: Internal.TimberFrameBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BigCartridgeBlock]: Internal.BigCartridgeBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.BlockGustmaker]: Internal.AMBlockItem, [key: Internal.WoolCarpetBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.DaylightDetectorBlock]: Internal.BlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.JukeboxBlock]: Internal.BlockItem, [key: Internal.BlockTagSubstitution]: Internal.ItemTagSubstitution, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.MultiblockPartBlock<any>]: Internal.MultiblockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DetectorRailBlock]: Internal.BlockItem, [key: Internal.SconceWallBlock]: Internal.StandingAndWallBlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.CrushingWheelBlock]: Internal.BlockItem, [key: Internal.BlazeBurnerBlock]: Internal.BlazeBurnerBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactoryMachineModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.FallenLeavesBlock]: Internal.TFItems$1, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.HalfTransparentBlock]: Internal.BlockItem, [key: Internal.FramedFenceGateBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.SpeedControllerBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.MushgloomBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparentSlab]: Internal.ItemBlockColoredName, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.FramedFancyPoweredRailSlopeBlock]: Internal.BlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.BlockChargepad]: Internal.ItemBlockTooltip<any>, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent$ItemBlockQIOInventoryComponent, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaSaplingBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.TaskScreenBlock]: Internal.ScreenBlockItem, [key: Internal.GhastTrapBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.RedstoneTorchBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockQIOComponent$ItemBlockQIOInventoryComponent, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TorchBlock]: Internal.StandingAndWallBlockItem, [key: blusunrize.immersiveengineering.common.blocks.metal.ChuteBlock]: Internal.BlockItemIE, [key: Internal.CandelabraBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.CeilingHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.PortableEnergyInterfaceBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BeetrootBlock]: Internal.ItemNameBlockItem, [key: com.ldtteam.domumornamentum.block.decorative.BarrelBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.EyebulbBlock]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SmokeStackBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.BlockScarecrow]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockPlantationField]: Internal.BlockItem, [key: Internal.AxisSmokeStackBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.ConcretePowderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrainTrapdoorBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: Internal.RiceBaleBlock]: Internal.BlockItem, [key: Internal.BlockIndustrialAlarm]: Internal.ItemBlockTooltip<any>, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.HammockBlock]: Internal.HammockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.SculkTendrilsPlantBlock]: Internal.BlockItem, [key: Internal.TFMGPumpBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.MagicLeavesBlock]: Internal.BlockItem, [key: Internal.BlockHutGlassblower]: Internal.ItemBlockHut, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockTooltip<any>, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SupportBlock]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.ChargerBlock]: Internal.AEBaseBlockItem, [key: Internal.AutocannonBreechBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.IEEntityBlock<any>]: Internal.BlockItemIE, [key: Internal.APShellBlock]: Internal.BlockItem, [key: Internal.TatamiMatBlock]: Internal.FuelBlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.CatwalkBlock]: Internal.CatwalkBlockItem, [key: Internal.CarpetBlock]: Internal.BlockItem, [key: Internal.FramedWallBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.StainedGlassBlock]: Internal.BlockItem, [key: Internal.OrganicCompostBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FramedLargeButtonBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaFenceGateBlock]: Internal.ZetaBlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.MangrovePropaguleBlock]: Internal.BlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.StandingSignBlock]: Internal.SignItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: com.simibubi.create.content.kinetics.turntable.TurntableBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.GlowShroomRingBlock]: Internal.ZetaBlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.HugeGlowShroomBlock]: Internal.ZetaBlockItem, [key: Internal.BlockReptileEgg]: Internal.AMBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.FramingSawBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.PulleyBlock]: Internal.WoodBasedBlockItem, [key: Internal.GantryCarriageBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.SpeakerBlock]: Internal.WoodBasedBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.RespawnAnchorBlock]: Internal.BlockItem, [key: Internal.RainbowLampBlock]: Internal.ZetaBlockItem, [key: Internal.TrappedPresentBlock]: Internal.PresentItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockTransmutationTable]: Internal.BlockItemAMRender, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.CreativeEnergyCellBlock]: Internal.AEBaseBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedFancyDetectorRailSlopeBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.AEDecorativeBlock]: Internal.AEBaseBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.StemBlock]: Internal.ItemNameBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CookingPotBlock]: Internal.CookingPotItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockHutFlorist]: Internal.ItemBlockHut, [key: Internal.LeverBlock]: Internal.BlockItem, [key: Internal.TallFlowerBlock]: Internal.DoubleHighBlockItem, [key: com.ldtteam.domumornamentum.block.vanilla.WallBlock]: Internal.WallBlockItem, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.FarmersDelightCompat$PlanterRichBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SeaPickleBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CoralBlock]: Internal.BlockItem, [key: Internal.FluidPipeBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutTavern]: Internal.ItemBlockHut, [key: Internal.PumpjackHammerConnectorBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.CastIronPipeBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.RedStoneOreBlock]: Internal.BlockItem, [key: Internal.WaterlilyBlockBOP]: Internal.PlaceOnWaterBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.MetalGrabRailsBlock]: Internal.BlockItem, [key: Internal.FireJetBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.FramedCornerSlopeBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.MultiblockPartBlock$WithMirrorState<any>]: Internal.MultiblockItem, [key: Internal.GearboxBlock]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.IncompleteAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.EncasedCogwheelBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.SafetyNetBlock]: Internal.FuelBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.RootsBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.EncasedPipeBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.FarmBlock]: Internal.BlockItem, [key: Internal.UnboredAutocannonBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.CatwalkRailingBlock]: Internal.RailingBlockItem, [key: Internal.ForceFieldBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.EtchedNagastoneBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.TallGrassBlock]: Internal.BlockItem, [key: Internal.DepotBlock]: Internal.BlockItem, [key: Internal.NonMirrorableWithActiveBlock<any>]: Internal.MultiblockItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.SculkSensorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.PillarBlock]: Internal.PillarBlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.VariantTrappedChestBlock]: Internal.ZetaBlockItem, [key: Internal.FramedWallHangingSignBlock]: Internal.FramedHangingSignItem, [key: Internal.SoulSandBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BuddingAmethystBlock]: Internal.BlockItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.CeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.NapalmBombBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperFullBlock]: Internal.BlockItem, [key: Internal.CasingBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ObserverBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.WallBannerBlock]: Internal.BannerItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.FlowerBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SupportWedgeBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.SurfaceScannerBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SpiralBrickBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.TFChestBlock]: Internal.TFBlocks$1, [key: Internal.FramedDoubleThreewayCornerBlock]: Internal.BlockItem, [key: Internal.TFMGSlidingDoorBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticTransparentStairs]: Internal.ItemBlockColoredName, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.CabbageBlock]: Internal.ItemNameBlockItem, [key: Internal.FramedInnerPrismCornerBlock]: Internal.BlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.TrussBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaPressurePlateBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.FramedPressurePlateBlock]: Internal.BlockItem, [key: Internal.CageLampBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.BannerBlock]: Internal.BannerItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: twilightforest.block.JarBlock]: Internal.BlockItem, [key: twilightforest.block.FlammableBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaGlassBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CeilingHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SpoutBlock]: Internal.AssemblyOperatorBlockItem, [key: Internal.PumpjackCrankBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.TFMGFluidValveBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallCanvasSignBlock]: Internal.SignItem, [key: Internal.HorizontalFacingBlock<any>]: Internal.BlockItemIE, [key: Internal.BlockMinecoloniesNamedGrave]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.HangingRootsBlock]: Internal.BlockItem, [key: Internal.BasicConnectorBlock<any>]: Internal.BlockItemIE, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.BlockOre]: Internal.ItemBlockTooltip<any>, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockHutShepherd]: Internal.ItemBlockHut, [key: Internal.HollowLogVertical]: Internal.HollowLogItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.PilotBlock]: Internal.BlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.ChorusFlowerBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SpongeBlock]: Internal.BlockItem, [key: Internal.ZetaCeilingHangingSignBlock]: Internal.ZetaHangingSignItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.EndermanSkullBlock]: Internal.EndermanHeadItem, [key: Internal.HalfTransparentBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.OthersidePortalBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockResource]: Internal.ItemBlockResource, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.WeatheringCopperVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WeightedPressurePlateBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.DyedPlacardBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.SculkBlock]: Internal.BlockItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.PortableStorageInterfaceBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ForceFieldBlock]: Internal.BlockItem, [key: Internal.SailBlock]: Internal.BlankSailBlockItem, [key: Internal.ZetaFlammableBlock]: Internal.ZetaBlockItem, [key: Internal.DriedSaltBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.HugeLilyPadBlock]: Internal.HugeLilyPadItem, [key: Internal.PinkPetalsBlock]: Internal.BlockItem, [key: Internal.SmartChuteBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.FramedCornerSlopeBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.AutocannonBarrelBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.BubbleBlock]: Internal.BubbleBlockItem, [key: Internal.TrussBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.BarrierBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.SaplingBlock]: Internal.BlockItem, [key: Internal.HollowLogHorizontal]: Internal.HollowLogItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.LargePumpjackHammerHeadBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SpanishMossBlock]: Internal.BlockItem, [key: Internal.BlockPlasticFenceGate]: Internal.ItemBlockColoredName, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.BrewingStandBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.UnripeTorchClusterBlock]: Internal.BlockItem, [key: Internal.CopycatStepBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BigDripleafBlock]: Internal.Items$1, [key: Internal.Block]: Internal.BlockItem, [key: com.simibubi.create.content.decoration.MetalLadderBlock]: Internal.BlockItem, [key: Internal.CakeBlock]: Internal.BlockItem, [key: Internal.ShulkerBoxBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.CartAssemblerBlock]: Internal.CartAssemblerBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FloatingCarpetBlock]: Internal.BlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.EnderChestBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SupportWedgeBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FenceBlock]: Internal.FurnaceFuelItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.TrackCouplerBlockImpl]: Internal.TrackCouplerBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.DieselEngineBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.MetalScaffoldingBlock]: Internal.MetalScaffoldingBlockItem, [key: Internal.ZetaStairsBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.FlowerBlockBOP]: Internal.BlockItem, [key: Internal.IronBarsBlock]: Internal.BlockItem, [key: Internal.TrophyBlock]: Internal.TrophyItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.APShotBlock]: Internal.BlockItem, [key: Internal.LeafCarpetBlock]: Internal.ZetaBlockItem, [key: Internal.FramedExtendedDoubleCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.CannonCastMouldBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BanisterBlock]: Internal.FurnaceFuelItem, [key: Internal.TorchberryPlantBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.SeatBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.CatwalkBlock]: Internal.CatwalkBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaPillarBlock]: Internal.ZetaBlockItem, [key: Internal.RelayerBlock]: Internal.BlockItem, [key: Internal.UnboredBigCannonBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.HarvesterBlock]: Internal.BlockItem, [key: Internal.CorundumBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.SupportBlock]: Internal.BlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.WallSignBlockBOP]: Internal.SignItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.AutocannonBarrelBlock]: Internal.AutocannonBlockItem<any>, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.BlockTile<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.TransLogCoreBlock]: Internal.BlockItem, [key: Internal.PumpjackBaseBlock]: Internal.BlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.RiceBlock]: Internal.RiceItem, [key: Internal.TransformerHVBlock]: Internal.BlockItemIE, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.WallHangingSignBlockBOP]: Internal.HangingSignItem, [key: Internal.WindowBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.DecalBlock]: Internal.BlockItem, [key: Internal.HollowLogBlock]: Internal.ZetaBlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.HedgeBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.CandleBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.ChiseledBookShelfBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ThornsBlock]: Internal.BlockItem, [key: Internal.CabinetBlock]: Internal.FuelBlockItem, [key: twilightforest.block.CloudBlock]: Internal.BlockItem, [key: Internal.FramedExtendedCornerSlopePanelWallBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallSkullBlock]: Internal.StandingAndWallBlockItem, [key: Internal.FramedSlopedPrismBlock]: Internal.BlockItem, [key: Internal.DoorBlock]: Internal.DoubleHighBlockItem, [key: Internal.BookPileHorizontalBlock]: Internal.BookItem, [key: Internal.WeatheringCopperStairBlock]: Internal.BlockItem, [key: Internal.BlockPlastic]: Internal.ItemBlockColoredName, [key: Internal.HugeMushroomBlock]: Internal.BlockItem, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.FormWorkBlock]: Internal.BlockItem, [key: Internal.EncasedSmokerBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockTile$BlockTileModel<any, any>]: Internal.ItemBlockMachine, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.BigCannonTubeBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedLightBlock]: Internal.FramedLightBlockItem, [key: Internal.TFMGFluidValveBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.PoweredRailBlock]: Internal.BlockItem, [key: Internal.IEStairsBlock]: Internal.BlockItemIE, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.GlobeBlock]: Internal.BlockItem, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.BlockHutGraveyard]: Internal.ItemBlockHut, [key: Internal.Block]: Internal.BlockItem, [key: Internal.FramedFlatStackedSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.BlockLeafcutterAnthill]: Internal.AMBlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.FenceGateBlock]: Internal.FurnaceFuelItem, [key: Internal.HorizontalFacingBlock<any>]: Internal.BlockItemIE, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.EncasedShaftBlock]: Internal.BlockItem, [key: Internal.TrackBlock]: Internal.TrackBlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.RamHeadBlock]: Internal.BlockItem, [key: Internal.VariantChestBlock]: Internal.ZetaBlockItem, [key: Internal.RotatedPillarBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaInheritedPaneBlock]: Internal.ZetaBlockItem, [key: Internal.FramedExtendedDoubleCornerSlopePanelBlock]: Internal.VerticalAndWallBlockItem, [key: Internal.BlockHutStoneSmeltery]: Internal.ItemBlockHut, [key: Internal.Block]: Internal.BlockItem, [key: Internal.RedstoneLinkBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockPlasticTransparent]: Internal.ItemBlockColoredName, [key: Internal.FenceBlock]: Internal.BlockItem, [key: Internal.SaplingBlockBOP]: Internal.BlockItem, [key: Internal.CatwalkBlock]: Internal.CatwalkBlockItem, [key: Internal.BlockHutCook]: Internal.ItemBlockHut, [key: Internal.WallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.FramedFlatExtendedDoubleSlopePanelCornerBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.WeatheringCopperSlabBlock]: Internal.BlockItem, [key: Internal.BrickBlock]: Internal.BlockItem, [key: Internal.BigCannonLayerBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.LightBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.FramedPrismBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.GlowingMossBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.FramedDoubleStairsBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.DoormatBlock]: Internal.WoodBasedBlockItem, [key: Internal.WideGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.BlockCompDrawers]: Internal.ItemDrawers, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.WallHangingCanvasSignBlock]: Internal.HangingSignItem, [key: Internal.BlockColonyFlagWallBanner]: Internal.ItemColonyFlagBanner, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.EnergyMeterBlock]: Internal.BlockItemIE, [key: Internal.CandleHolderBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TrophyWallBlock]: Internal.TrophyItem, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.BlockPersonalBarrel]: Internal.ItemBlockPersonalStorage<any>, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.Block]: Internal.BlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.ToolboxBlock]: Internal.UncontainableBlockItem, [key: Internal.BlockTriopsEggs]: Internal.AMBlockItem, [key: twilightforest.block.FlammableBlock]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.Block]: Internal.BlockItem, [key: Internal.ZetaWallBlock]: Internal.ZetaBlockItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.BlockStandardDrawers]: Internal.ItemDrawers, [key: Internal.ClocheBlock]: Internal.BlockItemIE, [key: Internal.TFLogBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.FramedElevatedDoubleSlopeSlabBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ShippingContainerBlock]: Internal.ShippingContainerBlockItem, [key: Internal.CocoaBlock]: Internal.ItemNameBlockItem, [key: Internal.ConnectedGlassPaneBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.TFWallHangingSignBlock]: Internal.HangingSignItem, [key: Internal.DoorBlock]: Internal.BlockItem, [key: Internal.BlockPlasticRoad]: Internal.ItemBlockColoredName, [key: Internal.ChorusVegetationBlock]: Internal.ZetaBlockItem, [key: Internal.FlagBlock]: Internal.FlagItem, [key: Internal.IEBaseBlock]: Internal.BlockItemIE, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.StainedGlassPaneBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.TFCeilingHangingSignBlock]: Internal.HangingSignItem, [key: Internal.FramedCenteredSlabBlock]: Internal.BlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.BlockFactoryMachine$BlockFactory<any>]: Internal.ItemBlockFactory, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockHutCitizen]: Internal.ItemBlockHut, [key: Internal.ZetaWallSignBlock]: Internal.ZetaSignItem, [key: Internal.BaseCoralWallFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.ExtraBlock]: Internal.ExtraBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.BlockBin]: Internal.ItemBlockBin, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.PinkPetalsBlock]: Internal.BlockItem, [key: Internal.MetalLadderBlock]: Internal.BlockItemIE, [key: Internal.WoodPostBlock]: Internal.ZetaBlockItem, [key: Internal.EncasedFanBlock]: Internal.BlockItem, [key: Internal.GiantBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BaseCoralFanBlock]: Internal.StandingAndWallBlockItem, [key: Internal.BlockObsidianTNT]: Internal.BlockItem, [key: Internal.BlockThermodynamicConductor]: Internal.ItemBlockThermodynamicConductor, [key: Internal.SleepingBagBlock]: Internal.SleepingBagItem, [key: Internal.ConnectedPillarBlock]: Internal.BlockItem, [key: Internal.BossSpawnerBlock]: Internal.BlockItem, [key: Internal.SoapBlock]: Internal.BlockItem, [key: Internal.FramedSlopePanelBlock]: Internal.BlockItem, [key: Internal.StandingCanvasSignBlock]: Internal.SignItem, [key: Internal.FramedFloorBlock]: Internal.BlockItem, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.BlockBasicMultiblock<any>]: Internal.ItemBlockTooltip<any>, [key: Internal.StairBlock]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.StoolBlock]: Internal.ZetaBlockItem, [key: Internal.FlowerPotBlock]: Internal.BlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.BlockPlasticFence]: Internal.ItemBlockColoredName, [key: Internal.Block]: Internal.BlockItem, [key: Internal.PressurePlateBlock]: Internal.BlockItem, [key: Internal.TinyPotatoBlock]: Internal.TinyPotatoBlockItem, [key: Internal.BlockPlasticStairs]: Internal.ItemBlockColoredName, [key: Internal.RiceRollMedleyBlock]: Internal.BlockItem, [key: Internal.SkilletBlock]: Internal.SkilletItem, [key: Internal.WildCropBlock]: Internal.BlockItem, [key: Internal.TrapDoorBlock]: Internal.BlockItem, [key: Internal.QuarkVerticalSlabBlock]: Internal.ZetaBlockItem, [key: Internal.BlockPlasticSlab]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.GlazedTerracottaBlock]: Internal.BlockItem, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.PresentBlock]: Internal.PresentItem, [key: Internal.CorundumClusterBlock]: Internal.ZetaBlockItem, [key: Internal.FenceGateBlock]: Internal.BlockItem, [key: Internal.BigCannonEndBlock]: Internal.BigCannonBlockItem<any>, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockIESlab<any>]: Internal.BlockItemIE, [key: Internal.BlockGlowPanel]: Internal.ItemBlockColoredName, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.SnowblossomLeavesBlock]: Internal.BlockItem, [key: Internal.DropExperienceBlock]: Internal.BlockItem, [key: Internal.BlockTrim]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaBlock]: Internal.ZetaBlockItem, [key: Internal.BedBlock]: Internal.BedItem, [key: Internal.NarrowGaugeTrackBlock]: Internal.TrackBlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.AluminumPipeBlock]: Internal.BlockItem, [key: Internal.Block]: Internal.BlockItem, [key: Internal.CraftingUnitBlock]: Internal.CraftingBlockItem, [key: Internal.ButtonBlock]: Internal.BlockItem, [key: Internal.LockBlock]: Internal.BlockItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.BlockFluidTank]: Internal.ItemBlockFluidTank, [key: Internal.VariantLadderBlock]: Internal.ZetaBlockItem, [key: Internal.CatwalkRailingBlock]: Internal.RailingBlockItem, [key: Internal.HollowLogClimbable]: Internal.HollowLogItem, [key: Internal.WallBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.SlabBlock]: Internal.BlockItem, [key: Internal.ZetaSlabBlock]: Internal.ZetaBlockItem, [key: Internal.Block]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.wooden.CraftingTableBlock]: Internal.BlockItemIE, [key: Internal.LeavesBlock]: Internal.BlockItem, [key: blusunrize.immersiveengineering.common.blocks.generic.ScaffoldingBlock]: Internal.BlockItemIE, [key: Internal.BaseCoralPlantBlock]: Internal.BlockItem};
        static readonly EAT_DURATION: 32;
        static readonly BASE_ATTACK_DAMAGE_UUID: Internal.UUID;
        static readonly MAX_STACK_SIZE: 64;
        static readonly MAX_BAR_WIDTH: 13;
        descriptionId: string;
        renderProperties: any;
        craftingRemainingItem: Internal.Item;
    }
    type Item_ = Item | Special.Item;
    class RedstoneLinkBlockEntity extends Internal.SmartBlockEntity {
        constructor(arg0: Internal.BlockEntityType_<any>, arg1: BlockPos_, arg2: Internal.BlockState_)
        setSignal(arg0: number): void;
        deserializeNBT(arg0: Internal.Tag_): void;
        requestModelDataUpdate(): void;
        write(arg0: Internal.CompoundTag_, arg1: boolean): void;
        getReceivedSignal(): number;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        tdv$isDynamicLightEnabled(): boolean;
        transmit(arg0: number): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        getModelData(): Internal.ModelData;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        getSignal(): number;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        set signal(arg0: number)
        get receivedSignal(): number
        get modelData(): Internal.ModelData
        get signal(): number
    }
    type RedstoneLinkBlockEntity_ = RedstoneLinkBlockEntity;
    interface ITrackedContentsItemHandler extends Internal.IItemHandlerSimpleInserter {
        count(ingredient: Internal.Ingredient_): number;
        count(): number;
        abstract setStackInSlot(arg0: number, arg1: Internal.ItemStack_): void;
        isEmpty(): boolean;
        abstract unregisterStackKeyListeners(): void;
        clear(ingredient: Internal.Ingredient_): void;
        find(): number;
        abstract getSlots(): number;
        abstract extractItem(arg0: number, arg1: number, arg2: boolean): Internal.ItemStack;
        getBlock(level: Internal.Level_): Internal.BlockContainerJS;
        setChanged(): void;
        kjs$self(): Internal.IItemHandler;
        abstract registerTrackingListeners(arg0: Internal.Consumer_<net.p3pp3rf1y.sophisticatedcore.inventory.ItemStackKey>, arg1: Internal.Consumer_<net.p3pp3rf1y.sophisticatedcore.inventory.ItemStackKey>, arg2: Internal.Runnable_, arg3: Internal.Runnable_): void;
        abstract getStackInSlot(arg0: number): Internal.ItemStack;
        abstract hasEmptySlots(): boolean;
        getHeight(): number;
        countNonEmpty(): number;
        asContainer(): net.minecraft.world.Container;
        getWidth(): number;
        abstract getSlotLimit(arg0: number): number;
        getAllItems(): Internal.List<Internal.ItemStack>;
        abstract getTrackedStacks(): Internal.Set<net.p3pp3rf1y.sophisticatedcore.inventory.ItemStackKey>;
        abstract getInternalSlotLimit(arg0: number): number;
        abstract insertItem(arg0: Internal.ItemStack_, arg1: boolean): Internal.ItemStack;
        abstract insertItem(arg0: number, arg1: Internal.ItemStack_, arg2: boolean): Internal.ItemStack;
        isMutable(): boolean;
        clear(): void;
        find(ingredient: Internal.Ingredient_): number;
        countNonEmpty(ingredient: Internal.Ingredient_): number;
        abstract isItemValid(arg0: number, arg1: Internal.ItemStack_): boolean;
        get empty(): boolean
        get slots(): number
        get height(): number
        get width(): number
        get allItems(): Internal.List<Internal.ItemStack>
        get trackedStacks(): Internal.Set<net.p3pp3rf1y.sophisticatedcore.inventory.ItemStackKey>
        get mutable(): boolean
    }
    type ITrackedContentsItemHandler_ = ITrackedContentsItemHandler;
    interface ItemSupplier {
        abstract getItem(): Internal.ItemStack;
        get item(): Internal.ItemStack
        (): Internal.ItemStack_;
    }
    type ItemSupplier_ = ItemSupplier;
    class QuarterProperty extends Internal.Enum<Internal.QuarterProperty> implements Internal.StringRepresentable {
        static valueOf(arg0: string): Internal.QuarterProperty;
        static keys(arg0: Internal.StringRepresentable_[]): Internal.Keyable;
        static fromEnum<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>): Internal.StringRepresentable$EnumCodec<E>;
        static fromEnumWithMapping<E extends Internal.Enum<E> & Internal.StringRepresentable>(arg0: Internal.Supplier_<E[]>, arg1: Internal.Function_<string, string>): Internal.StringRepresentable$EnumCodec<E>;
        getSerializedName(): string;
        getName(): string;
        static values(): Internal.QuarterProperty[];
        get serializedName(): string
        get name(): string
        static readonly SOUTH_EAST: Internal.QuarterProperty;
        static readonly NORTH_EAST: Internal.QuarterProperty;
        static readonly NORTH_WEST: Internal.QuarterProperty;
        static readonly SOUTH_WEST: Internal.QuarterProperty;
    }
    type QuarterProperty_ = "north_west" | "north_east" | "south_west" | QuarterProperty | "south_east";
    interface Boolean2ObjectFunction <V> extends it.unimi.dsi.fastutil.Function<boolean, V> {
        put(arg0: boolean, arg1: V): V;
        andThenShort(arg0: Internal.Object2ShortFunction_<V>): Internal.Boolean2ShortFunction;
        andThenObject<T>(arg0: Internal.Object2ObjectFunction_<V, T>): Internal.Boolean2ObjectFunction<T>;
        composeFloat(arg0: Internal.Float2BooleanFunction_): Internal.Float2ObjectFunction<V>;
        composeReference<T>(arg0: Internal.Reference2BooleanFunction_<T>): Internal.Reference2ObjectFunction<T, V>;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: V): V;
        andThenDouble(arg0: Internal.Object2DoubleFunction_<V>): Internal.Boolean2DoubleFunction;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenFloat(arg0: Internal.Object2FloatFunction_<V>): Internal.Boolean2FloatFunction;
        andThenInt(arg0: Internal.Object2IntFunction_<V>): Internal.Boolean2IntFunction;
        composeLong(arg0: Internal.Long2BooleanFunction_): Internal.Long2ObjectFunction<V>;
        /**
         * @deprecated
        */
        put(arg0: boolean, arg1: V): V;
        /**
         * @deprecated
        */
        get(arg0: any): V;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        remove(arg0: any): V;
        andThenLong(arg0: Internal.Object2LongFunction_<V>): Internal.Boolean2LongFunction;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, boolean>): Internal.Function<T, V>;
        apply(arg0: boolean): V;
        abstract get(arg0: boolean): V;
        andThenByte(arg0: Internal.Object2ByteFunction_<V>): Internal.Boolean2ByteFunction;
        andThen<V>(arg0: Internal.Function_<V, V>): Internal.Function<boolean, V>;
        composeShort(arg0: Internal.Short2BooleanFunction_): Internal.Short2ObjectFunction<V>;
        composeInt(arg0: Internal.Int2BooleanFunction_): Internal.Int2ObjectFunction<V>;
        composeChar(arg0: Internal.Char2BooleanFunction_): Internal.Char2ObjectFunction<V>;
        containsKey(arg0: boolean): boolean;
        andThenReference<T>(arg0: Internal.Object2ReferenceFunction_<V, T>): Internal.Boolean2ReferenceFunction<T>;
        composeObject<T>(arg0: Internal.Object2BooleanFunction_<T>): Internal.Object2ObjectFunction<T, V>;
        remove(arg0: boolean): V;
        size(): number;
        composeDouble(arg0: Internal.Double2BooleanFunction_): Internal.Double2ObjectFunction<V>;
        clear(): void;
        composeByte(arg0: Internal.Byte2BooleanFunction_): Internal.Byte2ObjectFunction<V>;
        defaultReturnValue(): V;
        getOrDefault(arg0: boolean, arg1: V): V;
        identity<T>(): Internal.Function<T, T>;
        defaultReturnValue(arg0: V): void;
        andThenChar(arg0: Internal.Object2CharFunction_<V>): Internal.Boolean2CharFunction;
        (arg0: boolean): V;
    }
    type Boolean2ObjectFunction_<V> = Boolean2ObjectFunction<V>;
    class ExperienceNuggetItem extends Internal.Item {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ExperienceNuggetItem_ = ExperienceNuggetItem;
    class HoeItemBuilder extends Internal.HandheldItemBuilder {
        constructor(i: ResourceLocation_)
        createObject(): Internal.Item;
    }
    type HoeItemBuilder_ = HoeItemBuilder;
    class BlockLeafcutterAntChamber extends Internal.Block {
        constructor()
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly FUNGUS: Internal.IntegerProperty;
    }
    type BlockLeafcutterAntChamber_ = BlockLeafcutterAntChamber;
    class BlockColonyFlagBanner extends Internal.AbstractColonyFlagBanner<Internal.BlockColonyFlagBanner> {
        constructor()
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        registerBlock(arg0: Internal.IForgeRegistry_<any>): Internal.IBlockMinecolonies<any>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly ROTATION: Internal.IntegerProperty;
    }
    type BlockColonyFlagBanner_ = BlockColonyFlagBanner;
    class GoalSelectorDebugRenderer$DebugGoal {
        constructor(arg0: BlockPos_, arg1: number, arg2: string, arg3: boolean)
        readonly name: string;
        readonly priority: number;
        readonly isRunning: boolean;
        readonly pos: BlockPos;
    }
    type GoalSelectorDebugRenderer$DebugGoal_ = GoalSelectorDebugRenderer$DebugGoal;
    abstract class HangingEntity extends Internal.Entity implements Internal.DynamicLightSource {
        setMotionY(y: number): void;
        isPeacefulCreature(): boolean;
        getDistance(pos: BlockPos_): number;
        setRotation(yaw: number, pitch: number): void;
        playSound(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        getStepHeight(): number;
        isAmbientCreature(): boolean;
        getSoundFromFluidType(arg0: Internal.FluidType_, arg1: Internal.SoundAction_): Internal.SoundEvent;
        isMonster(): boolean;
        getPos(): BlockPos;
        addAdditionalSaveData(arg0: Internal.CompoundTag_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        canHydrateInFluidType(arg0: Internal.FluidType_): boolean;
        getType(): string;
        self(): Internal.Entity;
        canaryOnBlockCacheDeleted(): void;
        getBlock(): Internal.BlockContainerJS;
        getPickedResult(arg0: Internal.HitResult_): Internal.ItemStack;
        getNbt(): Internal.CompoundTag;
        getMotionY(): number;
        getName(): net.minecraft.network.chat.Component;
        canaryOnBlockCacheSet(arg0: Internal.BlockState_): void;
        abstract dropItem(arg0: Internal.Entity_): void;
        abstract getWidth(): number;
        setPosition(x: number, y: number, z: number): void;
        getPassengers(): Internal.EntityArrayList;
        runCommandSilent(command: string): number;
        canStartSwimming(): boolean;
        isAnimal(): boolean;
        isPlayer(): boolean;
        survives(): boolean;
        readAdditionalSaveData(arg0: Internal.CompoundTag_): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        setY(y: number): void;
        getFluidFallDistanceModifier(arg0: Internal.FluidType_): number;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        isInFluidType(arg0: Internal.BiPredicate_<Internal.FluidType, number>): boolean;
        isLiving(): boolean;
        canFluidExtinguish(arg0: Internal.FluidType_): boolean;
        alwaysAccepts(): boolean;
        isInFluidType(arg0: Internal.FluidState_): boolean;
        isPushedByFluid(arg0: Internal.FluidType_): boolean;
        spawn(): void;
        getServer(): Internal.MinecraftServer;
        getDisplayName(): net.minecraft.network.chat.Component;
        setMotionX(x: number): void;
        shouldUpdateFluidWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        setMotionZ(z: number): void;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        canarySetClimbingMobCachingSectionUpdateBehavior(arg0: boolean): void;
        attack(hp: number): void;
        abstract playPlacementSound(): void;
        canSwimInFluidType(arg0: Internal.FluidType_): boolean;
        tdv$isDynamicLightEnabled(): boolean;
        getTeamId(): string;
        setNbt(nbt: Internal.CompoundTag_): void;
        canBeRiddenUnderFluidType(arg0: Internal.FluidType_, arg1: Internal.Entity_): boolean;
        getLevel(): Internal.Level;
        getFacing(): Internal.Direction;
        getScriptType(): Internal.ScriptType;
        isMultipartEntity(): boolean;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        shouldRiderSit(): boolean;
        abstract getHeight(): number;
        getParts(): Internal.PartEntity<any>[];
        setPositionAndRotation(x: number, y: number, z: number, yaw: number, pitch: number): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        isInFluidType(arg0: Internal.FluidType_): boolean;
        getFluidMotionScale(arg0: Internal.FluidType_): number;
        getMotionX(): number;
        isWaterCreature(): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getEyeHeightForge(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        getMotionZ(): number;
        getItem(): Internal.ItemStack;
        setX(x: number): void;
        tell(message: net.minecraft.network.chat.Component_): void;
        serializeNBT(): Internal.CompoundTag;
        setZ(z: number): void;
        setDirection(arg0: Internal.Direction_): void;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        isEyeInFluidType(arg0: Internal.FluidType_): boolean;
        getDistanceSq(pos: BlockPos_): number;
        isFrame(): boolean;
        getProfile(): Internal.GameProfile;
        playSound(id: Internal.SoundEvent_): void;
        getClassification(arg0: boolean): Internal.MobCategory;
        runCommand(command: string): number;
        getDistance(x: number, y: number, z: number): number;
        set motionY(y: number)
        get peacefulCreature(): boolean
        get stepHeight(): number
        get ambientCreature(): boolean
        get monster(): boolean
        get pos(): BlockPos
        get type(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        get motionY(): number
        get name(): net.minecraft.network.chat.Component
        get width(): number
        get passengers(): Internal.EntityArrayList
        get animal(): boolean
        get player(): boolean
        set y(y: number)
        get living(): boolean
        get server(): Internal.MinecraftServer
        get displayName(): net.minecraft.network.chat.Component
        set motionX(x: number)
        set position(block: Internal.BlockContainerJS_)
        set motionZ(z: number)
        get teamId(): string
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        get facing(): Internal.Direction
        get scriptType(): Internal.ScriptType
        get multipartEntity(): boolean
        get height(): number
        get parts(): Internal.PartEntity<any>[]
        get motionX(): number
        get waterCreature(): boolean
        get motionZ(): number
        get item(): Internal.ItemStack
        set x(x: number)
        set z(z: number)
        set direction(arg0: Internal.Direction_)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get frame(): boolean
        get profile(): Internal.GameProfile
    }
    type HangingEntity_ = HangingEntity;
    class BundleDelimiterPacket <T extends Internal.PacketListener> implements Internal.Packet<T> {
        constructor()
        write(arg0: Internal.FriendlyByteBuf_): void;
        isSkippable(): boolean;
        handle(arg0: T): void;
        get skippable(): boolean
    }
    type BundleDelimiterPacket_<T extends Internal.PacketListener> = BundleDelimiterPacket<T>;
    class TurntableBlock extends Internal.IEEntityBlock<any> {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type TurntableBlock_ = TurntableBlock;
    interface IChunkTimeSave {
        abstract smoothchunk$setSaveTimePoint(arg0: number): void;
        abstract smoothchunk$getNextSaveTime(): number;
    }
    type IChunkTimeSave_ = IChunkTimeSave;
    class AbacusItem extends Internal.ZetaItem {
        constructor(arg0: Internal.ZetaModule_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        static isEnabled(arg0: Internal.Item_): boolean;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        setDigSpeed(speed: number): void;
        getArmorTextureZeta(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        shouldCauseReequipAnimationZeta(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getMaxDamageZeta(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        isRepairableZeta(arg0: Internal.ItemStack_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        canElytraFlyZeta(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onEntityItemUpdateZeta(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        isBookEnchantableZeta(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        onItemUseFirstZeta(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        static getCount(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Level_): number;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        canApplyAtEnchantingTableZeta(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        static isEnabled(arg0: Internal.Block_): boolean;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        getItem(): Internal.Item;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        getAllEnchantmentsZeta(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        setCondition(arg0: Internal.BooleanSupplier_): any;
        isEnderMaskZeta(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        static getBlockPos(arg0: Internal.ItemStack_): BlockPos;
        setCreativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>): Internal.Item;
        static setBlockPos(arg0: Internal.ItemStack_, arg1: BlockPos_): void;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        isEnabled(): boolean;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getBurnTimeZeta(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        getEnchantmentLevelZeta(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        canEquipZeta(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        setCreativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>, arg1: Internal.ItemLike_, arg2: boolean): Internal.Item;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        damageItemZeta<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        getEnchantmentValueZeta(arg0: Internal.ItemStack_): number;
        canShearZeta(arg0: Internal.ItemStack_): boolean;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        getDefaultTooltipHideFlagsZeta(arg0: Internal.ItemStack_): number;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        doesSneakBypassUseZeta(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        get item(): Internal.Item
        set armorKnockbackResistance(knockbackResistance: number)
        set condition(arg0: Internal.BooleanSupplier_)
        set creativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>)
        get enabled(): boolean
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        static readonly TAG_POS_X: "boundPosX";
        static readonly TAG_POS_Y: "boundPosY";
        static readonly TAG_POS_Z: "boundPosZ";
        static MAX_COUNT: 48;
    }
    type AbacusItem_ = AbacusItem;
    interface LightTextureAccessor {
        abstract getFlicker(): number;
        abstract isDirty(): boolean;
        get flicker(): number
        get dirty(): boolean
    }
    type LightTextureAccessor_ = LightTextureAccessor;
    class DistillationOutputBlock extends Internal.Block implements Internal.IBE<Internal.DistillationOutputBlockEntity> {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        getBlockEntityClass(): typeof Internal.DistillationOutputBlockEntity;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.DistillationOutputBlockEntity>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockEntityType(): Internal.BlockEntityType<Internal.DistillationOutputBlockEntity>;
        getBlockStates(): Internal.List<Internal.BlockState>;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.DistillationOutputBlockEntity>): void;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.DistillationOutputBlockEntity;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.DistillationOutputBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockEntityClass(): typeof Internal.DistillationOutputBlockEntity
        get blockEntityType(): Internal.BlockEntityType<Internal.DistillationOutputBlockEntity>
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type DistillationOutputBlock_ = DistillationOutputBlock;
    class GiftLootEventJS extends Internal.LootEventJS {
        constructor(c: Internal.Map_<ResourceLocation, Internal.JsonElement>)
        addGift(id: ResourceLocation_, b: Internal.Consumer_<Internal.LootBuilder>): void;
    }
    type GiftLootEventJS_ = GiftLootEventJS;
    class BlockHutDeliveryman extends Internal.AbstractBlockHut<Internal.BlockHutDeliveryman> {
        constructor()
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        static createTickerHelper<E extends Internal.BlockEntity, A extends Internal.BlockEntity>(arg0: Internal.BlockEntityType_<A>, arg1: Internal.BlockEntityType_<E>, arg2: Internal.BlockEntityTicker_<E>): Internal.BlockEntityTicker<A>;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        shouldBrowseBuildings(arg0: Internal.PlayerInteractEvent$RightClickItem_): boolean;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type BlockHutDeliveryman_ = BlockHutDeliveryman;
    interface SignedMessageChain$Decoder {
        unsigned(arg0: Internal.UUID_): this;
        abstract unpack(arg0: Internal.MessageSignature_, arg1: Internal.SignedMessageBody_): Internal.PlayerChatMessage;
        (arg0: Internal.MessageSignature, arg1: Internal.SignedMessageBody): Internal.PlayerChatMessage_;
        readonly REJECT_ALL: Internal.SignedMessageChain$Decoder;
    }
    type SignedMessageChain$Decoder_ = SignedMessageChain$Decoder;
    class ICustomModule$ModuleDamageAbsorbInfo extends Internal.Record {
        constructor(absorptionRatio: Internal.FloatSupplier_, energyCost: Internal.FloatingLongSupplier_)
        absorptionRatio(): Internal.FloatSupplier;
        energyCost(): Internal.FloatingLongSupplier;
    }
    type ICustomModule$ModuleDamageAbsorbInfo_ = ICustomModule$ModuleDamageAbsorbInfo;
    class ServerEventJS extends Internal.EventJS {
        constructor(s: Internal.MinecraftServer_)
        getServer(): Internal.MinecraftServer;
        get server(): Internal.MinecraftServer
        readonly server: Internal.MinecraftServer;
    }
    type ServerEventJS_ = ServerEventJS;
    class PotatoCannonItem extends Internal.ProjectileWeaponItem implements Internal.CustomArmPoseItem {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        getArmPose(arg0: Internal.ItemStack_, arg1: Internal.AbstractClientPlayer_, arg2: Internal.InteractionHand_): Internal.HumanoidModel$ArmPose;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        isCannon(arg0: Internal.ItemStack_): boolean;
        setArmorProtection(armorProtection: number): void;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        static getAmmoforPreview(arg0: Internal.ItemStack_): Internal.Optional<Internal.ItemStack>;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
        static readonly MAX_DAMAGE: 100;
        static CLIENT_CURRENT_AMMO: Internal.ItemStack;
    }
    type PotatoCannonItem_ = PotatoCannonItem;
    abstract class AbstractConnectorBlock <BE extends Internal.AbstractConnectorBlockEntity> extends Internal.Block implements Internal.IWrenchable, Internal.IBE<BE>, Internal.ITransformableBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        transform(arg0: Internal.BlockState_, arg1: Internal.StructureTransform_): Internal.BlockState;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        onWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<BE, Internal.InteractionResult>): Internal.InteractionResult;
        abstract getBlockEntityType(): Internal.BlockEntityType<BE>;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<BE>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<BE>): void;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getRotatedBlockState(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        abstract getBlockEntityClass(): BE;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): BE;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockEntityType(): Internal.BlockEntityType<BE>
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        get blockEntityClass(): BE
        static readonly VARIANT: Internal.EnumProperty<Internal.ConnectorVariant>;
        static readonly MODE: Internal.EnumProperty<Internal.ConnectorMode>;
        static readonly FACING: Internal.DirectionProperty;
    }
    type AbstractConnectorBlock_<BE extends Internal.AbstractConnectorBlockEntity> = AbstractConnectorBlock<BE>;
    class NestedRadialMode extends Internal.Record implements Internal.INestedRadialMode {
        constructor(arg0: Internal.RadialData_<any>, arg1: Internal.ILangEntry_, arg2: ResourceLocation_, arg3: Internal.EnumColor_)
        constructor(nestedData: Internal.RadialData_<any>, sliceName: net.minecraft.network.chat.Component_, icon: ResourceLocation_, color: Internal.EnumColor_)
        constructor(arg0: Internal.RadialData_<any>, arg1: net.minecraft.network.chat.Component_, arg2: ResourceLocation_)
        sliceName(): net.minecraft.network.chat.Component;
        icon(): ResourceLocation;
        nestedData(): Internal.RadialData<any>;
        color(): Internal.EnumColor;
        hasNestedData(): boolean;
    }
    type NestedRadialMode_ = NestedRadialMode;
    class FishingHook extends Internal.Projectile {
        constructor(arg0: Internal.Player_, arg1: Internal.Level_, arg2: number, arg3: number)
        constructor(arg0: Internal.EntityType_<Internal.FishingHook>, arg1: Internal.Level_)
        setMotionY(y: number): void;
        isPeacefulCreature(): boolean;
        getDistance(pos: BlockPos_): number;
        setRotation(yaw: number, pitch: number): void;
        playSound(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        getHookedIn(): Internal.Entity;
        getStepHeight(): number;
        isAmbientCreature(): boolean;
        getSoundFromFluidType(arg0: Internal.FluidType_, arg1: Internal.SoundAction_): Internal.SoundEvent;
        isMonster(): boolean;
        addAdditionalSaveData(arg0: Internal.CompoundTag_): void;
        isOnScoreboardTeam(teamId: string): boolean;
        canHydrateInFluidType(arg0: Internal.FluidType_): boolean;
        getType(): string;
        self(): Internal.Entity;
        canaryOnBlockCacheDeleted(): void;
        getBlock(): Internal.BlockContainerJS;
        getPickedResult(arg0: Internal.HitResult_): Internal.ItemStack;
        getNbt(): Internal.CompoundTag;
        getMotionY(): number;
        getName(): net.minecraft.network.chat.Component;
        canaryOnBlockCacheSet(arg0: Internal.BlockState_): void;
        setPosition(x: number, y: number, z: number): void;
        getPassengers(): Internal.EntityArrayList;
        runCommandSilent(command: string): number;
        canStartSwimming(): boolean;
        isAnimal(): boolean;
        isPlayer(): boolean;
        readAdditionalSaveData(arg0: Internal.CompoundTag_): void;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        getPlayerOwner(): Internal.Player;
        setY(y: number): void;
        getFluidFallDistanceModifier(arg0: Internal.FluidType_): number;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        isInFluidType(arg0: Internal.BiPredicate_<Internal.FluidType, number>): boolean;
        isLiving(): boolean;
        canFluidExtinguish(arg0: Internal.FluidType_): boolean;
        alwaysAccepts(): boolean;
        isInFluidType(arg0: Internal.FluidState_): boolean;
        isPushedByFluid(arg0: Internal.FluidType_): boolean;
        spawn(): void;
        getServer(): Internal.MinecraftServer;
        getDisplayName(): net.minecraft.network.chat.Component;
        setMotionX(x: number): void;
        shouldUpdateFluidWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        setMotionZ(z: number): void;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        canarySetClimbingMobCachingSectionUpdateBehavior(arg0: boolean): void;
        attack(hp: number): void;
        canSwimInFluidType(arg0: Internal.FluidType_): boolean;
        retrieve(arg0: Internal.ItemStack_): number;
        tdv$isDynamicLightEnabled(): boolean;
        getTeamId(): string;
        setNbt(nbt: Internal.CompoundTag_): void;
        canBeRiddenUnderFluidType(arg0: Internal.FluidType_, arg1: Internal.Entity_): boolean;
        getLevel(): Internal.Level;
        getFacing(): Internal.Direction;
        getScriptType(): Internal.ScriptType;
        isMultipartEntity(): boolean;
        shouldRiderSit(): boolean;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        getParts(): Internal.PartEntity<any>[];
        setPositionAndRotation(x: number, y: number, z: number, yaw: number, pitch: number): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        isInFluidType(arg0: Internal.FluidType_): boolean;
        getFluidMotionScale(arg0: Internal.FluidType_): number;
        getMotionX(): number;
        isWaterCreature(): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getEyeHeightForge(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        getMotionZ(): number;
        getItem(): Internal.ItemStack;
        setX(x: number): void;
        tell(message: net.minecraft.network.chat.Component_): void;
        serializeNBT(): Internal.CompoundTag;
        setZ(z: number): void;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        isEyeInFluidType(arg0: Internal.FluidType_): boolean;
        getDistanceSq(pos: BlockPos_): number;
        isFrame(): boolean;
        getProfile(): Internal.GameProfile;
        playSound(id: Internal.SoundEvent_): void;
        getClassification(arg0: boolean): Internal.MobCategory;
        isOpenWaterFishing(): boolean;
        runCommand(command: string): number;
        getDistance(x: number, y: number, z: number): number;
        set motionY(y: number)
        get peacefulCreature(): boolean
        get hookedIn(): Internal.Entity
        get stepHeight(): number
        get ambientCreature(): boolean
        get monster(): boolean
        get type(): string
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        get motionY(): number
        get name(): net.minecraft.network.chat.Component
        get passengers(): Internal.EntityArrayList
        get animal(): boolean
        get player(): boolean
        get playerOwner(): Internal.Player
        set y(y: number)
        get living(): boolean
        get server(): Internal.MinecraftServer
        get displayName(): net.minecraft.network.chat.Component
        set motionX(x: number)
        set position(block: Internal.BlockContainerJS_)
        set motionZ(z: number)
        get teamId(): string
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        get facing(): Internal.Direction
        get scriptType(): Internal.ScriptType
        get multipartEntity(): boolean
        get parts(): Internal.PartEntity<any>[]
        get motionX(): number
        get waterCreature(): boolean
        get motionZ(): number
        get item(): Internal.ItemStack
        set x(x: number)
        set z(z: number)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get frame(): boolean
        get profile(): Internal.GameProfile
        get openWaterFishing(): boolean
    }
    type FishingHook_ = FishingHook;
    class DoubleFaceAttachedBlock extends Internal.HorizontalDirectionalBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly FACE: Internal.EnumProperty<Internal.DoubleFaceAttachedBlock$DoubleAttachFace>;
    }
    type DoubleFaceAttachedBlock_ = DoubleFaceAttachedBlock;
    class ItemSupplyChestDeployer extends Internal.AbstractItemMinecolonies {
        constructor(arg0: Internal.Item$Properties_)
        static canShipBePlaced(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Blueprint_, arg3: Internal.List_<Internal.PlacementError>, arg4: Internal.Player_): boolean;
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ItemSupplyChestDeployer_ = ItemSupplyChestDeployer;
    abstract class EngineBackPartBlock extends Internal.DirectionalBlock implements Internal.IWrenchable {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        onWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getRotatedBlockState(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type EngineBackPartBlock_ = EngineBackPartBlock;
    class TemplateMultiblock$TemplateData extends Internal.Record {
        constructor(template: Internal.StructureTemplate_, blocksWithoutAir: Internal.List_<Internal.StructureTemplate$StructureBlockInfo>, triggerState: Internal.BlockState_)
        template(): Internal.StructureTemplate;
        triggerState(): Internal.BlockState;
        blocksWithoutAir(): Internal.List<Internal.StructureTemplate$StructureBlockInfo>;
    }
    type TemplateMultiblock$TemplateData_ = TemplateMultiblock$TemplateData;
    interface IFluidContainerManager extends Internal.IHasMode {
        abstract previousMode(): void;
        abstract nextMode(): void;
        abstract getContainerEditMode(): Internal.IFluidContainerManager$ContainerEditMode;
        get containerEditMode(): Internal.IFluidContainerManager$ContainerEditMode
    }
    type IFluidContainerManager_ = IFluidContainerManager;
    class EmptyMapItem extends Internal.ComplexItem {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type EmptyMapItem_ = EmptyMapItem;
    class BellowsBlock extends Internal.Block implements Internal.EntityBlock {
        constructor(properties: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getTicker<T extends Internal.BlockEntity>(pLevel: Internal.Level_, pState: Internal.BlockState_, pBlockEntityType: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        updatePower(state: Internal.BlockState_, world: Internal.Level_, pos: BlockPos_): void;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(pPos: BlockPos_, pState: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        static createVoxelShapeY(height: number): Internal.VoxelShape;
        static createVoxelShapeXZ(height: number): Internal.VoxelShape;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly POWER: Internal.IntegerProperty;
        static readonly FACING: Internal.DirectionProperty;
    }
    type BellowsBlock_ = BellowsBlock;
    class FramedSignItem extends Internal.StandingAndWallBlockItem {
        constructor()
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type FramedSignItem_ = FramedSignItem;
    class LootTableEntry implements Internal.FunctionContainer, Internal.ConditionContainer {
        constructor(o: Internal.JsonObject_)
        enchantWithLevels(levels: Internal.NumberProvider_, treasure: boolean): Internal.FunctionContainer;
        weight(weight: number): this;
        addFunction(arg0: Internal.JsonObject_): Internal.FunctionContainer;
        enchantRandomly(enchantments: ResourceLocation_[]): Internal.FunctionContainer;
        furnaceSmelt(): Internal.FunctionContainer;
        entityProperties(entity: Internal.LootContext$EntityTarget_, properties: Internal.JsonObject_): Internal.ConditionContainer;
        lootingEnchant(count: Internal.NumberProvider_, limit: number): Internal.FunctionContainer;
        addCondition(o: Internal.JsonObject_): this;
        addConditionalFunction(func: Internal.Consumer_<Internal.ConditionalFunction>): Internal.FunctionContainer;
        randomChanceWithLooting(chance: number, multiplier: number): Internal.ConditionContainer;
        randomChance(chance: number): Internal.ConditionContainer;
        name(name: net.minecraft.network.chat.Component_, entity: Internal.LootContext$EntityTarget_): Internal.FunctionContainer;
        killedByPlayer(): Internal.ConditionContainer;
        damage(damage: Internal.NumberProvider_): Internal.FunctionContainer;
        nbt(tag: Internal.CompoundTag_): Internal.FunctionContainer;
        entityScores(entity: Internal.LootContext$EntityTarget_, scores: Internal.Map_<string, any>): Internal.ConditionContainer;
        count(count: Internal.NumberProvider_): Internal.FunctionContainer;
        survivesExplosion(): Internal.ConditionContainer;
        quality(quality: number): this;
        copyName(source: Internal.CopyNameFunction$NameSource_): Internal.FunctionContainer;
        lootTable(table: ResourceLocation_, seed: number): Internal.FunctionContainer;
        name(name: net.minecraft.network.chat.Component_): Internal.FunctionContainer;
        readonly json: Internal.JsonObject;
    }
    type LootTableEntry_ = LootTableEntry;
    class MapLayer {
        constructor(arg0: Internal.MapDimension_, arg1: Internal.RegionHighlightExistenceTracker_)
        tryAddingToCompleteRegionDetection(arg0: Internal.RegionDetection_): void;
        getCaveStart(): number;
        getRegionDetection(arg0: number, arg1: number): Internal.RegionDetection;
        preDetection(): void;
        getCompleteRegionDetection(arg0: number, arg1: number): Internal.RegionDetection;
        getDetectedRegions(): Internal.Hashtable<number, Internal.Hashtable<number, Internal.RegionDetection>>;
        regionDetectionExists(arg0: number, arg1: number): boolean;
        getMapRegions(): Internal.LeveledRegionManager;
        addRegionDetection(arg0: Internal.RegionDetection_): void;
        getLinkedCompleteWorldSaveDetectedRegions(): Internal.Iterable<Internal.RegionDetection>;
        setCaveStart(arg0: number): void;
        getRegionHighlightExistenceTracker(): Internal.RegionHighlightExistenceTracker;
        removeRegionDetection(arg0: number, arg1: number): void;
        get caveStart(): number
        get detectedRegions(): Internal.Hashtable<number, Internal.Hashtable<number, Internal.RegionDetection>>
        get mapRegions(): Internal.LeveledRegionManager
        get linkedCompleteWorldSaveDetectedRegions(): Internal.Iterable<Internal.RegionDetection>
        set caveStart(arg0: number)
        get regionHighlightExistenceTracker(): Internal.RegionHighlightExistenceTracker
    }
    type MapLayer_ = MapLayer;
    abstract class AbstractEntityRaiderMob extends Internal.AbstractFastMinecoloniesEntity implements Internal.Enemy, Internal.IThreatTableEntity {
        constructor(arg0: Internal.EntityType_<Internal.AbstractEntityRaiderMob>, arg1: Internal.Level_)
        getDistance(pos: BlockPos_): number;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        playSound(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        getDifficulty(): number;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        getOffHandItem(): Internal.ItemStack;
        isOnScoreboardTeam(teamId: string): boolean;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        swing(): void;
        getPickedResult(arg0: Internal.HitResult_): Internal.ItemStack;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        canStartSwimming(): boolean;
        isAnimal(): boolean;
        isPlayer(): boolean;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        abstract getSwimSpeedFactor(): number;
        setY(y: number): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isLiving(): boolean;
        getTotalMovementSpeed(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        moveInFluid(arg0: Internal.FluidState_, arg1: Vec3d_, arg2: number): boolean;
        isInFluidType(arg0: Internal.FluidState_): boolean;
        damageHeldItem(): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        shouldUpdateFluidWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        setMotionZ(z: number): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        initStatsFor(arg0: number, arg1: number, arg2: number): void;
        attack(hp: number): void;
        canSwimInFluidType(arg0: Internal.FluidType_): boolean;
        canaryOnEquipmentChanged(): void;
        getTeamId(): string;
        setMaxHealth(hp: number): void;
        canBeRiddenUnderFluidType(arg0: Internal.FluidType_, arg1: Internal.Entity_): boolean;
        getFacing(): Internal.Direction;
        getColony(): Internal.IColony;
        shouldRiderSit(): boolean;
        getLegsArmorItem(): Internal.ItemStack;
        setMainHandItem(item: Internal.ItemStack_): void;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        setStuckCounter(arg0: number): void;
        isInFluidType(arg0: Internal.FluidType_): boolean;
        getReachDistance(): number;
        getFluidMotionScale(arg0: Internal.FluidType_): number;
        getMotionX(): number;
        isWaterCreature(): boolean;
        getThreatTable(): Internal.ThreatTable<any>;
        getItem(): Internal.ItemStack;
        setX(x: number): void;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        setEnvDamageImmunity(arg0: boolean): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        isFrame(): boolean;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        playSound(id: Internal.SoundEvent_): void;
        foodEaten(is: Internal.ItemStack_): void;
        self(): Internal.LivingEntity;
        getDefaultMovementSpeed(): number;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        swing(hand: Internal.InteractionHand_): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        getEventID(): number;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        isPeacefulCreature(): boolean;
        isUndead(): boolean;
        setRotation(yaw: number, pitch: number): void;
        setTempEnvDamageImmunity(arg0: boolean): void;
        getStepHeight(): number;
        isAmbientCreature(): boolean;
        getSoundFromFluidType(arg0: Internal.FluidType_, arg1: Internal.SoundAction_): Internal.SoundEvent;
        isMonster(): boolean;
        canHydrateInFluidType(arg0: Internal.FluidType_): boolean;
        getType(): string;
        static getDefaultAttributes(): Internal.AttributeSupplier$Builder;
        setChestArmorItem(item: Internal.ItemStack_): void;
        self(): Internal.Entity;
        registerWithColony(): void;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        getMotionY(): number;
        getName(): net.minecraft.network.chat.Component;
        getPassengers(): Internal.EntityArrayList;
        setTotalMovementSpeedMultiplier(speed: number): void;
        setColony(arg0: Internal.IColony_): void;
        getFluidFallDistanceModifier(arg0: Internal.FluidType_): number;
        isInFluidType(arg0: Internal.BiPredicate_<Internal.FluidType, number>): boolean;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        canFluidExtinguish(arg0: Internal.FluidType_): boolean;
        abstract getRaiderType(): Internal.RaiderType;
        setLadderCounter(arg0: number): void;
        getStuckCounter(): number;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        isPushedByFluid(arg0: Internal.FluidType_): boolean;
        getFeetArmorItem(): Internal.ItemStack;
        setDefaultMovementSpeed(speed: number): void;
        setOffHandItem(item: Internal.ItemStack_): void;
        sinkInFluid(arg0: Internal.FluidType_): void;
        getMainHandItem(): Internal.ItemStack;
        spawn(): void;
        getServer(): Internal.MinecraftServer;
        setMotionX(x: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        getAI(): Internal.ITickRateStateMachine<Internal.IState>;
        setEnvDamageInterval(arg0: number): void;
        tdv$isDynamicLightEnabled(): boolean;
        setNbt(nbt: Internal.CompoundTag_): void;
        getLevel(): Internal.Level;
        getScriptType(): Internal.ScriptType;
        setMovementSpeedAddition(speed: number): void;
        isMultipartEntity(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        getNavigation(): Internal.AbstractAdvancedPathNavigate;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getLadderCounter(): number;
        getParts(): Internal.PartEntity<any>[];
        setPositionAndRotation(x: number, y: number, z: number, yaw: number, pitch: number): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getEyeHeightForge(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        getMotionZ(): number;
        tell(message: net.minecraft.network.chat.Component_): void;
        serializeNBT(): Internal.CompoundTag;
        setZ(z: number): void;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        isEyeInFluidType(arg0: Internal.FluidType_): boolean;
        getDistanceSq(pos: BlockPos_): number;
        getProfile(): Internal.GameProfile;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        getAttributeBaseValue(attribute: Internal.Attribute_): number;
        getClassification(arg0: boolean): Internal.MobCategory;
        runCommand(command: string): number;
        setEventID(arg0: number): void;
        canDrownInFluidType(arg0: Internal.FluidType_): boolean;
        get difficulty(): number
        set defaultMovementSpeedMultiplier(speed: number)
        get offHandItem(): Internal.ItemStack
        get animal(): boolean
        get player(): boolean
        get swimSpeedFactor(): number
        set y(y: number)
        get living(): boolean
        get totalMovementSpeed(): number
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        set motionZ(z: number)
        get teamId(): string
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get colony(): Internal.IColony
        get legsArmorItem(): Internal.ItemStack
        set mainHandItem(item: Internal.ItemStack_)
        set stuckCounter(arg0: number)
        get reachDistance(): number
        get motionX(): number
        get waterCreature(): boolean
        get threatTable(): Internal.ThreatTable<any>
        get item(): Internal.ItemStack
        set x(x: number)
        set envDamageImmunity(arg0: boolean)
        get potionEffects(): Internal.EntityPotionEffectsJS
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        get defaultMovementSpeed(): number
        set motionY(y: number)
        get eventID(): number
        get peacefulCreature(): boolean
        get undead(): boolean
        set tempEnvDamageImmunity(arg0: boolean)
        get stepHeight(): number
        get ambientCreature(): boolean
        get monster(): boolean
        get type(): string
        get defaultAttributes(): Internal.AttributeSupplier$Builder
        set chestArmorItem(item: Internal.ItemStack_)
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        get motionY(): number
        get name(): net.minecraft.network.chat.Component
        get passengers(): Internal.EntityArrayList
        set totalMovementSpeedMultiplier(speed: number)
        set colony(arg0: Internal.IColony_)
        get raiderType(): Internal.RaiderType
        set ladderCounter(arg0: number)
        get stuckCounter(): number
        get feetArmorItem(): Internal.ItemStack
        set defaultMovementSpeed(speed: number)
        set offHandItem(item: Internal.ItemStack_)
        get mainHandItem(): Internal.ItemStack
        get server(): Internal.MinecraftServer
        set motionX(x: number)
        get AI(): Internal.ITickRateStateMachine<Internal.IState>
        set envDamageInterval(arg0: number)
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        get scriptType(): Internal.ScriptType
        set movementSpeedAddition(speed: number)
        get multipartEntity(): boolean
        get headArmorItem(): Internal.ItemStack
        get navigation(): Internal.AbstractAdvancedPathNavigate
        set feetArmorItem(item: Internal.ItemStack_)
        get ladderCounter(): number
        get parts(): Internal.PartEntity<any>[]
        get chestArmorItem(): Internal.ItemStack
        get motionZ(): number
        set z(z: number)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get profile(): Internal.GameProfile
        set headArmorItem(item: Internal.ItemStack_)
        set eventID(arg0: number)
    }
    type AbstractEntityRaiderMob_ = AbstractEntityRaiderMob;
    class CherryLeavesBlock extends Internal.LeavesBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isShearable(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: BlockPos_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        onSheared(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.Level_, arg3: BlockPos_, arg4: number): Internal.List<Internal.ItemStack>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type CherryLeavesBlock_ = CherryLeavesBlock;
    interface LootItemCondition$Builder {
        and(arg0: Internal.LootItemCondition$Builder_): Internal.AllOfCondition$Builder;
        abstract build(): Internal.LootItemCondition;
        invert(): this;
        or(arg0: Internal.LootItemCondition$Builder_): Internal.AnyOfCondition$Builder;
        (): Internal.LootItemCondition_;
    }
    type LootItemCondition$Builder_ = LootItemCondition$Builder;
    class FramedFlowerPotBlock extends Internal.FramedBlock {
        constructor()
        shouldPreventNeighborCulling(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.BlockState_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        isSuffocating(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getCamoOcclusionShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): Internal.VoxelShape;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canCamoSustainPlant(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.IPlantable_): boolean;
        static createProperties(arg0: Internal.IBlockType_): Internal.BlockBehaviour$Properties;
        getCamoShadeBrightness(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: number): number;
        getCamoDrops(arg0: Internal.List_<Internal.ItemStack>, arg1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        static toggleYSlope(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        handleUse(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: Internal.InteractionHand_, arg5: Internal.BlockHitResult_): Internal.InteractionResult;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        updateShapeLockable(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Supplier_<Internal.BlockState>): Internal.BlockState;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        tryApplyCamoImmediately(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.LivingEntity_, arg3: Internal.ItemStack_): void;
        isIntangible(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): boolean;
        lockState(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Player_, arg3: Internal.ItemStack_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.BlockHitResult_, arg2: Internal.Rotation_): Internal.BlockState;
        updateCulling(arg0: Internal.LevelReader_, arg1: BlockPos_): void;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getCamoVisualShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): Internal.VoxelShape;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        handleBlockLeftClick(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        playBreakSound(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        static playCamoBreakSound(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_): void;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        initCache(arg0: Internal.BlockState_): Internal.StateCache;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        runOcclusionTestAndGetLookupState(arg0: Internal.SideSkipPredicate_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.BlockState_, arg5: Internal.Direction_): Internal.BlockState;
        createBlockItem(): Internal.BlockItem;
        static getFlowerPotState(arg0: Internal.Block_): Internal.BlockState;
        printCamoBlock(arg0: Internal.CompoundTag_): Internal.Optional<Internal.MutableComponent>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        needCullingUpdateAfterStateChange(arg0: Internal.LevelReader_, arg1: Internal.BlockState_, arg2: Internal.BlockState_): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getCache(arg0: Internal.BlockState_): Internal.StateCache;
        rotate(arg0: Internal.BlockState_, arg1: Internal.Direction_, arg2: Internal.Rotation_): Internal.BlockState;
        useCamoOcclusionShapeForLightOcclusion(arg0: Internal.BlockState_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type FramedFlowerPotBlock_ = FramedFlowerPotBlock;
    class VineBlock extends Internal.Block implements Internal.IForgeShearable {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isShearable(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: BlockPos_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        canSupportAtFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Direction_): boolean;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        static getPropertyForFace(arg0: Internal.Direction_): Internal.BooleanProperty;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        onSheared(arg0: Internal.Player_, arg1: Internal.ItemStack_, arg2: Internal.Level_, arg3: BlockPos_, arg4: number): Internal.List<Internal.ItemStack>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        static isAcceptableNeighbour(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Direction_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly NORTH: Internal.BooleanProperty;
        static readonly PROPERTY_BY_DIRECTION: {[key: Internal.Direction]: Internal.BooleanProperty, [key: Internal.Direction]: Internal.BooleanProperty, [key: Internal.Direction]: Internal.BooleanProperty, [key: Internal.Direction]: Internal.BooleanProperty, [key: Internal.Direction]: Internal.BooleanProperty};
        static readonly UP: Internal.BooleanProperty;
        static readonly SOUTH: Internal.BooleanProperty;
        static readonly WEST: Internal.BooleanProperty;
        static readonly EAST: Internal.BooleanProperty;
    }
    type VineBlock_ = VineBlock;
    class AdvancementBasedRobitSkin extends Internal.Record implements Internal.RobitSkin {
        constructor(arg0: Internal.List_<ResourceLocation>, arg1: ResourceLocation_)
        constructor(textures: Internal.List_<ResourceLocation>, customModel: ResourceLocation_, advancement: ResourceLocation_)
        advancement(): ResourceLocation;
        static getTranslationKey(arg0: Internal.ResourceKey_<Internal.RobitSkin>): string;
        customModel(): ResourceLocation;
        codec(): Internal.Codec<Internal.RobitSkin>;
        isUnlocked(arg0: Internal.Player_): boolean;
        textures(): Internal.List<ResourceLocation>;
        static getTranslatedName(arg0: Internal.ResourceKey_<Internal.RobitSkin>): net.minecraft.network.chat.Component;
    }
    type AdvancementBasedRobitSkin_ = AdvancementBasedRobitSkin;
    interface Byte2CharFunction extends Internal.IntUnaryOperator, it.unimi.dsi.fastutil.Function<number, string> {
        getOrDefault(arg0: number, arg1: string): string;
        abstract get(arg0: number): string;
        composeObject<T>(arg0: Internal.Object2ByteFunction_<T>): Internal.Object2CharFunction<T>;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: string): string;
        /**
         * @deprecated
        */
        getOrDefault(arg0: any, arg1: any): any;
        defaultReturnValue(): string;
        andThenLong(arg0: Internal.Char2LongFunction_): Internal.Byte2LongFunction;
        andThen(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        composeChar(arg0: Internal.Char2ByteFunction_): Internal.Char2CharFunction;
        andThenFloat(arg0: Internal.Char2FloatFunction_): Internal.Byte2FloatFunction;
        /**
         * @deprecated
        */
        remove(arg0: any): string;
        /**
         * @deprecated
        */
        containsKey(arg0: any): boolean;
        andThenByte(arg0: Internal.Char2ByteFunction_): Internal.Byte2ByteFunction;
        composeByte(arg0: Internal.Byte2ByteFunction_): this;
        compose(arg0: Internal.IntUnaryOperator_): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        applyAsInt(arg0: number): number;
        defaultReturnValue(arg0: string): void;
        identity(): Internal.IntUnaryOperator;
        /**
         * @deprecated
        */
        get(arg0: any): string;
        /**
         * @deprecated
        */
        put(arg0: any, arg1: any): any;
        /**
         * @deprecated
        */
        compose<T>(arg0: Internal.Function_<T, number>): Internal.Function<T, string>;
        containsKey(arg0: number): boolean;
        andThenInt(arg0: Internal.Char2IntFunction_): Internal.Byte2IntFunction;
        composeShort(arg0: Internal.Short2ByteFunction_): Internal.Short2CharFunction;
        andThenDouble(arg0: Internal.Char2DoubleFunction_): Internal.Byte2DoubleFunction;
        /**
         * @deprecated
        */
        andThen<T>(arg0: Internal.Function_<string, T>): Internal.Function<number, T>;
        remove(arg0: number): string;
        composeDouble(arg0: Internal.Double2ByteFunction_): Internal.Double2CharFunction;
        andThenReference<T>(arg0: Internal.Char2ReferenceFunction_<T>): Internal.Byte2ReferenceFunction<T>;
        composeInt(arg0: Internal.Int2ByteFunction_): Internal.Int2CharFunction;
        andThenChar(arg0: Internal.Char2CharFunction_): this;
        andThenObject<T>(arg0: Internal.Char2ObjectFunction_<T>): Internal.Byte2ObjectFunction<T>;
        size(): number;
        composeReference<T>(arg0: Internal.Reference2ByteFunction_<T>): Internal.Reference2CharFunction<T>;
        composeFloat(arg0: Internal.Float2ByteFunction_): Internal.Float2CharFunction;
        clear(): void;
        /**
         * @deprecated
        */
        put(arg0: number, arg1: string): string;
        apply(arg0: number): string;
        composeLong(arg0: Internal.Long2ByteFunction_): Internal.Long2CharFunction;
        put(arg0: number, arg1: string): string;
        andThenShort(arg0: Internal.Char2ShortFunction_): Internal.Byte2ShortFunction;
        (arg0: number): string;
    }
    type Byte2CharFunction_ = Byte2CharFunction;
    class SoftFluidStack {
        constructor(fluid: Internal.Holder_<Internal.SoftFluid>)
        constructor(fluid: Internal.Holder_<Internal.SoftFluid>, count: number, tag: Internal.CompoundTag_)
        constructor(fluid: Internal.Holder_<Internal.SoftFluid>, count: number)
        setTag(tag: Internal.CompoundTag_): void;
        static load(tag: Internal.CompoundTag_): Internal.SoftFluidStack;
        getCount(): number;
        isEmpty(): boolean;
        save(compoundTag: Internal.CompoundTag_): Internal.CompoundTag;
        getTintMethod(): Internal.SoftFluid$TintMethod;
        is(fluid: Internal.Holder_<Internal.SoftFluid>): boolean;
        shrink(amount: number): void;
        is(fluid: Internal.SoftFluid_): boolean;
        static fromItem(itemStack: Internal.ItemStack_): Internal.Pair<Internal.SoftFluidStack, Internal.FluidContainerList$Category>;
        split(amount: number): this;
        getVanillaFluid(): Internal.Fluid;
        static fromFluid(fluid: Internal.Fluid_, amount: number, tag: Internal.CompoundTag_): Internal.SoftFluidStack;
        toItem(emptyContainer: Internal.ItemStack_, dontModifyStack: boolean): Internal.Pair<Internal.ItemStack, Internal.FluidContainerList$Category>;
        static empty(): Internal.SoftFluidStack;
        isFluidStackTagEqual(other: Internal.SoftFluidStack_): boolean;
        getFoodProvider(): Internal.FoodProvider;
        setCount(count: number): void;
        is(tag: Internal.TagKey_<Internal.SoftFluid>): boolean;
        getContainerList(): Internal.FluidContainerList;
        addTagElement(key: string, tag: Internal.Tag_): void;
        getOrCreateTag(): Internal.CompoundTag;
        copyWithCount(count: number): this;
        isFluidEqual(other: Internal.SoftFluidStack_): boolean;
        hasTag(): boolean;
        getTag(): Internal.CompoundTag;
        getOrCreateTagElement(key: string): Internal.CompoundTag;
        getFluid(): Internal.Holder<Internal.SoftFluid>;
        isEquivalent(fluid: Internal.Fluid_): boolean;
        copy(): this;
        grow(amount: number): void;
        set tag(tag: Internal.CompoundTag_)
        get count(): number
        get empty(): boolean
        get tintMethod(): Internal.SoftFluid$TintMethod
        get vanillaFluid(): Internal.Fluid
        get foodProvider(): Internal.FoodProvider
        set count(count: number)
        get containerList(): Internal.FluidContainerList
        get orCreateTag(): Internal.CompoundTag
        get tag(): Internal.CompoundTag
        get fluid(): Internal.Holder<Internal.SoftFluid>
    }
    type SoftFluidStack_ = SoftFluidStack;
    interface IQuestGiver extends Internal.IQuestParticipant {
        abstract getName(): string;
        abstract onQuestDeletion(arg0: ResourceLocation_): void;
        abstract assignQuest(arg0: Internal.IQuestInstance_): void;
        abstract openDialogue(arg0: Internal.IQuestInstance_, arg1: number): void;
        abstract addQuestParticipation(arg0: Internal.IQuestInstance_): void;
        abstract isParticipantOfQuest(arg0: ResourceLocation_): boolean;
        get name(): string
    }
    type IQuestGiver_ = IQuestGiver;
    class ItemFrameItem extends Internal.HangingEntityItem {
        constructor(arg0: Internal.EntityType_<Internal.HangingEntity>, arg1: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ItemFrameItem_ = ItemFrameItem;
    class SaplingBlockBOP extends Internal.SaplingBlock implements Internal.BonemealableBlock {
        constructor(arg0: any_, arg1: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getPlantType(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.PlantType;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        m_7926_(arg0: Internal.StateDefinition$Builder_<Internal.Block, Internal.BlockState>): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly STAGE: Internal.IntegerProperty;
        static readonly SHAPE: Internal.VoxelShapeAlignedCuboid;
    }
    type SaplingBlockBOP_ = SaplingBlockBOP;
    abstract class RaytracingUtil {
        constructor()
        getEntityParams(arg0: Internal.Entity_): org.apache.commons.lang3.tuple.Pair<Vec3d, Vec3d>;
        rayTrace(arg0: Internal.Entity_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: Internal.ClipContext$Block_, arg4: Internal.ClipContext$Fluid_): Internal.HitResult;
        rayTrace(arg0: Internal.Entity_, arg1: Internal.Level_, arg2: Vec3d_, arg3: Vec3d_, arg4: Internal.ClipContext$Block_, arg5: Internal.ClipContext$Fluid_): Internal.HitResult;
        abstract getEntityRange(arg0: Internal.LivingEntity_): number;
        rayTrace(arg0: Internal.Entity_, arg1: Internal.Level_, arg2: Internal.Entity_, arg3: Internal.ClipContext$Block_, arg4: Internal.ClipContext$Fluid_, arg5: number): Internal.HitResult;
        rayTrace(arg0: Internal.Entity_, arg1: Internal.Level_, arg2: Vec3d_, arg3: Vec3d_, arg4: Internal.ClipContext$Block_, arg5: Internal.ClipContext$Fluid_, arg6: number): Internal.HitResult;
    }
    type RaytracingUtil_ = RaytracingUtil;
    interface IGenerallySearchableNavigation$PointTest {
        abstract test(arg0: number, arg1: number, arg2: Internal.Map_<Internal.TrackEdge, com.simibubi.create.foundation.utility.Pair<boolean, Internal.Couple<Internal.TrackNode>>>, arg3: com.simibubi.create.foundation.utility.Pair_<Internal.Couple<Internal.TrackNode>, Internal.TrackEdge>, arg4: Internal.TrackEdgePoint_): boolean;
        (arg0: number, arg1: number, arg2: Internal.Map<Internal.TrackEdge, com.simibubi.create.foundation.utility.Pair<boolean, Internal.Couple<Internal.TrackNode>>>, arg3: com.simibubi.create.foundation.utility.Pair<Internal.Couple<Internal.TrackNode>, Internal.TrackEdge>, arg4: Internal.TrackEdgePoint): boolean;
    }
    type IGenerallySearchableNavigation$PointTest_ = IGenerallySearchableNavigation$PointTest;
    class FakeTrackBlock extends Internal.Block implements Internal.ProperWaterloggedBlock, Internal.EntityBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        fluidState(arg0: Internal.BlockState_): Internal.FluidState;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        static keepAlive(arg0: Internal.LevelAccessor_, arg1: BlockPos_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        updateWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        static withWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): Internal.BlockState;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        withWater(arg0: Internal.BlockState_, arg1: Internal.BlockPlaceContext_): Internal.BlockState;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type FakeTrackBlock_ = FakeTrackBlock;
    class RefillUpgradeItem extends Internal.UpgradeItemBase<Internal.RefillUpgradeWrapper> {
        constructor(arg0: Internal.IntSupplier_, arg1: boolean, arg2: boolean)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        allowsTargetSlotSelection(): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        getFilterSlotCount(): number;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        getCleanedUpgradeStack(arg0: Internal.ItemStack_): Internal.ItemStack;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        getInventoryColumnsTaken(): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        getType(): Internal.UpgradeType<Internal.RefillUpgradeWrapper>;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canAddUpgradeTo(arg0: Internal.IStorageWrapper_, arg1: Internal.ItemStack_, arg2: boolean, arg3: boolean): Internal.UpgradeSlotChangeResult;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        supportsBlockPick(): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getUpgradeGroup(): Internal.UpgradeGroup;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        canRemoveUpgradeFrom(arg0: Internal.IStorageWrapper_, arg1: boolean): Internal.UpgradeSlotChangeResult;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        canSwapUpgradeFor(arg0: Internal.ItemStack_, arg1: Internal.IStorageWrapper_, arg2: boolean): Internal.UpgradeSlotChangeResult;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        get filterSlotCount(): number
        set attackSpeed(attackSpeed: number)
        get inventoryColumnsTaken(): number
        get creativeTab(): string
        get type(): Internal.UpgradeType<Internal.RefillUpgradeWrapper>
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get upgradeGroup(): Internal.UpgradeGroup
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type RefillUpgradeItem_ = RefillUpgradeItem;
    class SequencerInstructions extends Internal.Enum<Internal.SequencerInstructions> {
        static values(): Internal.SequencerInstructions[];
        static valueOf(arg0: string): Internal.SequencerInstructions;
        needsPropagation(): boolean;
        static readonly TURN_ANGLE: Internal.SequencerInstructions;
        static readonly TURN_DISTANCE: Internal.SequencerInstructions;
        static readonly AWAIT: Internal.SequencerInstructions;
        static readonly END: Internal.SequencerInstructions;
        static readonly DELAY: Internal.SequencerInstructions;
    }
    type SequencerInstructions_ = "turn_angle" | "end" | "await" | "delay" | "turn_distance" | SequencerInstructions;
    class LevelStem extends Internal.Record {
        constructor(arg0: Internal.Holder_<Internal.DimensionType>, arg1: Internal.ChunkGenerator_)
        generator(): Internal.ChunkGenerator;
        type(): Internal.Holder<Internal.DimensionType>;
        static readonly OVERWORLD: Internal.ResourceKey<Internal.LevelStem>;
        static readonly END: Internal.ResourceKey<Internal.LevelStem>;
        static readonly CODEC: Internal.Codec<Internal.LevelStem>;
        static readonly NETHER: Internal.ResourceKey<Internal.LevelStem>;
    }
    type LevelStem_ = Special.Dimension | LevelStem;
    class BlockRadioactiveWasteBarrel extends Internal.BlockTile$BlockTileModel<Internal.TileEntityRadioactiveWasteBarrel, Internal.BlockTypeTile<Internal.TileEntityRadioactiveWasteBarrel>> {
        constructor()
        updateFluids(state: Internal.BlockState_, world: Internal.LevelAccessor_, currentPos: BlockPos_): void;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        createDummyBlockEntity(state: Internal.BlockState_): Internal.TileEntityRadioactiveWasteBarrel;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getFluidLoggedProperty(): Internal.EnumProperty<Internal.IFluidLogType>;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getTicker<T extends Internal.BlockEntity>(level: Internal.Level_, state: Internal.BlockState_, blockEntityType: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        setState(state: Internal.BlockState_, fluid: Internal.Fluid_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        isValidFluid(fluid: Internal.Fluid_): boolean;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(world: Internal.LevelAccessor_, pos: BlockPos_, state: Internal.BlockState_, fluidState: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        createDummyBlockEntity(): Internal.TileEntityRadioactiveWasteBarrel;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(state: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(world: Internal.BlockGetter_, pos: BlockPos_, state: Internal.BlockState_, fluid: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(world: Internal.LevelAccessor_, pos: BlockPos_, state: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        newBlockEntity(pos: BlockPos_, state: Internal.BlockState_): Internal.TileEntityRadioactiveWasteBarrel;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        triggerBlockEntityEvent(state: Internal.BlockState_, level: Internal.Level_, pos: BlockPos_, id: number, param: number): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getFluidLightLevel(state: Internal.BlockState_): number;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getFluid(state: Internal.BlockState_): Internal.FluidState;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get fluidLoggedProperty(): Internal.EnumProperty<Internal.IFluidLogType>
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type BlockRadioactiveWasteBarrel_ = BlockRadioactiveWasteBarrel;
    interface IUsageGPU {
        abstract embPlus$getSyncGpu(): number;
        (): number;
    }
    type IUsageGPU_ = IUsageGPU;
    class FramedVerticalDividedStairsBlock extends Internal.AbstractFramedDoubleBlock {
        constructor()
        shouldPreventNeighborCulling(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.BlockState_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getTopInteractionMode(arg0: Internal.BlockState_): Internal.DoubleBlockTopInteractionMode;
        isSuffocating(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getCamoOcclusionShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): Internal.VoxelShape;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        canCamoSustainPlant(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.IPlantable_): boolean;
        static createProperties(arg0: Internal.IBlockType_): Internal.BlockBehaviour$Properties;
        getCamoShadeBrightness(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: number): number;
        getCamoDrops(arg0: Internal.List_<Internal.ItemStack>, arg1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        static toggleYSlope(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        handleUse(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: Internal.InteractionHand_, arg5: Internal.BlockHitResult_): Internal.InteractionResult;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        updateShapeLockable(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Supplier_<Internal.BlockState>): Internal.BlockState;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        tryApplyCamoImmediately(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.LivingEntity_, arg3: Internal.ItemStack_): void;
        isIntangible(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): boolean;
        lockState(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Player_, arg3: Internal.ItemStack_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getSolidityCheck(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.SolidityCheck;
        rotate(arg0: Internal.BlockState_, arg1: Internal.BlockHitResult_, arg2: Internal.Rotation_): Internal.BlockState;
        updateCulling(arg0: Internal.LevelReader_, arg1: BlockPos_): void;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getCamoVisualShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): Internal.VoxelShape;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        static generateShapes(arg0: Internal.ImmutableList_<Internal.BlockState>): Internal.ShapeProvider;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        handleBlockLeftClick(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockPair(arg0: Internal.BlockState_): Internal.Tuple<Internal.BlockState, Internal.BlockState>;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        static playCamoBreakSound(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_): void;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        initCache(arg0: Internal.BlockState_): Internal.StateCache;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getCamoGetter(arg0: Internal.BlockState_, arg1: Internal.Direction_, arg2: Internal.Direction_): Internal.CamoGetter;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        createBlockItem(): Internal.BlockItem;
        printCamoBlock(arg0: Internal.CompoundTag_): Internal.Optional<Internal.MutableComponent>;
        doesBlockOccludeBeaconBeam(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        needCullingUpdateAfterStateChange(arg0: Internal.LevelReader_, arg1: Internal.BlockState_, arg2: Internal.BlockState_): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getCache(arg0: Internal.BlockState_): Internal.StateCache;
        rotate(arg0: Internal.BlockState_, arg1: Internal.Direction_, arg2: Internal.Rotation_): Internal.BlockState;
        useCamoOcclusionShapeForLightOcclusion(arg0: Internal.BlockState_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type FramedVerticalDividedStairsBlock_ = FramedVerticalDividedStairsBlock;
    class ListTag extends Internal.CollectionTag<Internal.Tag> {
        constructor()
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E): Internal.List<E>;
        getDouble(arg0: number): number;
        static copyOf<E>(arg0: Internal.Collection_<E>): Internal.List<E>;
        get(arg0: number): Internal.Tag;
        set(arg0: number, arg1: Internal.Tag_): Internal.Tag;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E): Internal.List<E>;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E): Internal.List<E>;
        getCompound(arg0: number): Internal.CompoundTag;
        copy(): this;
        getShort(arg0: number): number;
        static of<E>(arg0: E): Internal.List<E>;
        static of<E>(): Internal.List<E>;
        static of<E>(...arg0: E[]): Internal.List<E>;
        acceptAsRoot(arg0: Internal.StreamTagVisitor_): void;
        getFloat(arg0: number): number;
        toArray<T>(arg0: Internal.IntFunction_<T[]>): T[];
        getIntArray(arg0: number): number[];
        getLongArray(arg0: number): number[];
        getList(arg0: number): this;
        getInt(arg0: number): number;
        sort(arg0: Internal.Comparator_<Internal.Tag>): void;
        stream(): Internal.Stream<Internal.Tag>;
        getString(arg0: number): string;
        spliterator(): Internal.Spliterator<Internal.Tag>;
        replaceAll(arg0: Internal.UnaryOperator_<Internal.Tag>): void;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E): Internal.List<E>;
        getType(): Internal.TagType<Internal.ListTag>;
        static of<E>(arg0: E, arg1: E, arg2: E): Internal.List<E>;
        forEach(arg0: Internal.Consumer_<Internal.Tag>): void;
        abstract toArray<T>(arg0: T[]): T[];
        remove(arg0: number): Internal.Tag;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E): Internal.List<E>;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E, arg4: E, arg5: E, arg6: E, arg7: E, arg8: E, arg9: E): Internal.List<E>;
        parallelStream(): Internal.Stream<Internal.Tag>;
        getAsString(): string;
        static of<E>(arg0: E, arg1: E): Internal.List<E>;
        removeIf(arg0: Internal.Predicate_<Internal.Tag>): boolean;
        static of<E>(arg0: E, arg1: E, arg2: E, arg3: E): Internal.List<E>;
        get type(): Internal.TagType<Internal.ListTag>
        get asString(): string
        static readonly TYPE: Internal.TagType<Internal.ListTag>;
    }
    type ListTag_ = ListTag;
    class GlowSquid extends Internal.Squid {
        constructor(arg0: Internal.EntityType_<Internal.GlowSquid>, arg1: Internal.Level_)
        static checkGlowSquideSpawnRules(arg0: Internal.EntityType_<Internal.LivingEntity>, arg1: Internal.ServerLevelAccessor_, arg2: Internal.MobSpawnType_, arg3: BlockPos_, arg4: Internal.RandomSource_): boolean;
        getDistance(pos: BlockPos_): number;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number): void;
        removeAttribute(attribute: Internal.Attribute_, identifier: string): void;
        playSound(id: Internal.SoundEvent_, volume: number, pitch: number): void;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        setDefaultMovementSpeedMultiplier(speed: number): void;
        getOffHandItem(): Internal.ItemStack;
        isOnScoreboardTeam(teamId: string): boolean;
        getEquipment(slot: Internal.EquipmentSlot_): Internal.ItemStack;
        swing(): void;
        getPickedResult(arg0: Internal.HitResult_): Internal.ItemStack;
        setPosition(x: number, y: number, z: number): void;
        runCommandSilent(command: string): number;
        canStartSwimming(): boolean;
        isAnimal(): boolean;
        isPlayer(): boolean;
        rayTrace(distance: number, fluids: boolean): Internal.RayTraceResultJS;
        setY(y: number): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        damageEquipment(slot: Internal.EquipmentSlot_): void;
        isLiving(): boolean;
        getDarkTicksRemaining(): number;
        getTotalMovementSpeed(): number;
        rayTrace(): Internal.RayTraceResultJS;
        alwaysAccepts(): boolean;
        moveInFluid(arg0: Internal.FluidState_, arg1: Vec3d_, arg2: number): boolean;
        isInFluidType(arg0: Internal.FluidState_): boolean;
        damageHeldItem(): void;
        getDisplayName(): net.minecraft.network.chat.Component;
        shouldUpdateFluidWhileBoating(arg0: Internal.FluidState_, arg1: Internal.Boat_): boolean;
        setPosition(block: Internal.BlockContainerJS_): void;
        setMotionZ(z: number): void;
        mergeNbt(tag: Internal.CompoundTag_): Internal.Entity;
        attack(hp: number): void;
        canSwimInFluidType(arg0: Internal.FluidType_): boolean;
        canaryOnEquipmentChanged(): void;
        getTeamId(): string;
        setMaxHealth(hp: number): void;
        canBeRiddenUnderFluidType(arg0: Internal.FluidType_, arg1: Internal.Entity_): boolean;
        getFacing(): Internal.Direction;
        shouldRiderSit(): boolean;
        getLegsArmorItem(): Internal.ItemStack;
        setMainHandItem(item: Internal.ItemStack_): void;
        isHoldingInAnyHand(i: Internal.Ingredient_): boolean;
        rayTrace(distance: number): Internal.RayTraceResultJS;
        isInFluidType(arg0: Internal.FluidType_): boolean;
        getReachDistance(): number;
        getFluidMotionScale(arg0: Internal.FluidType_): number;
        getMotionX(): number;
        isWaterCreature(): boolean;
        getItem(): Internal.ItemStack;
        setX(x: number): void;
        setAttributeBaseValue(attribute: Internal.Attribute_, value: number): void;
        getPotionEffects(): Internal.EntityPotionEffectsJS;
        isFrame(): boolean;
        setLegsArmorItem(item: Internal.ItemStack_): void;
        playSound(id: Internal.SoundEvent_): void;
        foodEaten(is: Internal.ItemStack_): void;
        self(): Internal.LivingEntity;
        getDefaultMovementSpeed(): number;
        getHeldItem(hand: Internal.InteractionHand_): Internal.ItemStack;
        swing(hand: Internal.InteractionHand_): void;
        getDistance(x: number, y: number, z: number): number;
        setMotionY(y: number): void;
        getAttributeTotalValue(attribute: Internal.Attribute_): number;
        isPeacefulCreature(): boolean;
        isUndead(): boolean;
        setRotation(yaw: number, pitch: number): void;
        getStepHeight(): number;
        isAmbientCreature(): boolean;
        getSoundFromFluidType(arg0: Internal.FluidType_, arg1: Internal.SoundAction_): Internal.SoundEvent;
        isMonster(): boolean;
        canHydrateInFluidType(arg0: Internal.FluidType_): boolean;
        getType(): string;
        setChestArmorItem(item: Internal.ItemStack_): void;
        self(): Internal.Entity;
        getBlock(): Internal.BlockContainerJS;
        getNbt(): Internal.CompoundTag;
        setEquipment(slot: Internal.EquipmentSlot_, item: Internal.ItemStack_): void;
        getMotionY(): number;
        getName(): net.minecraft.network.chat.Component;
        getPassengers(): Internal.EntityArrayList;
        setTotalMovementSpeedMultiplier(speed: number): void;
        getFluidFallDistanceModifier(arg0: Internal.FluidType_): number;
        isInFluidType(arg0: Internal.BiPredicate_<Internal.FluidType, number>): boolean;
        setHeldItem(hand: Internal.InteractionHand_, item: Internal.ItemStack_): void;
        canFluidExtinguish(arg0: Internal.FluidType_): boolean;
        damageHeldItem(hand: Internal.InteractionHand_, amount: number, onBroken: Internal.Consumer_<Internal.ItemStack>): void;
        isPushedByFluid(arg0: Internal.FluidType_): boolean;
        getFeetArmorItem(): Internal.ItemStack;
        setDefaultMovementSpeed(speed: number): void;
        setOffHandItem(item: Internal.ItemStack_): void;
        sinkInFluid(arg0: Internal.FluidType_): void;
        getMainHandItem(): Internal.ItemStack;
        spawn(): void;
        getServer(): Internal.MinecraftServer;
        setMotionX(x: number): void;
        canEntityBeSeen(entity: Internal.LivingEntity_): boolean;
        teleportTo(dimension: ResourceLocation_, x: number, y: number, z: number, yaw: number, pitch: number): void;
        tdv$isDynamicLightEnabled(): boolean;
        setNbt(nbt: Internal.CompoundTag_): void;
        getLevel(): Internal.Level;
        getScriptType(): Internal.ScriptType;
        setMovementSpeedAddition(speed: number): void;
        isMultipartEntity(): boolean;
        getHeadArmorItem(): Internal.ItemStack;
        modifyAttribute(attribute: Internal.Attribute_, identifier: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        setFeetArmorItem(item: Internal.ItemStack_): void;
        getParts(): Internal.PartEntity<any>[];
        setPositionAndRotation(x: number, y: number, z: number, yaw: number, pitch: number): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        getEyeHeightForge(arg0: Internal.Pose_, arg1: Internal.EntityDimensions_): number;
        deserializeNBT(arg0: Internal.Tag_): void;
        getChestArmorItem(): Internal.ItemStack;
        damageEquipment(slot: Internal.EquipmentSlot_, amount: number): void;
        getMotionZ(): number;
        tell(message: net.minecraft.network.chat.Component_): void;
        serializeNBT(): Internal.CompoundTag;
        setZ(z: number): void;
        setStatusMessage(message: net.minecraft.network.chat.Component_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        isEyeInFluidType(arg0: Internal.FluidType_): boolean;
        getDistanceSq(pos: BlockPos_): number;
        getProfile(): Internal.GameProfile;
        setHeadArmorItem(item: Internal.ItemStack_): void;
        getAttributeBaseValue(attribute: Internal.Attribute_): number;
        getClassification(arg0: boolean): Internal.MobCategory;
        runCommand(command: string): number;
        canDrownInFluidType(arg0: Internal.FluidType_): boolean;
        set defaultMovementSpeedMultiplier(speed: number)
        get offHandItem(): Internal.ItemStack
        get animal(): boolean
        get player(): boolean
        set y(y: number)
        get living(): boolean
        get darkTicksRemaining(): number
        get totalMovementSpeed(): number
        get displayName(): net.minecraft.network.chat.Component
        set position(block: Internal.BlockContainerJS_)
        set motionZ(z: number)
        get teamId(): string
        set maxHealth(hp: number)
        get facing(): Internal.Direction
        get legsArmorItem(): Internal.ItemStack
        set mainHandItem(item: Internal.ItemStack_)
        get reachDistance(): number
        get motionX(): number
        get waterCreature(): boolean
        get item(): Internal.ItemStack
        set x(x: number)
        get potionEffects(): Internal.EntityPotionEffectsJS
        get frame(): boolean
        set legsArmorItem(item: Internal.ItemStack_)
        get defaultMovementSpeed(): number
        set motionY(y: number)
        get peacefulCreature(): boolean
        get undead(): boolean
        get stepHeight(): number
        get ambientCreature(): boolean
        get monster(): boolean
        get type(): string
        set chestArmorItem(item: Internal.ItemStack_)
        get block(): Internal.BlockContainerJS
        get nbt(): Internal.CompoundTag
        get motionY(): number
        get name(): net.minecraft.network.chat.Component
        get passengers(): Internal.EntityArrayList
        set totalMovementSpeedMultiplier(speed: number)
        get feetArmorItem(): Internal.ItemStack
        set defaultMovementSpeed(speed: number)
        set offHandItem(item: Internal.ItemStack_)
        get mainHandItem(): Internal.ItemStack
        get server(): Internal.MinecraftServer
        set motionX(x: number)
        set nbt(nbt: Internal.CompoundTag_)
        get level(): Internal.Level
        get scriptType(): Internal.ScriptType
        set movementSpeedAddition(speed: number)
        get multipartEntity(): boolean
        get headArmorItem(): Internal.ItemStack
        set feetArmorItem(item: Internal.ItemStack_)
        get parts(): Internal.PartEntity<any>[]
        get chestArmorItem(): Internal.ItemStack
        get motionZ(): number
        set z(z: number)
        set statusMessage(message: net.minecraft.network.chat.Component_)
        get profile(): Internal.GameProfile
        set headArmorItem(item: Internal.ItemStack_)
    }
    type GlowSquid_ = GlowSquid;
    interface IPart extends Internal.ICustomCableConnection, Internal.Clearable {
        writeVisualStateToNBT(arg0: Internal.CompoundTag_): void;
        addAdditionalDrops(arg0: Internal.List_<Internal.ItemStack>, arg1: boolean): void;
        readFromStream(arg0: Internal.FriendlyByteBuf_): boolean;
        tryClear(arg0: any): void;
        abstract getPartItem(): Internal.IPartItem<any>;
        onShiftActivate(arg0: Internal.Player_, arg1: Internal.InteractionHand_, arg2: Vec3d_): boolean;
        writeToNBT(arg0: Internal.CompoundTag_): void;
        onUpdateShape(arg0: Internal.Direction_): void;
        isProvidingStrongPower(): number;
        exportSettings(arg0: Internal.SettingsFrom_, arg1: Internal.CompoundTag_): void;
        importSettings(arg0: Internal.SettingsFrom_, arg1: Internal.CompoundTag_, arg2: Internal.Player_): void;
        onPlacement(arg0: Internal.Player_): void;
        renderDynamic(arg0: number, arg1: Internal.PoseStack_, arg2: Internal.MultiBufferSource_, arg3: number, arg4: number): void;
        addEntityCrashInfo(arg0: Internal.CrashReportCategory_): void;
        abstract getGridNode(): Internal.IGridNode;
        isSolid(): boolean;
        onActivate(arg0: Internal.Player_, arg1: Internal.InteractionHand_, arg2: Vec3d_): boolean;
        addToWorld(): void;
        readFromNBT(arg0: Internal.CompoundTag_): void;
        onEntityCollision(arg0: Internal.Entity_): void;
        abstract getBoxes(arg0: Internal.IPartCollisionHelper_): void;
        getLightLevel(): number;
        getDesiredConnectionType(): Internal.AECableType;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        getExternalFacingNode(): Internal.IGridNode;
        onClicked(arg0: Internal.Player_, arg1: Vec3d_): boolean;
        abstract getCableConnectionLength(arg0: Internal.AECableType_): number;
        onNeighborChanged(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: BlockPos_): void;
        isLadder(arg0: Internal.LivingEntity_): boolean;
        removeFromWorld(): void;
        getExternalCableConnectionType(): Internal.AECableType;
        abstract setPartHostInfo(arg0: Internal.Direction_, arg1: Internal.IPartHost_, arg2: Internal.BlockEntity_): void;
        writeToStream(arg0: Internal.FriendlyByteBuf_): void;
        getStaticModels(): Internal.IPartModel;
        isProvidingWeakPower(): number;
        canBePlacedOn(arg0: Internal.BusSupport_): boolean;
        getModelData(): Internal.ModelData;
        addPartDrop(arg0: Internal.List_<Internal.ItemStack>, arg1: boolean): void;
        requireDynamicRender(): boolean;
        onShiftClicked(arg0: Internal.Player_, arg1: Vec3d_): boolean;
        canConnectRedstone(): boolean;
        readVisualStateFromNBT(arg0: Internal.CompoundTag_): void;
        clearContent(): void;
        animateTick(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.RandomSource_): void;
        get partItem(): Internal.IPartItem<any>
        get gridNode(): Internal.IGridNode
        get solid(): boolean
        get lightLevel(): number
        get desiredConnectionType(): Internal.AECableType
        get externalFacingNode(): Internal.IGridNode
        get externalCableConnectionType(): Internal.AECableType
        get staticModels(): Internal.IPartModel
        get modelData(): Internal.ModelData
    }
    type IPart_ = IPart;
    class TrappedChestBlock extends Internal.ChestBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type TrappedChestBlock_ = TrappedChestBlock;
    class FramedSmallDoubleCornerSlopePanelWallBlock extends Internal.FramedDoubleCornerSlopePanelWallBlock {
        constructor(arg0: xfacthd.framedblocks.common.data.BlockType_)
        shouldPreventNeighborCulling(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.BlockState_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getTopInteractionMode(arg0: Internal.BlockState_): Internal.DoubleBlockTopInteractionMode;
        isSuffocating(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getCamoOcclusionShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): Internal.VoxelShape;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        canCamoSustainPlant(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.IPlantable_): boolean;
        static createProperties(arg0: Internal.IBlockType_): Internal.BlockBehaviour$Properties;
        getCamoShadeBrightness(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: number): number;
        getCamoDrops(arg0: Internal.List_<Internal.ItemStack>, arg1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        static toggleYSlope(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        handleUse(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: Internal.InteractionHand_, arg5: Internal.BlockHitResult_): Internal.InteractionResult;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        updateShapeLockable(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Supplier_<Internal.BlockState>): Internal.BlockState;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        tryApplyCamoImmediately(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.LivingEntity_, arg3: Internal.ItemStack_): void;
        isIntangible(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): boolean;
        lockState(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Player_, arg3: Internal.ItemStack_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        getSolidityCheck(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.SolidityCheck;
        rotate(arg0: Internal.BlockState_, arg1: Internal.BlockHitResult_, arg2: Internal.Rotation_): Internal.BlockState;
        updateCulling(arg0: Internal.LevelReader_, arg1: BlockPos_): void;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getCamoVisualShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): Internal.VoxelShape;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockPair(arg0: Internal.BlockState_): Internal.Tuple<Internal.BlockState, Internal.BlockState>;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        static playCamoBreakSound(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_): void;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        initCache(arg0: Internal.BlockState_): Internal.StateCache;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getCamoGetter(arg0: Internal.BlockState_, arg1: Internal.Direction_, arg2: Internal.Direction_): Internal.CamoGetter;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        createBlockItem(): Internal.BlockItem;
        printCamoBlock(arg0: Internal.CompoundTag_): Internal.Optional<Internal.MutableComponent>;
        doesBlockOccludeBeaconBeam(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        needCullingUpdateAfterStateChange(arg0: Internal.LevelReader_, arg1: Internal.BlockState_, arg2: Internal.BlockState_): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getCache(arg0: Internal.BlockState_): Internal.StateCache;
        useCamoOcclusionShapeForLightOcclusion(arg0: Internal.BlockState_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type FramedSmallDoubleCornerSlopePanelWallBlock_ = FramedSmallDoubleCornerSlopePanelWallBlock;
    class URL implements Internal.Serializable {
        constructor(arg0: Internal.URL_, arg1: string, arg2: Internal.URLStreamHandler_)
        constructor(arg0: Internal.URL_, arg1: string)
        constructor(arg0: string, arg1: string, arg2: string)
        constructor(arg0: string, arg1: string, arg2: number, arg3: string)
        constructor(arg0: string, arg1: string, arg2: number, arg3: string, arg4: Internal.URLStreamHandler_)
        constructor(arg0: string)
        getContent(): any;
        getQuery(): string;
        sameFile(arg0: Internal.URL_): boolean;
        openConnection(): Internal.URLConnection;
        openConnection(arg0: Internal.Proxy_): Internal.URLConnection;
        getPort(): number;
        getFile(): string;
        getAuthority(): string;
        getUserInfo(): string;
        getRef(): string;
        getProtocol(): string;
        toExternalForm(): string;
        openStream(): Internal.InputStream;
        static setURLStreamHandlerFactory(arg0: Internal.URLStreamHandlerFactory_): void;
        toURI(): Internal.URI;
        getContent(arg0: typeof any[]): any;
        getPath(): string;
        getHost(): string;
        getDefaultPort(): number;
        get content(): any
        get query(): string
        get port(): number
        get file(): string
        get authority(): string
        get userInfo(): string
        get ref(): string
        get protocol(): string
        set URLStreamHandlerFactory(arg0: Internal.URLStreamHandlerFactory_)
        get path(): string
        get host(): string
        get defaultPort(): number
    }
    type URL_ = URL;
    class PowderChargeItem extends Internal.BlockItem {
        constructor(block: Internal.Block_, properties: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type PowderChargeItem_ = PowderChargeItem;
    class Score {
        constructor(arg0: Internal.Scoreboard_, arg1: Internal.Objective_, arg2: string)
        isLocked(): boolean;
        getOwner(): string;
        setScore(arg0: number): void;
        getObjective(): Internal.Objective;
        getScore(): number;
        add(arg0: number): void;
        increment(): void;
        reset(): void;
        setLocked(arg0: boolean): void;
        getScoreboard(): Internal.Scoreboard;
        get locked(): boolean
        get owner(): string
        set score(arg0: number)
        get objective(): Internal.Objective
        get score(): number
        set locked(arg0: boolean)
        get scoreboard(): Internal.Scoreboard
        static readonly SCORE_COMPARATOR: Internal.Comparator<Internal.Score>;
    }
    type Score_ = Score;
    interface IElectricEquipment {
        abstract onStrike(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.LivingEntity_, arg3: Internal.Map_<string, any>, arg4: DamageSource_, arg5: Internal.IElectricEquipment$ElectricSource_): void;
        applyToEntity(arg0: Internal.LivingEntity_, arg1: DamageSource_, arg2: Internal.IElectricEquipment$ElectricSource_): void;
        (arg0: Internal.ItemStack, arg1: Internal.EquipmentSlot, arg2: Internal.LivingEntity, arg3: Internal.Map<string, any>, arg4: DamageSource, arg5: Internal.IElectricEquipment$ElectricSource): void;
    }
    type IElectricEquipment_ = IElectricEquipment;
    interface IServerPlayer {
        abstract setXaeroWorldMapPlayerData(arg0: Internal.ServerPlayerData_): void;
        abstract getXaeroWorldMapPlayerData(): Internal.ServerPlayerData;
        set xaeroWorldMapPlayerData(arg0: Internal.ServerPlayerData_)
        get xaeroWorldMapPlayerData(): Internal.ServerPlayerData
    }
    type IServerPlayer_ = IServerPlayer;
    class AnyOfPredicate extends Internal.CombiningPredicate {
        constructor(arg0: Internal.List_<net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate>)
        static hasSturdyFace(arg0: Internal.Direction_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static noFluid(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        and(arg0: Internal.BiPredicate_<Internal.WorldGenLevel, BlockPos>): Internal.BiPredicate<Internal.WorldGenLevel, BlockPos>;
        static matchesTag(arg0: Vec3i_, arg1: Internal.TagKey_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static anyOf(arg0: Internal.List_<net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static noFluid(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static anyOf(arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_, arg1: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        negate(): Internal.BiPredicate<Internal.WorldGenLevel, BlockPos>;
        test(arg0: Internal.WorldGenLevel_, arg1: BlockPos_): boolean;
        static solid(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static insideWorld(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        or(arg0: Internal.BiPredicate_<Internal.WorldGenLevel, BlockPos>): Internal.BiPredicate<Internal.WorldGenLevel, BlockPos>;
        static matchesTag(arg0: Internal.TagKey_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static solid(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static alwaysTrue(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(arg0: Vec3i_, ...arg1: Internal.Block_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static allOf(...arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(arg0: Vec3i_, arg1: Internal.List_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static replaceable(): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static wouldSurvive(arg0: Internal.BlockState_, arg1: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesFluids(arg0: Vec3i_, arg1: Internal.List_<Internal.Fluid>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static not(arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesFluids(arg0: Vec3i_, ...arg1: Internal.Fluid_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static allOf(arg0: Internal.List_<net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static anyOf(...arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static allOf(arg0: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_, arg1: net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static hasSturdyFace(arg0: Vec3i_, arg1: Internal.Direction_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static replaceable(arg0: Vec3i_): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(arg0: Internal.List_<Internal.Block>): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesBlocks(...arg0: Internal.Block_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static matchesFluids(...arg0: Internal.Fluid_[]): net.minecraft.world.level.levelgen.blockpredicates.BlockPredicate;
        static readonly CODEC: Internal.Codec<Internal.AnyOfPredicate>;
    }
    type AnyOfPredicate_ = AnyOfPredicate;
    class WallHangingSignBlockBOP extends Internal.WallHangingSignBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_, arg1: Internal.WoodType_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type WallHangingSignBlockBOP_ = WallHangingSignBlockBOP;
    class HayBlock extends Internal.RotatedPillarBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type HayBlock_ = HayBlock;
    interface PathMatcher {
        abstract matches(arg0: Internal.Path_): boolean;
        (arg0: Internal.Path): boolean;
    }
    type PathMatcher_ = PathMatcher;
    class BambooFeature extends Internal.Feature<Internal.ProbabilityFeatureConfiguration> {
        constructor(arg0: Internal.Codec_<Internal.ProbabilityFeatureConfiguration>)
    }
    type BambooFeature_ = BambooFeature;
    class FramedFancyPoweredRailBlock extends Internal.PoweredRailBlock implements Internal.IFramedBlock {
        shouldPreventNeighborCulling(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.BlockState_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getCamoOcclusionShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): Internal.VoxelShape;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        onMinecartPass(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.AbstractMinecart_): void;
        static createProperties(arg0: Internal.IBlockType_): Internal.BlockBehaviour$Properties;
        getCamoShadeBrightness(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: number): number;
        getCamoDrops(arg0: Internal.List_<Internal.ItemStack>, arg1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.BlockHitResult_, arg2: Internal.Rotation_): Internal.BlockState;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockType(): Internal.IBlockType;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        static playCamoBreakSound(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_): void;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        isValidRailShape(arg0: Internal.RailShape_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        runOcclusionTestAndGetLookupState(arg0: Internal.SideSkipPredicate_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.BlockState_, arg5: Internal.Direction_): Internal.BlockState;
        canMakeSlopes(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        static powered(): Internal.FramedFancyPoweredRailBlock;
        doesBlockOccludeBeaconBeam(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        useCamoOcclusionShapeForLightOcclusion(arg0: Internal.BlockState_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        isSuffocating(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canCamoSustainPlant(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.IPlantable_): boolean;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        static toggleYSlope(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        setLightEmission(v: number): void;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        handleUse(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: Internal.InteractionHand_, arg5: Internal.BlockHitResult_): Internal.InteractionResult;
        setDestroySpeed(v: number): void;
        updateShapeLockable(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Supplier_<Internal.BlockState>): Internal.BlockState;
        tryApplyCamoImmediately(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.LivingEntity_, arg3: Internal.ItemStack_): void;
        isIntangible(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): boolean;
        lockState(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Player_, arg3: Internal.ItemStack_): boolean;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        updateCulling(arg0: Internal.LevelReader_, arg1: BlockPos_): void;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getCamoVisualShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): Internal.VoxelShape;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        static activator(): Internal.FramedFancyPoweredRailBlock;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        handleBlockLeftClick(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        playBreakSound(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_): boolean;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        initCache(arg0: Internal.BlockState_): Internal.StateCache;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        createBlockItem(): Internal.BlockItem;
        printCamoBlock(arg0: Internal.CompoundTag_): Internal.Optional<Internal.MutableComponent>;
        getRailMaxSpeed(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.AbstractMinecart_): number;
        needCullingUpdateAfterStateChange(arg0: Internal.LevelReader_, arg1: Internal.BlockState_, arg2: Internal.BlockState_): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getCache(arg0: Internal.BlockState_): Internal.StateCache;
        rotate(arg0: Internal.BlockState_, arg1: Internal.Direction_, arg2: Internal.Rotation_): Internal.BlockState;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        get blockType(): Internal.IBlockType
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get mod(): string
    }
    type FramedFancyPoweredRailBlock_ = FramedFancyPoweredRailBlock;
    interface BitStorage {
        abstract getAndSet(arg0: number, arg1: number): number;
        abstract getAll(arg0: Internal.IntConsumer_): void;
        abstract getSize(): number;
        abstract copy(): this;
        abstract get(arg0: number): number;
        abstract set(arg0: number, arg1: number): void;
        abstract getBits(): number;
        abstract unpack(arg0: number[]): void;
        abstract getRaw(): number[];
        get size(): number
        get bits(): number
        get raw(): number[]
    }
    type BitStorage_ = BitStorage;
    class ModMismatchEvent$MismatchResolutionResult extends Internal.Record {
        constructor(modid: string, versionDifference: Internal.ModMismatchEvent$MismatchedVersionInfo_, resolver: Internal.ModContainer_)
        versionDifference(): Internal.ModMismatchEvent$MismatchedVersionInfo;
        resolver(): Internal.ModContainer;
        modid(): string;
        wasSelfResolved(): boolean;
    }
    type ModMismatchEvent$MismatchResolutionResult_ = ModMismatchEvent$MismatchResolutionResult;
    interface HeightmapAccessor {
        abstract set(arg0: number, arg1: number, arg2: number): void;
        abstract getOpaque(): Internal.Predicate<Internal.BlockState>;
        get opaque(): Internal.Predicate<Internal.BlockState>
    }
    type HeightmapAccessor_ = HeightmapAccessor;
    class URI implements Internal.Comparable<Internal.URI>, Internal.Serializable {
        constructor(arg0: string, arg1: string, arg2: string)
        constructor(arg0: string, arg1: string, arg2: string, arg3: string)
        constructor(arg0: string, arg1: string, arg2: string, arg3: string, arg4: string)
        constructor(arg0: string, arg1: string, arg2: string, arg3: number, arg4: string, arg5: string, arg6: string)
        constructor(arg0: string)
        getQuery(): string;
        toURL(): Internal.URL;
        relativize(arg0: Internal.URI_): this;
        getPort(): number;
        compareTo(arg0: any): number;
        getRawUserInfo(): string;
        toASCIIString(): string;
        isOpaque(): boolean;
        getRawSchemeSpecificPart(): string;
        static create(arg0: string): Internal.URI;
        resolve(arg0: string): this;
        resolve(arg0: Internal.URI_): this;
        getPath(): string;
        getScheme(): string;
        compareTo(arg0: Internal.URI_): number;
        normalize(): this;
        getRawQuery(): string;
        getAuthority(): string;
        getUserInfo(): string;
        getSchemeSpecificPart(): string;
        parseServerAuthority(): this;
        getRawPath(): string;
        getFragment(): string;
        isAbsolute(): boolean;
        getRawFragment(): string;
        getHost(): string;
        getRawAuthority(): string;
        get query(): string
        get port(): number
        get rawUserInfo(): string
        get opaque(): boolean
        get rawSchemeSpecificPart(): string
        get path(): string
        get scheme(): string
        get rawQuery(): string
        get authority(): string
        get userInfo(): string
        get schemeSpecificPart(): string
        get rawPath(): string
        get fragment(): string
        get absolute(): boolean
        get rawFragment(): string
        get host(): string
        get rawAuthority(): string
    }
    type URI_ = URI;
    class AnimationMetadataSectionSerializer implements Internal.MetadataSectionSerializer<Internal.AnimationMetadataSection> {
        constructor()
        getMetadataSectionName(): string;
        fromJson(arg0: Internal.JsonObject_): any;
        get metadataSectionName(): string
    }
    type AnimationMetadataSectionSerializer_ = AnimationMetadataSectionSerializer;
    interface Functor$Mu extends Internal.Kind1$Mu {
    }
    type Functor$Mu_ = Functor$Mu;
    abstract class AbstractByteBuf extends Internal.ByteBuf {
        retain(): Internal.ReferenceCounted;
        retain(arg0: number): Internal.ReferenceCounted;
    }
    type AbstractByteBuf_ = AbstractByteBuf;
    class ModelBlockRenderer {
        constructor(arg0: Internal.BlockColors_)
        /**
         * @deprecated
        */
        tesselateWithAO(arg0: Internal.BlockAndTintGetter_, arg1: Internal.BakedModel_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_, arg6: boolean, arg7: Internal.RandomSource_, arg8: number, arg9: number): void;
        renderModel(arg0: Internal.PoseStack$Pose_, arg1: Internal.VertexConsumer_, arg2: Internal.BlockState_, arg3: Internal.BakedModel_, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number, arg9: Internal.ModelData_, arg10: Internal.RenderType_): void;
        /**
         * @deprecated
        */
        renderModel(arg0: Internal.PoseStack$Pose_, arg1: Internal.VertexConsumer_, arg2: Internal.BlockState_, arg3: Internal.BakedModel_, arg4: number, arg5: number, arg6: number, arg7: number, arg8: number): void;
        static enableCaching(): void;
        tesselateWithAO(arg0: Internal.BlockAndTintGetter_, arg1: Internal.BakedModel_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_, arg6: boolean, arg7: Internal.RandomSource_, arg8: number, arg9: number, arg10: Internal.ModelData_, arg11: Internal.RenderType_): void;
        /**
         * @deprecated
        */
        tesselateBlock(arg0: Internal.BlockAndTintGetter_, arg1: Internal.BakedModel_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_, arg6: boolean, arg7: Internal.RandomSource_, arg8: number, arg9: number): void;
        /**
         * @deprecated
        */
        tesselateWithoutAO(arg0: Internal.BlockAndTintGetter_, arg1: Internal.BakedModel_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_, arg6: boolean, arg7: Internal.RandomSource_, arg8: number, arg9: number): void;
        static clearCache(): void;
        tesselateBlock(arg0: Internal.BlockAndTintGetter_, arg1: Internal.BakedModel_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_, arg6: boolean, arg7: Internal.RandomSource_, arg8: number, arg9: number, arg10: Internal.ModelData_, arg11: Internal.RenderType_): void;
        tesselateWithoutAO(arg0: Internal.BlockAndTintGetter_, arg1: Internal.BakedModel_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.PoseStack_, arg5: Internal.VertexConsumer_, arg6: boolean, arg7: Internal.RandomSource_, arg8: number, arg9: number, arg10: Internal.ModelData_, arg11: Internal.RenderType_): void;
    }
    type ModelBlockRenderer_ = ModelBlockRenderer;
    interface IMateriallyTexturedBlockEntity {
        abstract updateTextureDataWith(arg0: Internal.MaterialTextureData_): void;
        abstract getTextureData(): Internal.MaterialTextureData;
        get textureData(): Internal.MaterialTextureData
    }
    type IMateriallyTexturedBlockEntity_ = IMateriallyTexturedBlockEntity;
    class LargePlatformDoubleAxleBogeyBlock extends Internal.DoubleAxleBogeyBlock {
        constructor(props: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        fluidState(arg0: Internal.BlockState_): Internal.FluidState;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        onWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        playRemoveSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getTicker<S extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<S>): Internal.BlockEntityTicker<S>;
        playRotateSound(arg0: Internal.Level_, arg1: BlockPos_): void;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockEntity(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.CRBogeyBlockEntity;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        static onRemove(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.BlockState_): void;
        updateWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        withBlockEntityDo(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Consumer_<Internal.CRBogeyBlockEntity>): void;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        static withWater(arg0: Internal.LevelAccessor_, arg1: Internal.BlockState_, arg2: BlockPos_): Internal.BlockState;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        onSneakWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        withWater(arg0: Internal.BlockState_, arg1: Internal.BlockPlaceContext_): Internal.BlockState;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        updateAfterWrenched(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_): Internal.BlockState;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        onBlockEntityUse(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.Function_<Internal.CRBogeyBlockEntity, Internal.InteractionResult>): Internal.InteractionResult;
        getBlockEntityOptional(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.Optional<Internal.CRBogeyBlockEntity>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type LargePlatformDoubleAxleBogeyBlock_ = LargePlatformDoubleAxleBogeyBlock;
    class InventoryMenu extends Internal.RecipeBookMenu<Internal.CraftingContainer> {
        constructor(arg0: Internal.Inventory_, arg1: boolean, arg2: Internal.Player_)
        static isHotbarSlot(arg0: number): boolean;
        getCraftSlots(): Internal.CraftingContainer;
        get craftSlots(): Internal.CraftingContainer
        static readonly EMPTY_ARMOR_SLOT_BOOTS: ResourceLocation;
        static readonly RESULT_SLOT: 0;
        static readonly CONTAINER_ID: 0;
        static readonly USE_ROW_SLOT_END: 45;
        static readonly USE_ROW_SLOT_START: 36;
        static readonly CRAFT_SLOT_END: 5;
        static readonly ARMOR_SLOT_END: 9;
        static readonly CRAFT_SLOT_START: 1;
        static readonly EMPTY_ARMOR_SLOT_SHIELD: ResourceLocation;
        static readonly EMPTY_ARMOR_SLOT_LEGGINGS: ResourceLocation;
        readonly owner: Internal.Player;
        static readonly EMPTY_ARMOR_SLOT_CHESTPLATE: ResourceLocation;
        static readonly SHIELD_SLOT: 45;
        readonly active: boolean;
        static readonly ARMOR_SLOT_START: 5;
        static readonly INV_SLOT_START: 9;
        static readonly INV_SLOT_END: 36;
        static readonly BLOCK_ATLAS: ResourceLocation;
        static readonly EMPTY_ARMOR_SLOT_HELMET: ResourceLocation;
    }
    type InventoryMenu_ = InventoryMenu;
    class HempBlock extends Internal.CropBlock implements Internal.BonemealableBlock {
        constructor(arg0: Internal.BlockBehaviour$Properties_)
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        getPlantType(arg0: Internal.BlockGetter_, arg1: BlockPos_): Internal.PlantType;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly AGE: Internal.IntegerProperty;
        static readonly TOP: Internal.BooleanProperty;
        static readonly PROPERTIES: Internal.Supplier<Internal.BlockBehaviour$Properties>;
    }
    type HempBlock_ = HempBlock;
    class SimpleChannel {
        constructor(arg0: any_, arg1: Internal.Consumer_<any>)
        constructor(arg0: any_)
        handler$zgg000$onWrapInVanillaPacket(arg0: any, arg1: Internal.NetworkDirection_, arg2: Internal.CallbackInfoReturnable_<any>): void;
        toVanillaPacket<MSG>(arg0: MSG, arg1: Internal.NetworkDirection_): Internal.Packet<any>;
        encodeMessage<MSG>(arg0: MSG, arg1: Internal.FriendlyByteBuf_): number;
        sendTo<MSG>(arg0: MSG, arg1: Internal.Connection_, arg2: Internal.NetworkDirection_): void;
        sendToServer<MSG>(arg0: MSG): void;
        registerMessage<MSG>(arg0: number, arg1: MSG, arg2: Internal.BiConsumer_<MSG, Internal.FriendlyByteBuf>, arg3: Internal.Function_<Internal.FriendlyByteBuf, MSG>, arg4: Internal.BiConsumer_<MSG, Internal.Supplier<Internal.NetworkEvent$Context>>): Internal.IndexedMessageCodec$MessageHandler<MSG>;
        send<MSG>(arg0: Internal.PacketDistributor$PacketTarget_, arg1: MSG): void;
        messageBuilder<M>(arg0: M, arg1: number, arg2: Internal.NetworkDirection_): Internal.SimpleChannel$MessageBuilder<M>;
        registerMessage<MSG>(arg0: number, arg1: MSG, arg2: Internal.BiConsumer_<MSG, Internal.FriendlyByteBuf>, arg3: Internal.Function_<Internal.FriendlyByteBuf, MSG>, arg4: Internal.BiConsumer_<MSG, Internal.Supplier<Internal.NetworkEvent$Context>>, arg5: Internal.Optional_<Internal.NetworkDirection>): Internal.IndexedMessageCodec$MessageHandler<MSG>;
        isRemotePresent(arg0: Internal.Connection_): boolean;
        messageBuilder<M>(arg0: M, arg1: number): Internal.SimpleChannel$MessageBuilder<M>;
        reply<MSG>(arg0: MSG, arg1: Internal.NetworkEvent$Context_): void;
    }
    type SimpleChannel_ = SimpleChannel;
    class Optional <T> {
        orElseThrow(): T;
        stream(): Internal.Stream<T>;
        static empty<T>(): Internal.Optional<T>;
        ifPresent(arg0: Internal.Consumer_<T>): void;
        orElseGet(arg0: Internal.Supplier_<T>): T;
        isEmpty(): boolean;
        ifPresentOrElse(arg0: Internal.Consumer_<T>, arg1: Internal.Runnable_): void;
        flatMap<U>(arg0: Internal.Function_<T, Internal.Optional<U>>): Internal.Optional<U>;
        filter(arg0: Internal.Predicate_<T>): this;
        static ofNullable<T>(arg0: T): Internal.Optional<T>;
        or(arg0: Internal.Supplier_<Internal.Optional<T>>): this;
        orElse(arg0: T): T;
        isPresent(): boolean;
        map<U>(arg0: Internal.Function_<T, U>): Internal.Optional<U>;
        orElseThrow<X extends Internal.Throwable>(arg0: Internal.Supplier_<X>): T;
        get(): T;
        static of<T>(arg0: T): Internal.Optional<T>;
        get empty(): boolean
        get present(): boolean
    }
    type Optional_<T> = Optional<T>;
    class WallBlockItem extends Internal.BlockItem implements Internal.IDoItem {
        constructor(arg0: com.ldtteam.domumornamentum.block.vanilla.WallBlock_, arg1: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getInputIds(): Internal.List<ResourceLocation>;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        getGroup(): ResourceLocation;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        get inputIds(): Internal.List<ResourceLocation>
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get group(): ResourceLocation
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type WallBlockItem_ = WallBlockItem;
    interface WrappedExecutable {
        getReturnType(): typeof any;
        construct(cx: Internal.Context_, scope: Internal.Scriptable_, args: any[]): any;
        isStatic(): boolean;
        unwrap(): Internal.Executable;
        abstract invoke(arg0: Internal.Context_, arg1: Internal.Scriptable_, arg2: any, arg3: any[]): any;
        get returnType(): typeof any
        get "static"(): boolean
        (arg0: Internal.Context, arg1: Internal.Scriptable, arg2: any, arg3: any[]): any;
    }
    type WrappedExecutable_ = WrappedExecutable;
    /**
     * @deprecated
    */
    class ReloadableServerResources {
        constructor(arg0: Internal.RegistryAccess$Frozen_, arg1: Internal.FeatureFlagSet_, arg2: Internal.Commands$CommandSelection_, arg3: number)
        getFunctionLibrary(): Internal.ServerFunctionLibrary;
        getRecipeManager(): Internal.RecipeManager;
        updateRegistryTags(arg0: Internal.RegistryAccess_): void;
        getLootData(): Internal.LootDataManager;
        static loadResources(arg0: Internal.ResourceManager_, arg1: Internal.RegistryAccess$Frozen_, arg2: Internal.FeatureFlagSet_, arg3: Internal.Commands$CommandSelection_, arg4: number, arg5: Internal.Executor_, arg6: Internal.Executor_): Internal.CompletableFuture<Internal.ReloadableServerResources>;
        handler$zle000$placebo_listeners(arg0: Internal.CallbackInfoReturnable_<any>): void;
        getConditionContext(): Internal.ICondition$IContext;
        handler$zcj000$updateRegistryTags(registryAccess: Internal.RegistryAccess_, ci: Internal.CallbackInfo_): void;
        listeners(): Internal.List<Internal.PreparableReloadListener>;
        getAdvancements(): Internal.ServerAdvancementManager;
        getCommands(): Internal.Commands;
        get functionLibrary(): Internal.ServerFunctionLibrary
        get recipeManager(): Internal.RecipeManager
        get lootData(): Internal.LootDataManager
        get conditionContext(): Internal.ICondition$IContext
        get advancements(): Internal.ServerAdvancementManager
        get commands(): Internal.Commands
        readonly tagManager: Internal.TagManager;
    }
    type ReloadableServerResources_ = ReloadableServerResources;
    interface IWashable {
        abstract tryWash(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_): boolean;
        (arg0: Internal.Level, arg1: BlockPos, arg2: Internal.BlockState): boolean;
    }
    type IWashable_ = IWashable;
    interface DynamicLightHandler <T> {
        makeLivingEntityHandler<T extends Internal.LivingEntity>(arg0: Internal.DynamicLightHandler_<T>): this;
        makeHandler<T extends Internal.LivingEntity>(arg0: Internal.Function_<T, number>, arg1: Internal.Function_<T, boolean>): this;
        makeCreeperEntityHandler<T extends Internal.Creeper>(arg0: Internal.DynamicLightHandler_<T>): this;
        abstract getLuminance(arg0: T): number;
        isWaterSensitive(arg0: T): boolean;
        (arg0: T): number;
    }
    type DynamicLightHandler_<T> = DynamicLightHandler<T>;
    abstract class MekanismContainer extends Internal.AbstractContainerMenu implements Internal.ISecurityContainer {
        handleWindowProperty(property: number, value: Internal.ItemStack_): void;
        getInventoryContainerSlots(): Internal.List<Internal.InventoryContainerSlot>;
        handleWindowProperty(property: number, value: boolean): void;
        trackArray(arrayIn: boolean[]): void;
        getSelectedWindow(player: Internal.UUID_): Internal.SelectedWindowData;
        track(data: Internal.ISyncableData_): void;
        trackArray(arrayIn: boolean[][]): void;
        getHotBarSlots(): Internal.List<Internal.HotBarSlot>;
        trackArray(arrayIn: number[]): void;
        static insertItemCheckAll<SLOT extends Internal.Slot & Internal.IInsertableSlot>(slots: Internal.List_<SLOT>, stack: Internal.ItemStack_, selectedWindow: Internal.SelectedWindowData_, action: mekanism.api.Action_): Internal.ItemStack;
        handleWindowProperty(property: number, value: number): void;
        trackArray(arrayIn: number[]): void;
        isRemote(): boolean;
        trackArray(arrayIn: number[]): void;
        startTracking(key: any, tracker: Internal.MekanismContainer$ISpecificContainerTracker_): Internal.List<Internal.ISyncableData>;
        handleWindowProperty(property: number, value: number): void;
        setSelectedWindow(player: Internal.UUID_, selectedWindow: Internal.SelectedWindowData_): void;
        handleWindowProperty(property: number, value: number): void;
        trackArray(arrayIn: number[]): void;
        handleWindowProperty(property: number, value: Internal.FloatingLong_): void;
        handleWindowProperty<V>(property: number, value: V): void;
        trackArray(arrayIn: number[]): void;
        handleWindowProperty(property: number, value: number): void;
        stopTracking(key: any): void;
        startTrackingServer(key: any, tracker: Internal.MekanismContainer$ISpecificContainerTracker_): void;
        getSelectedWindow(): Internal.SelectedWindowData;
        handleWindowProperty(property: number, value: number): void;
        static insertItem<SLOT extends Internal.Slot & Internal.IInsertableSlot>(slots: Internal.List_<SLOT>, stack: Internal.ItemStack_, selectedWindow: Internal.SelectedWindowData_): Internal.ItemStack;
        handleWindowProperty<STACK extends Internal.ChemicalStack<any>>(property: number, value: STACK): void;
        getMainInventorySlots(): Internal.List<Internal.MainInventorySlot>;
        handleWindowProperty(property: number, value: Internal.FluidStack_): void;
        static insertItem<SLOT extends Internal.Slot & Internal.IInsertableSlot>(slots: Internal.List_<SLOT>, stack: Internal.ItemStack_, ignoreEmpty: boolean, checkAll: boolean, selectedWindow: Internal.SelectedWindowData_, action: mekanism.api.Action_): Internal.ItemStack;
        handleWindowProperty(property: number, value: number): void;
        handleWindowProperty(property: number, value: BlockPos_): void;
        abstract getSecurityObject(): Internal.ICapabilityProvider;
        static insertItem<SLOT extends Internal.Slot & Internal.IInsertableSlot>(slots: Internal.List_<SLOT>, stack: Internal.ItemStack_, ignoreEmpty: boolean, selectedWindow: Internal.SelectedWindowData_, action: mekanism.api.Action_): Internal.ItemStack;
        handleWindowProperty<TYPE>(property: number, value: Internal.List_<TYPE>): void;
        getPlayerUUID(): Internal.UUID;
        handleWindowProperty<FREQUENCY extends Internal.Frequency>(property: number, value: FREQUENCY): void;
        trackArray(arrayIn: number[]): void;
        static insertItem<SLOT extends Internal.Slot & Internal.IInsertableSlot>(slots: Internal.List_<SLOT>, stack: Internal.ItemStack_, ignoreEmpty: boolean, selectedWindow: Internal.SelectedWindowData_): Internal.ItemStack;
        setSelectedWindow(selectedWindow: Internal.SelectedWindowData_): void;
        get inventoryContainerSlots(): Internal.List<Internal.InventoryContainerSlot>
        get hotBarSlots(): Internal.List<Internal.HotBarSlot>
        get remote(): boolean
        get selectedWindow(): Internal.SelectedWindowData
        get mainInventorySlots(): Internal.List<Internal.MainInventorySlot>
        get securityObject(): Internal.ICapabilityProvider
        get playerUUID(): Internal.UUID
        set selectedWindow(selectedWindow: Internal.SelectedWindowData_)
        static readonly SKIN_SELECT_WINDOW: 3;
        static readonly BASE_Y_OFFSET: 84;
        static readonly TRANSPORTER_CONFIG_WINDOW: 0;
        static readonly UPGRADE_WINDOW: 2;
        static readonly SIDE_CONFIG_WINDOW: 1;
    }
    type MekanismContainer_ = MekanismContainer;
    class SoulBeadItem extends Internal.ZetaItem {
        constructor(arg0: Internal.ZetaModule_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        static isEnabled(arg0: Internal.Item_): boolean;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        setDigSpeed(speed: number): void;
        getArmorTextureZeta(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        shouldCauseReequipAnimationZeta(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getMaxDamageZeta(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        isRepairableZeta(arg0: Internal.ItemStack_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        canElytraFlyZeta(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onEntityItemUpdateZeta(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        isBookEnchantableZeta(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        onItemUseFirstZeta(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        canApplyAtEnchantingTableZeta(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        static isEnabled(arg0: Internal.Block_): boolean;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        getItem(): Internal.Item;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        getAllEnchantmentsZeta(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        setCondition(arg0: Internal.BooleanSupplier_): any;
        isEnderMaskZeta(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        setCreativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>): Internal.Item;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        isEnabled(): boolean;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getBurnTimeZeta(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        getEnchantmentLevelZeta(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        canEquipZeta(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        setCreativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>, arg1: Internal.ItemLike_, arg2: boolean): Internal.Item;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        damageItemZeta<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        getEnchantmentValueZeta(arg0: Internal.ItemStack_): number;
        canShearZeta(arg0: Internal.ItemStack_): boolean;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        getDefaultTooltipHideFlagsZeta(arg0: Internal.ItemStack_): number;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        doesSneakBypassUseZeta(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        get item(): Internal.Item
        set armorKnockbackResistance(knockbackResistance: number)
        set condition(arg0: Internal.BooleanSupplier_)
        set creativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>)
        get enabled(): boolean
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type SoulBeadItem_ = SoulBeadItem;
    class FramedPyramidBlock extends Internal.FramedBlock {
        constructor(arg0: xfacthd.framedblocks.common.data.BlockType_)
        shouldPreventNeighborCulling(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: BlockPos_, arg4: Internal.BlockState_): boolean;
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        static generateSlabShapes(arg0: Internal.ImmutableList_<Internal.BlockState>): Internal.ShapeProvider;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        isSuffocating(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getCamoOcclusionShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): Internal.VoxelShape;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        canCamoSustainPlant(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.IPlantable_): boolean;
        static createProperties(arg0: Internal.IBlockType_): Internal.BlockBehaviour$Properties;
        getCamoShadeBrightness(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: number): number;
        getCamoDrops(arg0: Internal.List_<Internal.ItemStack>, arg1: Internal.LootParams$Builder_): Internal.List<Internal.ItemStack>;
        getTicker<T extends Internal.BlockEntity>(arg0: Internal.Level_, arg1: Internal.BlockState_, arg2: Internal.BlockEntityType_<T>): Internal.BlockEntityTicker<T>;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        static toggleYSlope(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        handleUse(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: Internal.InteractionHand_, arg5: Internal.BlockHitResult_): Internal.InteractionResult;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        updateShapeLockable(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Supplier_<Internal.BlockState>): Internal.BlockState;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        tryApplyCamoImmediately(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.LivingEntity_, arg3: Internal.ItemStack_): void;
        isIntangible(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): boolean;
        lockState(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.Player_, arg3: Internal.ItemStack_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.BlockHitResult_, arg2: Internal.Rotation_): Internal.BlockState;
        updateCulling(arg0: Internal.LevelReader_, arg1: BlockPos_): void;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getCamoVisualShape(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.CollisionContext_): Internal.VoxelShape;
        getListener<T extends Internal.BlockEntity>(arg0: Internal.ServerLevel_, arg1: T): Internal.GameEventListener;
        arch$holder(): Internal.Holder<Internal.Block>;
        static generateShapes(arg0: Internal.ImmutableList_<Internal.BlockState>): Internal.ShapeProvider;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        newBlockEntity(arg0: BlockPos_, arg1: Internal.BlockState_): Internal.BlockEntity;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        playBreakSound(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        static playCamoBreakSound(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_): void;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        initCache(arg0: Internal.BlockState_): Internal.StateCache;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        runOcclusionTestAndGetLookupState(arg0: Internal.SideSkipPredicate_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.BlockState_, arg5: Internal.Direction_): Internal.BlockState;
        createBlockItem(): Internal.BlockItem;
        printCamoBlock(arg0: Internal.CompoundTag_): Internal.Optional<Internal.MutableComponent>;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        needCullingUpdateAfterStateChange(arg0: Internal.LevelReader_, arg1: Internal.BlockState_, arg2: Internal.BlockState_): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        getCache(arg0: Internal.BlockState_): Internal.StateCache;
        useCamoOcclusionShapeForLightOcclusion(arg0: Internal.BlockState_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type FramedPyramidBlock_ = FramedPyramidBlock;
    interface ICraftingService extends Internal.IGridService {
        abstract getCraftables(arg0: Internal.AEKeyFilter_): Internal.Set<Internal.AEKey>;
        abstract submitJob(arg0: Internal.ICraftingPlan_, arg1: Internal.ICraftingRequester_, arg2: Internal.ICraftingCPU_, arg3: boolean, arg4: Internal.IActionSource_): Internal.ICraftingSubmitResult;
        abstract getRequestedAmount(arg0: Internal.AEKey_): number;
        isCraftable(arg0: Internal.AEKey_): boolean;
        abstract canEmitFor(arg0: Internal.AEKey_): boolean;
        abstract getCpus(): Internal.ImmutableSet<Internal.ICraftingCPU>;
        abstract getFuzzyCraftable(arg0: Internal.AEKey_, arg1: Internal.AEKeyFilter_): Internal.AEKey;
        abstract getCraftingFor(arg0: Internal.AEKey_): Internal.Collection<Internal.IPatternDetails>;
        abstract isRequesting(arg0: Internal.AEKey_): boolean;
        abstract isRequestingAny(): boolean;
        abstract refreshNodeCraftingProvider(arg0: Internal.IGridNode_): void;
        abstract beginCraftingCalculation(arg0: Internal.Level_, arg1: Internal.ICraftingSimulationRequester_, arg2: Internal.AEKey_, arg3: number, arg4: Internal.CalculationStrategy_): Internal.Future<Internal.ICraftingPlan>;
        get cpus(): Internal.ImmutableSet<Internal.ICraftingCPU>
        get requestingAny(): boolean
    }
    type ICraftingService_ = ICraftingService;
    interface ChatDecorator {
        abstract decorate(arg0: Internal.ServerPlayer_, arg1: net.minecraft.network.chat.Component_): Internal.CompletableFuture<net.minecraft.network.chat.Component>;
        (arg0: Internal.ServerPlayer, arg1: net.minecraft.network.chat.Component): Internal.CompletableFuture_<net.minecraft.network.chat.Component>;
        readonly PLAIN: Internal.ChatDecorator;
    }
    type ChatDecorator_ = ChatDecorator;
    class MeteoritePlacerItem extends Internal.AEBaseItem {
        constructor(arg0: Internal.Item$Properties_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type MeteoritePlacerItem_ = MeteoritePlacerItem;
    class AdvancementJS {
        constructor(a: Internal.Advancement_)
        addChild(a: Internal.AdvancementJS_): void;
        getId(): ResourceLocation;
        getDisplayText(): net.minecraft.network.chat.Component;
        getTitle(): net.minecraft.network.chat.Component;
        id(): ResourceLocation;
        getParent(): this;
        hasDisplay(): boolean;
        getDescription(): net.minecraft.network.chat.Component;
        getChildren(): Internal.Set<Internal.AdvancementJS>;
        get id(): ResourceLocation
        get displayText(): net.minecraft.network.chat.Component
        get title(): net.minecraft.network.chat.Component
        get parent(): Internal.AdvancementJS
        get description(): net.minecraft.network.chat.Component
        get children(): Internal.Set<Internal.AdvancementJS>
        readonly advancement: Internal.Advancement;
    }
    type AdvancementJS_ = AdvancementJS;
    class RopeAndNailItem extends Internal.BaseComfortsItem {
        constructor(arg0: Internal.Block_)
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type RopeAndNailItem_ = RopeAndNailItem;
    interface IToken <T> {
        abstract getIdentifier(): T;
        get identifier(): T
        (): T;
    }
    type IToken_<T> = IToken<T>;
    abstract class AbstractAcceptorCache <ACCEPTOR, INFO> {
        getCachedAcceptor(side: Internal.Direction_): Internal.LazyOptional<ACCEPTOR>;
        getConnectedAcceptors(sides: Internal.Set_<Internal.Direction>): Internal.List<ACCEPTOR>;
        clear(): void;
        invalidateCachedAcceptor(side: Internal.Direction_): void;
        currentAcceptorConnections: number;
    }
    type AbstractAcceptorCache_<ACCEPTOR, INFO> = AbstractAcceptorCache<ACCEPTOR, INFO>;
    interface IBlueprintDataProviderBE {
        removeTag(arg0: BlockPos_, arg1: string): void;
        getRealWorldPos(arg0: BlockPos_): BlockPos;
        abstract getSchematicName(): string;
        abstract getTilePos(): BlockPos;
        abstract getSchematicCorners(): Internal.Tuple<BlockPos, BlockPos>;
        abstract getPositionedTags(): Internal.Map<BlockPos, Internal.List<string>>;
        abstract getBlueprintPath(): string;
        readTagPosMapFrom(arg0: Internal.CompoundTag_): Internal.Map<BlockPos, Internal.List<string>>;
        abstract setSchematicCorners(arg0: BlockPos_, arg1: BlockPos_): void;
        abstract getUpdatePacket(): Internal.ClientboundBlockEntityDataPacket;
        writeMapToCompound(arg0: Internal.CompoundTag_, arg1: Internal.Map_<BlockPos, Internal.List<string>>): void;
        addTag(arg0: BlockPos_, arg1: string): void;
        readSchematicDataFromNBT(arg0: Internal.CompoundTag_): void;
        getWorldTagNamePosMap(): Internal.Map<string, Internal.Set<BlockPos>>;
        abstract setPositionedTags(arg0: Internal.Map_<BlockPos, Internal.List<string>>): void;
        getInWorldCorners(): Internal.Tuple<BlockPos, BlockPos>;
        abstract setSchematicName(arg0: string): void;
        abstract getPackName(): string;
        getWorldTagPosMap(): Internal.Map<BlockPos, Internal.List<string>>;
        abstract setPackName(arg0: string): void;
        abstract setBlueprintPath(arg0: string): void;
        writeSchematicDataToNBT(arg0: Internal.CompoundTag_): void;
        get schematicName(): string
        get tilePos(): BlockPos
        get schematicCorners(): Internal.Tuple<BlockPos, BlockPos>
        get positionedTags(): Internal.Map<BlockPos, Internal.List<string>>
        get blueprintPath(): string
        get updatePacket(): Internal.ClientboundBlockEntityDataPacket
        get worldTagNamePosMap(): Internal.Map<string, Internal.Set<BlockPos>>
        set positionedTags(arg0: Internal.Map_<BlockPos, Internal.List<string>>)
        get inWorldCorners(): Internal.Tuple<BlockPos, BlockPos>
        set schematicName(arg0: string)
        get packName(): string
        get worldTagPosMap(): Internal.Map<BlockPos, Internal.List<string>>
        set packName(arg0: string)
        set blueprintPath(arg0: string)
        readonly TAG_CORNER_ONE: "corner1";
        readonly TAG_POS_TAG_MAP: "posTagMap";
        readonly TAG_TAG_POS: "tagPos";
        readonly TAG_CORNER_TWO: "corner2";
        readonly TAG_TAG_NAME: "tagName";
        readonly TAG_PATH: "path";
        readonly TAG_SCHEMATIC_NAME: "schematicName";
        readonly TAG_BLUEPRINTDATA: "blueprintDataProvider";
        readonly TAG_PACK: "pack";
        readonly TAG_TAG_NAME_LIST: "tagNameList";
    }
    type IBlueprintDataProviderBE_ = IBlueprintDataProviderBE;
    class ModItems$1 extends Internal.ItemNameBlockItem {
        elytraFlightTick(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): boolean;
        getMaxDamage(arg0: Internal.ItemStack_): number;
        getShareTag(arg0: Internal.ItemStack_): Internal.CompoundTag;
        isDamageable(arg0: Internal.ItemStack_): boolean;
        isEnderMask(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.EnderMan_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        canGrindstoneRepair(arg0: Internal.ItemStack_): boolean;
        getBurnTime(arg0: Internal.ItemStack_, arg1: Internal.RecipeType_<any>): number;
        setDigSpeed(speed: number): void;
        onItemUseFirst(arg0: Internal.ItemStack_, arg1: Internal.UseOnContext_): Internal.InteractionResult;
        isCorrectToolForDrops(arg0: Internal.ItemStack_, arg1: Internal.BlockState_): boolean;
        isPiglinCurrency(arg0: Internal.ItemStack_): boolean;
        getEnchantmentValue(arg0: Internal.ItemStack_): number;
        canDisableShield(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: Internal.LivingEntity_, arg3: Internal.LivingEntity_): boolean;
        setAttackSpeed(attackSpeed: number): void;
        canApplyAtEnchantingTable(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): boolean;
        canWalkOnPowderedSnow(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        onStopUsing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_, arg2: number): void;
        isNotReplaceableByPickAction(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: number): boolean;
        getXpRepairRatio(arg0: Internal.ItemStack_): number;
        isBookEnchantable(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getCreativeTab(): string;
        initCapabilities(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): Internal.ICapabilityProvider;
        onDroppedByPlayer(arg0: Internal.ItemStack_, arg1: Internal.Player_): boolean;
        isDamaged(arg0: Internal.ItemStack_): boolean;
        getDefaultTooltipHideFlags(arg0: Internal.ItemStack_): number;
        getCreatorModId(arg0: Internal.ItemStack_): string;
        canContinueUsing(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        getFoodProperties(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): Internal.FoodProperties;
        getHighlightTip(arg0: Internal.ItemStack_, arg1: net.minecraft.network.chat.Component_): net.minecraft.network.chat.Component;
        onDestroyed(arg0: Internal.ItemEntity_, arg1: DamageSource_): void;
        onLeftClickEntity(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): boolean;
        canEquip(arg0: Internal.ItemStack_, arg1: Internal.EquipmentSlot_, arg2: Internal.Entity_): boolean;
        makesPiglinsNeutral(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        removeAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_): void;
        setArmorKnockbackResistance(knockbackResistance: number): void;
        canPerformAction(arg0: Internal.ItemStack_, arg1: Internal.ToolAction_): boolean;
        onInventoryTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_, arg3: number, arg4: number): void;
        hasCustomEntity(arg0: Internal.ItemStack_): boolean;
        onEntityItemUpdate(arg0: Internal.ItemStack_, arg1: Internal.ItemEntity_): boolean;
        getDamage(arg0: Internal.ItemStack_): number;
        getCraftingRemainingItem(arg0: Internal.ItemStack_): Internal.ItemStack;
        readShareTag(arg0: Internal.ItemStack_, arg1: Internal.CompoundTag_): void;
        /**
         * @deprecated
         * This method is marked to be removed in future!
        */
        onArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Player_): void;
        getEquipmentSlot(arg0: Internal.ItemStack_): Internal.EquipmentSlot;
        shouldCauseBlockBreakReset(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_): boolean;
        damageItem<T extends Internal.LivingEntity>(arg0: Internal.ItemStack_, arg1: number, arg2: T, arg3: Internal.Consumer_<T>): number;
        arch$registryName(): ResourceLocation;
        setAttackDamage(attackDamage: number): void;
        getAttributeModifiers(arg0: Internal.EquipmentSlot_, arg1: Internal.ItemStack_): Internal.Multimap<Internal.Attribute, Internal.AttributeModifier>;
        arch$holder(): Internal.Holder<Internal.Item>;
        getMod(): string;
        canElytraFly(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        createEntity(arg0: Internal.Level_, arg1: Internal.Entity_, arg2: Internal.ItemStack_): Internal.Entity;
        getArmorTexture(arg0: Internal.ItemStack_, arg1: Internal.Entity_, arg2: Internal.EquipmentSlot_, arg3: string): string;
        getAttributes(attribute: Internal.Attribute_): Internal.List<Internal.AttributeModifier>;
        setArmorProtection(armorProtection: number): void;
        onEntitySwing(arg0: Internal.ItemStack_, arg1: Internal.LivingEntity_): boolean;
        getEntityLifespan(arg0: Internal.ItemStack_, arg1: Internal.Level_): number;
        setArmorToughness(armorToughness: number): void;
        setDamage(arg0: Internal.ItemStack_, arg1: number): void;
        hasCraftingRemainingItem(arg0: Internal.ItemStack_): boolean;
        getMaxStackSize(arg0: Internal.ItemStack_): number;
        doesSneakBypassUse(arg0: Internal.ItemStack_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getSweepHitBox(arg0: Internal.ItemStack_, arg1: Internal.Player_, arg2: Internal.Entity_): Internal.AABB;
        getEnchantmentLevel(arg0: Internal.ItemStack_, arg1: Internal.Enchantment_): number;
        shouldCauseReequipAnimation(arg0: Internal.ItemStack_, arg1: Internal.ItemStack_, arg2: boolean): boolean;
        getAllEnchantments(arg0: Internal.ItemStack_): Internal.Map<Internal.Enchantment, number>;
        onHorseArmorTick(arg0: Internal.ItemStack_, arg1: Internal.Level_, arg2: Internal.Mob_): void;
        addAttribute(attribute: Internal.Attribute_, uuid: Internal.UUID_, name: string, d: number, operation: Internal.AttributeModifier$Operation_): void;
        getDigSpeed(): number;
        setTier(c: Internal.Consumer_<Internal.MutableToolTier>): void;
        setFoodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>): void;
        onBlockStartBreak(arg0: Internal.ItemStack_, arg1: BlockPos_, arg2: Internal.Player_): boolean;
        set digSpeed(speed: number)
        set attackSpeed(attackSpeed: number)
        get creativeTab(): string
        set armorKnockbackResistance(knockbackResistance: number)
        set attackDamage(attackDamage: number)
        get mod(): string
        set armorProtection(armorProtection: number)
        set armorToughness(armorToughness: number)
        get digSpeed(): number
        set tier(c: Internal.Consumer_<Internal.MutableToolTier>)
        set foodProperties(consumer: Internal.Consumer_<Internal.FoodBuilder>)
    }
    type ModItems$1_ = ModItems$1;
    class StasisEnchantment extends Internal.Enchantment {
        constructor()
        allowedInCreativeTab(arg0: Internal.Item_, arg1: Internal.Set_<Internal.EnchantmentCategory>): boolean;
        getDamageBonus(arg0: number, arg1: Internal.MobType_, arg2: Internal.ItemStack_): number;
        m_5975_(enchantment: Internal.Enchantment_): boolean;
    }
    type StasisEnchantment_ = StasisEnchantment;
    class ZetaFlammablePillarBlock extends Internal.ZetaPillarBlock {
        constructor(arg0: string, arg1: Internal.ZetaModule_, arg2: number, arg3: Internal.BlockBehaviour$Properties_)
        static isEnabled(arg0: Internal.Item_): boolean;
        canStickToZeta(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        isScaffoldingZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        setCreativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>, arg1: Internal.ItemLike_, arg2: boolean): Internal.Block;
        getBeaconColorMultiplierZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        setLightEmission(v: number): void;
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getFireSpreadSpeedZeta(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        setCreativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>): Internal.Block;
        getLightEmissionZeta(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        isStickyBlockZeta(arg0: Internal.BlockState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getSoundTypeZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        shouldDisplayFluidOverlayZeta(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        static isEnabled(arg0: Internal.Block_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isLadderZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        arch$holder(): Internal.Holder<Internal.Block>;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        getBlock(): Internal.Block;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        isConduitFrameZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        setCondition(arg0: Internal.BooleanSupplier_): any;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        isEnabled(): boolean;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getEnchantPowerBonusZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        makesOpenTrapdoorAboveClimbableZeta(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        collisionExtendsVerticallyZeta(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getToolModifiedStateZeta(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: string, arg3: boolean): Internal.BlockState;
        canSustainPlantZeta(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: string): boolean;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        set lightEmission(v: number)
        set creativeTab(arg0: Internal.ResourceKey_<Internal.CreativeModeTab>)
        set destroySpeed(v: number)
        get block(): Internal.Block
        set condition(arg0: Internal.BooleanSupplier_)
        get enabled(): boolean
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
    }
    type ZetaFlammablePillarBlock_ = ZetaFlammablePillarBlock;
    class SignBlockEntity extends Internal.BlockEntity {
        constructor(arg0: BlockPos_, arg1: Internal.BlockState_)
        constructor(arg0: Internal.BlockEntityType_<any>, arg1: BlockPos_, arg2: Internal.BlockState_)
        setText(arg0: Internal.SignText_, arg1: boolean): boolean;
        updateText(arg0: Internal.UnaryOperator_<Internal.SignText>, arg1: boolean): boolean;
        getMaxTextLineWidth(): number;
        requestModelDataUpdate(): void;
        handleUpdateTag(arg0: Internal.CompoundTag_): void;
        getPlayerWhoMayEdit(): Internal.UUID;
        tdv$isDynamicLightEnabled(): boolean;
        setWaxed(arg0: boolean): boolean;
        playerIsTooFarAwayToEdit(arg0: Internal.UUID_): boolean;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        updateSignText(arg0: Internal.Player_, arg1: boolean, arg2: Internal.List_<Internal.FilteredText>): void;
        static createCommandSourceStack(arg0: Internal.Player_, arg1: Internal.Level_, arg2: BlockPos_): Internal.CommandSourceStack;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        onDataPacket(arg0: Internal.Connection_, arg1: Internal.ClientboundBlockEntityDataPacket_): void;
        canExecuteClickCommands(arg0: boolean, arg1: Internal.Player_): boolean;
        deserializeNBT(arg0: Internal.Tag_): void;
        getTextFacingPlayer(arg0: Internal.Player_): Internal.SignText;
        getFrontText(): Internal.SignText;
        isWaxed(): boolean;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        isFacingFrontText(arg0: Internal.Player_): boolean;
        getUpdatePacket(): Internal.ClientboundBlockEntityDataPacket;
        getText(arg0: boolean): Internal.SignText;
        getBackText(): Internal.SignText;
        getTextLineHeight(): number;
        static tick(arg0: Internal.Level_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.SignBlockEntity_): void;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        getModelData(): Internal.ModelData;
        executeClickCommandsIfPresent(arg0: Internal.Player_, arg1: Internal.Level_, arg2: BlockPos_, arg3: boolean): boolean;
        setAllowedPlayerEditor(arg0: Internal.UUID_): void;
        get maxTextLineWidth(): number
        get playerWhoMayEdit(): Internal.UUID
        set waxed(arg0: boolean)
        get frontText(): Internal.SignText
        get waxed(): boolean
        get updatePacket(): Internal.ClientboundBlockEntityDataPacket
        get backText(): Internal.SignText
        get textLineHeight(): number
        get modelData(): Internal.ModelData
        set allowedPlayerEditor(arg0: Internal.UUID_)
        frontText: Internal.SignText;
    }
    type SignBlockEntity_ = SignBlockEntity;
    class BlockSkunkSpray extends Internal.MultifaceBlock implements Internal.SimpleWaterloggedBlock {
        constructor()
        isFlammable(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getRespawnPosition(arg0: Internal.BlockState_, arg1: Internal.EntityType_<any>, arg2: Internal.LevelReader_, arg3: BlockPos_, arg4: number, arg5: Internal.LivingEntity_): Internal.Optional<Vec3d>;
        supportsExternalFaceHiding(arg0: Internal.BlockState_): boolean;
        isEnabled(arg0: Internal.FeatureFlagSet_): boolean;
        isFertile(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        collisionExtendsVertically(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        canBeHydrated(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.FluidState_, arg4: BlockPos_): boolean;
        getPickupSound(): Internal.Optional<Internal.SoundEvent>;
        getWeakChanges(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): boolean;
        onBlockStateChange(arg0: Internal.LevelReader_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_): void;
        getFriction(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): number;
        canConnectRedstone(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isFireSource(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        isStickyBlock(arg0: Internal.BlockState_): boolean;
        setLightEmission(v: number): void;
        getBeaconColorMultiplier(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): number[];
        onBlockExploded(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Explosion_): void;
        getPistonPushReaction(arg0: Internal.BlockState_): Internal.PushReaction;
        isSlimeBlock(arg0: Internal.BlockState_): boolean;
        getAppearance(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.BlockState_, arg5: BlockPos_): Internal.BlockState;
        getExpDrop(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.RandomSource_, arg3: BlockPos_, arg4: number, arg5: number): number;
        setDestroySpeed(v: number): void;
        shouldDisplayFluidOverlay(arg0: Internal.BlockState_, arg1: Internal.BlockAndTintGetter_, arg2: BlockPos_, arg3: Internal.FluidState_): boolean;
        canEntityDestroy(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        rotate(arg0: Internal.BlockState_, arg1: Internal.LevelAccessor_, arg2: BlockPos_, arg3: Internal.Rotation_): Internal.BlockState;
        canHarvestBlock(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Player_): boolean;
        getToolModifiedState(arg0: Internal.BlockState_, arg1: Internal.UseOnContext_, arg2: Internal.ToolAction_, arg3: boolean): Internal.BlockState;
        isValidSpawn(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.SpawnPlacements$Type_, arg4: Internal.EntityType_<any>): boolean;
        placeLiquid(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.FluidState_): boolean;
        shouldCheckWeakPower(arg0: Internal.BlockState_, arg1: Internal.SignalGetter_, arg2: BlockPos_, arg3: Internal.Direction_): boolean;
        getFlammability(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        arch$holder(): Internal.Holder<Internal.Block>;
        isLadder(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getCloneItemStack(arg0: Internal.BlockState_, arg1: Internal.HitResult_, arg2: Internal.BlockGetter_, arg3: BlockPos_, arg4: Internal.Player_): Internal.ItemStack;
        makesOpenTrapdoorAboveClimbable(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.BlockState_): boolean;
        onDestroyedByPlayer(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Player_, arg4: boolean, arg5: Internal.FluidState_): boolean;
        getBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_): Internal.BlockPathTypes;
        onNeighborChange(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): void;
        getMapColor(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.MapColor_): Internal.MapColor;
        getPickupSound(arg0: Internal.BlockState_): Internal.Optional<Internal.SoundEvent>;
        canPlaceLiquid(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.Fluid_): boolean;
        isPortalFrame(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        onCaughtFire(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Direction_, arg4: Internal.LivingEntity_): void;
        hidesNeighborFace(arg0: Internal.BlockGetter_, arg1: BlockPos_, arg2: Internal.BlockState_, arg3: Internal.BlockState_, arg4: Internal.Direction_): boolean;
        onTreeGrow(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: Internal.BiConsumer_<BlockPos, Internal.BlockState>, arg3: Internal.RandomSource_, arg4: BlockPos_, arg5: Internal.TreeConfiguration_): boolean;
        isScaffolding(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.LivingEntity_): boolean;
        getStateAtViewpoint(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Vec3d_): Internal.BlockState;
        pickupBlock(arg0: Internal.LevelAccessor_, arg1: BlockPos_, arg2: Internal.BlockState_): Internal.ItemStack;
        getBlockStates(): Internal.List<Internal.BlockState>;
        isBed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        getExplosionResistance(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): number;
        getBedDirection(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): Internal.Direction;
        setRequiresTool(v: boolean): void;
        canStickTo(arg0: Internal.BlockState_, arg1: Internal.BlockState_): boolean;
        getFireSpreadSpeed(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Direction_): number;
        getLightEmission(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): number;
        setBedOccupied(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.LivingEntity_, arg4: boolean): void;
        arch$registryName(): ResourceLocation;
        getMod(): string;
        getAdjacentBlockPathType(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Mob_, arg4: Internal.BlockPathTypes_): Internal.BlockPathTypes;
        addLandingEffects(arg0: Internal.BlockState_, arg1: Internal.ServerLevel_, arg2: BlockPos_, arg3: Internal.BlockState_, arg4: Internal.LivingEntity_, arg5: number): boolean;
        canDropFromExplosion(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_, arg3: Internal.Explosion_): boolean;
        isConduitFrame(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: BlockPos_): boolean;
        getEnchantPowerBonus(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_): number;
        addRunningEffects(arg0: Internal.BlockState_, arg1: Internal.Level_, arg2: BlockPos_, arg3: Internal.Entity_): boolean;
        static removeStinkFace(arg0: Internal.BlockState_, arg1: Internal.Direction_): Internal.BlockState;
        getSoundType(arg0: Internal.BlockState_, arg1: Internal.LevelReader_, arg2: BlockPos_, arg3: Internal.Entity_): SoundType;
        isBurning(arg0: Internal.BlockState_, arg1: Internal.BlockGetter_, arg2: BlockPos_): boolean;
        get pickupSound(): Internal.Optional<Internal.SoundEvent>
        set lightEmission(v: number)
        set destroySpeed(v: number)
        get blockStates(): Internal.List<Internal.BlockState>
        set requiresTool(v: boolean)
        get mod(): string
        static readonly AGE: Internal.IntegerProperty;
    }
    type BlockSkunkSpray_ = BlockSkunkSpray;
    class Hashtable <K, V> extends Internal.Dictionary<K, V> implements Internal.Cloneable, Internal.Map<K, V>, Internal.Serializable {
        constructor(arg0: Internal.Map_<K, V>)
        constructor()
        constructor(arg0: number)
        constructor(arg0: number, arg1: number)
        clone(): any;
        computeIfAbsent(arg0: K, arg1: Internal.Function_<K, V>): V;
        replace(arg0: K, arg1: V): V;
        containsValue(arg0: any): boolean;
        computeIfPresent(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        static of<K, V>(): Internal.Map<K, V>;
        getOrDefault(arg0: any, arg1: V): V;
        static entry<K, V>(arg0: K, arg1: V): Internal.Map$Entry<K, V>;
        keys(): Internal.Enumeration<K>;
        containsKey(arg0: any): boolean;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V): Internal.Map<K, V>;
        put(arg0: K, arg1: V): V;
        get(arg0: any): V;
        remove(arg0: any): V;
        static copyOf<K, V>(arg0: Internal.Map_<K, V>): Internal.Map<K, V>;
        contains(arg0: any): boolean;
        elements(): Internal.Enumeration<V>;
        merge(arg0: K, arg1: V, arg2: Internal.BiFunction_<V, V, V>): V;
        putIfAbsent(arg0: K, arg1: V): V;
        keySet(): Internal.Set<K>;
        forEach(arg0: Internal.BiConsumer_<K, V>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V): Internal.Map<K, V>;
        values(): Internal.Collection<V>;
        entrySet(): Internal.Set<Internal.Map$Entry<K, V>>;
        compute(arg0: K, arg1: Internal.BiFunction_<K, V, V>): V;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V): Internal.Map<K, V>;
        remove(arg0: any, arg1: any): boolean;
        putAll(arg0: Internal.Map_<K, V>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V, arg18: K, arg19: V): Internal.Map<K, V>;
        static ofEntries<K, V>(...arg0: Internal.Map$Entry_<K, V>[]): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V, arg14: K, arg15: V, arg16: K, arg17: V): Internal.Map<K, V>;
        clear(): void;
        replace(arg0: K, arg1: V, arg2: V): boolean;
        replaceAll(arg0: Internal.BiFunction_<K, V, V>): void;
        static of<K, V>(arg0: K, arg1: V, arg2: K, arg3: V, arg4: K, arg5: V, arg6: K, arg7: V, arg8: K, arg9: V, arg10: K, arg11: V, arg12: K, arg13: V): Internal.Map<K, V>;
        static of<K, V>(arg0: K, arg1: V): Internal.Map<K, V>;
    }
    type Hashtable_<K, V> = Hashtable<K, V>;
    interface ComponentContents {
        resolve(arg0: Internal.CommandSourceStack_, arg1: Internal.Entity_, arg2: number): Internal.MutableComponent;
        visit<T>(arg0: Internal.FormattedText$StyledContentConsumer_<T>, arg1: Internal.Style_): Internal.Optional<T>;
        visit<T>(arg0: Internal.FormattedText$ContentConsumer_<T>): Internal.Optional<T>;
        readonly EMPTY: Internal.ComponentContents;
    }
    type ComponentContents_ = ComponentContents;
    class VideoMode {
        constructor(arg0: any_)
        constructor(arg0: number, arg1: number, arg2: number, arg3: number, arg4: number, arg5: number)
        constructor(arg0: any_)
        static read(arg0: string): Internal.Optional<Internal.VideoMode>;
        getRedBits(): number;
        getWidth(): number;
        getBlueBits(): number;
        write(): string;
        getHeight(): number;
        getGreenBits(): number;
        getRefreshRate(): number;
        get redBits(): number
        get width(): number
        get blueBits(): number
        get height(): number
        get greenBits(): number
        get refreshRate(): number
    }
    type VideoMode_ = VideoMode;
    interface ZAddReloadListener extends Internal.IZetaLoadEvent {
        abstract getRegistryAccess(): Internal.RegistryAccess;
        abstract getServerResources(): Internal.ReloadableServerResources;
        abstract addListener(arg0: Internal.PreparableReloadListener_): void;
        get registryAccess(): Internal.RegistryAccess
        get serverResources(): Internal.ReloadableServerResources
    }
    type ZAddReloadListener_ = ZAddReloadListener;
    class ForgeConfigSpec$Builder {
        constructor()
        define(arg0: string, arg1: boolean): Internal.ForgeConfigSpec$BooleanValue;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<V>, arg2: Internal.EnumGetMethod_, arg3: Internal.Predicate_<any>, arg4: V): Internal.ForgeConfigSpec$EnumValue<V>;
        defineInRange(arg0: Internal.List_<string>, arg1: number, arg2: number, arg3: number): Internal.ForgeConfigSpec$LongValue;
        define<T>(arg0: Internal.List_<string>, arg1: T): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V): Internal.ForgeConfigSpec$EnumValue<V>;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$EnumValue<V>;
        defineInRange(arg0: string, arg1: number, arg2: number, arg3: number): Internal.ForgeConfigSpec$DoubleValue;
        defineInRange(arg0: string, arg1: number, arg2: number, arg3: number): Internal.ForgeConfigSpec$IntValue;
        defineListAllowEmpty<T>(arg0: Internal.List_<string>, arg1: Internal.List_<T>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        defineList<T>(arg0: string, arg1: Internal.Supplier_<Internal.List<T>>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, arg2: Internal.EnumGetMethod_, arg3: Internal.Predicate_<any>): Internal.ForgeConfigSpec$EnumValue<V>;
        pop(): this;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, ...arg2: V[]): Internal.ForgeConfigSpec$EnumValue<V>;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, arg2: Internal.EnumGetMethod_): Internal.ForgeConfigSpec$EnumValue<V>;
        defineInList<T>(arg0: string, arg1: Internal.Supplier_<T>, arg2: Internal.Collection_<T>): Internal.ForgeConfigSpec$ConfigValue<T>;
        comment(...arg0: string[]): this;
        defineListAllowEmpty<T>(arg0: string, arg1: Internal.List_<T>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        define(arg0: string, arg1: Internal.Supplier_<boolean>): Internal.ForgeConfigSpec$BooleanValue;
        defineInList<T>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<T>, arg2: Internal.Collection_<T>): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineInRange(arg0: string, arg1: Internal.Supplier_<number>, arg2: number, arg3: number): Internal.ForgeConfigSpec$DoubleValue;
        defineInList<T>(arg0: string, arg1: T, arg2: Internal.Collection_<T>): Internal.ForgeConfigSpec$ConfigValue<T>;
        define<T>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<T>, arg2: Internal.Predicate_<any>, arg3: typeof any): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineInRange<V extends Internal.Comparable<any>>(arg0: string, arg1: Internal.Supplier_<V>, arg2: V, arg3: V, arg4: V): Internal.ForgeConfigSpec$ConfigValue<V>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$EnumValue<V>;
        defineInRange(arg0: Internal.List_<string>, arg1: number, arg2: number, arg3: number): Internal.ForgeConfigSpec$DoubleValue;
        defineList<T>(arg0: Internal.List_<string>, arg1: Internal.List_<T>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        define<T>(arg0: Internal.List_<string>, arg1: T, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<T>;
        define(arg0: Internal.List_<string>, arg1: Internal.Supplier_<boolean>): Internal.ForgeConfigSpec$BooleanValue;
        translation(arg0: string): this;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<V>, arg2: Internal.Predicate_<any>, arg3: V): Internal.ForgeConfigSpec$EnumValue<V>;
        define(arg0: Internal.List_<string>, arg1: boolean): Internal.ForgeConfigSpec$BooleanValue;
        defineInRange<V extends Internal.Comparable<any>>(arg0: string, arg1: V, arg2: V, arg3: V, arg4: V): Internal.ForgeConfigSpec$ConfigValue<V>;
        defineInRange(arg0: Internal.List_<string>, arg1: number, arg2: number, arg3: number): Internal.ForgeConfigSpec$IntValue;
        defineInRange(arg0: string, arg1: Internal.Supplier_<number>, arg2: number, arg3: number): Internal.ForgeConfigSpec$LongValue;
        defineInRange(arg0: Internal.List_<string>, arg1: Internal.Supplier_<number>, arg2: number, arg3: number): Internal.ForgeConfigSpec$DoubleValue;
        define<T>(arg0: string, arg1: T, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineInRange<V extends Internal.Comparable<any>>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<V>, arg2: V, arg3: V, arg4: V): Internal.ForgeConfigSpec$ConfigValue<V>;
        defineInRange<V extends Internal.Comparable<any>>(arg0: Internal.List_<string>, arg1: V, arg2: V, arg3: V, arg4: V): Internal.ForgeConfigSpec$ConfigValue<V>;
        defineInList<T>(arg0: Internal.List_<string>, arg1: T, arg2: Internal.Collection_<T>): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineListAllowEmpty<T>(arg0: string, arg1: Internal.Supplier_<Internal.List<T>>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, arg2: Internal.EnumGetMethod_, ...arg3: V[]): Internal.ForgeConfigSpec$EnumValue<V>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, ...arg2: V[]): Internal.ForgeConfigSpec$EnumValue<V>;
        defineInRange(arg0: Internal.List_<string>, arg1: Internal.Supplier_<number>, arg2: number, arg3: number): Internal.ForgeConfigSpec$IntValue;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, arg2: Internal.Collection_<V>): Internal.ForgeConfigSpec$EnumValue<V>;
        worldRestart(): this;
        define<T>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<T>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, arg2: Internal.EnumGetMethod_, arg3: Internal.Collection_<V>): Internal.ForgeConfigSpec$EnumValue<V>;
        pop(arg0: number): this;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, arg2: Internal.EnumGetMethod_, arg3: Internal.Collection_<V>): Internal.ForgeConfigSpec$EnumValue<V>;
        comment(arg0: string): this;
        defineList<T>(arg0: string, arg1: Internal.List_<T>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        defineInRange(arg0: string, arg1: Internal.Supplier_<number>, arg2: number, arg3: number): Internal.ForgeConfigSpec$IntValue;
        define<T>(arg0: Internal.List_<string>, arg1: Internal.ForgeConfigSpec$ValueSpec_, arg2: Internal.Supplier_<T>): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: Internal.Supplier_<V>, arg2: Internal.Predicate_<any>, arg3: V): Internal.ForgeConfigSpec$EnumValue<V>;
        build(): Internal.ForgeConfigSpec;
        defineListAllowEmpty<T>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<Internal.List<T>>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V): Internal.ForgeConfigSpec$EnumValue<V>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: Internal.Supplier_<V>, arg2: Internal.EnumGetMethod_, arg3: Internal.Predicate_<any>, arg4: V): Internal.ForgeConfigSpec$EnumValue<V>;
        define<T>(arg0: string, arg1: T): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, arg2: Internal.EnumGetMethod_, ...arg3: V[]): Internal.ForgeConfigSpec$EnumValue<V>;
        defineEnum<V extends Internal.Enum<V>>(arg0: string, arg1: V, arg2: Internal.EnumGetMethod_): Internal.ForgeConfigSpec$EnumValue<V>;
        defineInRange(arg0: Internal.List_<string>, arg1: Internal.Supplier_<number>, arg2: number, arg3: number): Internal.ForgeConfigSpec$LongValue;
        defineInRange(arg0: string, arg1: number, arg2: number, arg3: number): Internal.ForgeConfigSpec$LongValue;
        define<T>(arg0: string, arg1: Internal.Supplier_<T>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<T>;
        defineList<T>(arg0: Internal.List_<string>, arg1: Internal.Supplier_<Internal.List<T>>, arg2: Internal.Predicate_<any>): Internal.ForgeConfigSpec$ConfigValue<Internal.List<T>>;
        push(arg0: Internal.List_<string>): this;
        configure<T>(arg0: Internal.Function_<Internal.ForgeConfigSpec$Builder, T>): org.apache.commons.lang3.tuple.Pair<T, Internal.ForgeConfigSpec>;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, arg2: Internal.EnumGetMethod_, arg3: Internal.Predicate_<any>): Internal.ForgeConfigSpec$EnumValue<V>;
        push(arg0: string): this;
        defineEnum<V extends Internal.Enum<V>>(arg0: Internal.List_<string>, arg1: V, arg2: Internal.Collection_<V>): Internal.ForgeConfigSpec$EnumValue<V>;
    }
    type ForgeConfigSpec$Builder_ = ForgeConfigSpec$Builder;
    class RedstoneLinkNetworkHandler$Frequency {
        getStack(): Internal.ItemStack;
        static of(arg0: Internal.ItemStack_): Internal.RedstoneLinkNetworkHandler$Frequency;
        get stack(): Internal.ItemStack
        static readonly EMPTY: Internal.RedstoneLinkNetworkHandler$Frequency;
    }
    type RedstoneLinkNetworkHandler$Frequency_ = RedstoneLinkNetworkHandler$Frequency;
    class TravellingPoint$SteerDirection extends Internal.Enum<Internal.TravellingPoint$SteerDirection> {
        static values(): Internal.TravellingPoint$SteerDirection[];
        static valueOf(arg0: string): Internal.TravellingPoint$SteerDirection;
        static readonly NONE: Internal.TravellingPoint$SteerDirection;
        static readonly LEFT: Internal.TravellingPoint$SteerDirection;
        static readonly RIGHT: Internal.TravellingPoint$SteerDirection;
    }
    type TravellingPoint$SteerDirection_ = TravellingPoint$SteerDirection | "right" | "none" | "left";
    class CloudStatus extends Internal.Enum<Internal.CloudStatus> implements Internal.OptionEnum {
        getKey(): string;
        static valueOf(arg0: string): Internal.CloudStatus;
        static values(): Internal.CloudStatus[];
        getCaption(): net.minecraft.network.chat.Component;
        getId(): number;
        get key(): string
        get caption(): net.minecraft.network.chat.Component
        get id(): number
        static readonly OFF: Internal.CloudStatus;
        static readonly FAST: Internal.CloudStatus;
        static readonly FANCY: Internal.CloudStatus;
    }
    type CloudStatus_ = "off" | "fancy" | CloudStatus | "fast";
    class StructureModifier$Phase extends Internal.Enum<Internal.StructureModifier$Phase> {
        static valueOf(arg0: string): Internal.StructureModifier$Phase;
        static values(): Internal.StructureModifier$Phase[];
        static readonly MODIFY: Internal.StructureModifier$Phase;
        static readonly REMOVE: Internal.StructureModifier$Phase;
        static readonly AFTER_EVERYTHING: Internal.StructureModifier$Phase;
        static readonly ADD: Internal.StructureModifier$Phase;
        static readonly BEFORE_EVERYTHING: Internal.StructureModifier$Phase;
    }
    type StructureModifier$Phase_ = "remove" | StructureModifier$Phase | "before_everything" | "modify" | "after_everything" | "add";
    class ScanToolData {
        constructor(arg0: Internal.CompoundTag_)
        getCurrentSlotData(): Internal.ScanToolData$Slot;
        prevSlot(): void;
        getCurrentSlotId(): number;
        getInternalTag(): Internal.CompoundTag;
        setCurrentSlotData(arg0: Internal.ScanToolData$Slot_): void;
        nextSlot(): void;
        moveTo(arg0: number): void;
        get currentSlotData(): Internal.ScanToolData$Slot
        get currentSlotId(): number
        get internalTag(): Internal.CompoundTag
        set currentSlotData(arg0: Internal.ScanToolData$Slot_)
        static readonly NUM_SLOTS: 10;
    }
    type ScanToolData_ = ScanToolData;
    class EngineBackBlockEntity extends Internal.SmartBlockEntity implements Internal.IHaveGoggleInformation {
        constructor(arg0: Internal.BlockEntityType_<any>, arg1: BlockPos_, arg2: Internal.BlockState_)
        getCapability<T>(arg0: Internal.Capability_<T>, arg1: Internal.Direction_): Internal.LazyOptional<T>;
        deserializeNBT(arg0: Internal.Tag_): void;
        requestModelDataUpdate(): void;
        containedFluidTooltip(arg0: Internal.List_<net.minecraft.network.chat.Component>, arg1: boolean, arg2: Internal.LazyOptional_<Internal.IFluidHandler>): boolean;
        write(arg0: Internal.CompoundTag_, arg1: boolean): void;
        getCapability<T>(arg0: Internal.Capability_<T>): Internal.LazyOptional<T>;
        getFrontPart(): Internal.BlockEntity;
        tdv$isDynamicLightEnabled(): boolean;
        getTankInventory(): Internal.IFluidTank;
        deserializeNBT(arg0: Internal.CompoundTag_): void;
        getModelData(): Internal.ModelData;
        addToGoggleTooltip(arg0: Internal.List_<net.minecraft.network.chat.Component>, arg1: boolean): boolean;
        onLoad(): void;
        serializeNBT(): Internal.Tag;
        tdv$setDynamicLightEnabled(arg0: boolean): void;
        hasCustomOutlineRendering(arg0: Internal.Player_): boolean;
        get frontPart(): Internal.BlockEntity
        get tankInventory(): Internal.IFluidTank
        get modelData(): Internal.ModelData
        consumptionTimer: number;
        tankInventory: Internal.FluidTank;
    }
    type EngineBackBlockEntity_ = EngineBackBlockEntity;
}
declare namespace org.objectweb.asm {
    class Type {
        getOpcode(arg0: number): number;
        getClassName(): string;
        getSort(): number;
        getDescriptor(): string;
        static getDescriptor(arg0: typeof any): string;
        getSize(): number;
        static getConstructorDescriptor(arg0: Internal.Constructor_<any>): string;
        getDimensions(): number;
        static getType(arg0: Internal.Constructor_<any>): org.objectweb.asm.Type;
        static getType(arg0: typeof any): org.objectweb.asm.Type;
        static getInternalName(arg0: typeof any): string;
        getElementType(): this;
        static getMethodType(arg0: org.objectweb.asm.Type_, ...arg1: org.objectweb.asm.Type_[]): org.objectweb.asm.Type;
        static getMethodDescriptor(arg0: org.objectweb.asm.Type_, ...arg1: org.objectweb.asm.Type_[]): string;
        static getReturnType(arg0: Internal.Method_): org.objectweb.asm.Type;
        getInternalName(): string;
        static getReturnType(arg0: string): org.objectweb.asm.Type;
        getArgumentTypes(): org.objectweb.asm.Type[];
        static getObjectType(arg0: string): org.objectweb.asm.Type;
        static getMethodType(arg0: string): org.objectweb.asm.Type;
        static getMethodDescriptor(arg0: Internal.Method_): string;
        getArgumentsAndReturnSizes(): number;
        static getType(arg0: Internal.Method_): org.objectweb.asm.Type;
        static getArgumentTypes(arg0: string): org.objectweb.asm.Type[];
        getReturnType(): this;
        static getType(arg0: string): org.objectweb.asm.Type;
        static getArgumentsAndReturnSizes(arg0: string): number;
        static getArgumentTypes(arg0: Internal.Method_): org.objectweb.asm.Type[];
        get className(): string
        get sort(): number
        get descriptor(): string
        get size(): number
        get dimensions(): number
        get elementType(): org.objectweb.asm.Type
        get internalName(): string
        get argumentTypes(): org.objectweb.asm.Type[]
        get argumentsAndReturnSizes(): number
        get returnType(): org.objectweb.asm.Type
        static readonly ARRAY: 9;
        static readonly VOID_TYPE: org.objectweb.asm.Type;
        static readonly INT: 5;
        static readonly LONG: 7;
        static readonly SHORT_TYPE: org.objectweb.asm.Type;
        static readonly INT_TYPE: org.objectweb.asm.Type;
        static readonly CHAR: 2;
        static readonly BYTE: 3;
        static readonly CHAR_TYPE: org.objectweb.asm.Type;
        static readonly SHORT: 4;
        static readonly METHOD: 11;
        static readonly OBJECT: 10;
        static readonly BYTE_TYPE: org.objectweb.asm.Type;
        static readonly LONG_TYPE: org.objectweb.asm.Type;
        static readonly VOID: 0;
        static readonly FLOAT: 6;
        static readonly DOUBLE: 8;
        static readonly FLOAT_TYPE: org.objectweb.asm.Type;
        static readonly DOUBLE_TYPE: org.objectweb.asm.Type;
        static readonly BOOLEAN_TYPE: org.objectweb.asm.Type;
        static readonly BOOLEAN: 1;
    }
    type Type_ = Type;
}
declare namespace vectorwing.farmersdelight.common.mixin.accessor {
    interface RecipeManagerAccessor {
        abstract getRecipeMap<C extends net.minecraft.world.Container, T extends Internal.Recipe<C>>(arg0: Internal.RecipeType_<T>): Internal.Map<ResourceLocation, Internal.Recipe<C>>;
        (arg0: Internal.RecipeType<T>): Internal.Map_<ResourceLocation, Internal.Recipe<C>>;
    }
    type RecipeManagerAccessor_ = RecipeManagerAccessor;
}
