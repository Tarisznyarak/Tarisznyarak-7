StartupEvents.registry('item', event => {
  event.create('brass_precision_mechanism').displayName('§fBrass Precision Mechanism')
  })